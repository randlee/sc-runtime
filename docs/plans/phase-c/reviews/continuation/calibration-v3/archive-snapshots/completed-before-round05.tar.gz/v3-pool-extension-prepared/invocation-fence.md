```json
{
  "correlation_id": "sc-runtime-testability-v3-pool-extension",
  "operation": "testability",
  "params": {
    "authority": {
      "anchors": {
        "records": [],
        "sha256": "4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945"
      },
      "intent": {
        "content": "Fidelity is preservation of the meaning authorized by the verbatim quote together with explicitly approved context bound to the applicable fixture. Ordinary paraphrase and formalization of a directive into requirement language are allowed. A statement may extract one supported duty from a compound quote; it need not reproduce unrelated duties. It must retain substantive conditions, prohibitions, applicability, and allowed behavior. It must not select a new JSON shape, output stream, governed surface, actor, trigger, algorithm, or policy without authority for that selection. An unspecified distinction is not permission to choose one alternative.\n\nWhen the source requests a test using synthetic canary data, harmless concrete test values may instantiate that requested test. The instantiation must be identified as fixture-only data and must not add a production configuration binding, new trigger, output surface, storage policy, or behavior. Additional domain premises require explicit approval; they must not be invented or presented as previous approval.",
        "id": "human-approved-generic-fidelity-policy-v3",
        "sha256": "0f279abaa344206d9d5518d4bdce31e5bdf3f3131df4b628cf5922d95ef00be5",
        "version": 1
      }
    },
    "calibration_corpus": {
      "case_count": 36,
      "frozen_before_live": true,
      "path": "/Users/randlee/github/sc-runtime-worktrees/plan/phase-c/docs/plans/phase-c/reviews/continuation/calibration-v3/inputs/testability-calibration.v3.json",
      "schema": "plan-anchor/testability-calibration/2",
      "sha256": "cd4e9a96f8f018e394c897fc4cd82423a77771ddc7c20503b032db59451c96fb",
      "version": 2
    },
    "candidate_minimum": 3,
    "confidence_reference_threshold": 0.8,
    "correlation_id": "sc-runtime-testability-v3-pool-extension",
    "current_questions": {
      "faithful": {
        "criteria": {
          "no": "The statement commits to a new or contrary policy, implementation choice, strength, trigger or outcome.",
          "unclear": "Meaning preservation remains ambiguous after ordinary formalization and the supplied intent.",
          "yes": "Ordinary formalization or explicit approved clarification suffices to support the duty; no substantive requirement was invented."
        },
        "instructions": "Is the statement a faithful formal requirement derived from the supplied quote and optional approved intent? Preserve meaning, not spelling: an informal directive may become must; print, emit and write may be equivalent descriptions of the same ordinary output channel; conventional format or container terminology is allowed when the authority does not distinguish it. A statement may select one duty from several. Precision authorized by explicit state.intent.content is supported; precision inferred without that authority is not. Ignore whether the supported requirement is vague.",
        "type": "choice"
      },
      "observable": {
        "criteria": {
          "no": "Compliance depends on an undefined quality, private shorthand, or approval without an identified observable record or decision mechanism.",
          "unclear": "Evidence is identified, but the observation or decision needed to settle compliance remains ambiguous.",
          "yes": "The stated behavior or artifact supplies a determinate observation; any decisive approval condition identifies its observable record or decision mechanism."
        },
        "instructions": "Does anchor.statement identify an inspectable behavior or artifact sufficient to settle compliance? Concrete outputs, paths, explicit actions and prohibitions can supply that evidence as written. An approval-dependent condition needs an identified observable approval record or decision mechanism; naming an approver alone does not supply one. Do not invent a missing record, witness procedure or later inquiry. Recorded human approval can be observable.",
        "type": "choice"
      },
      "scoped": {
        "criteria": {
          "no": "No work area or applicability set is identifiable.",
          "unclear": "An area is named but its applicability cannot be determined.",
          "yes": "A reviewer can identify the work area where this anchor applies, including an explicit all-items set."
        },
        "instructions": "Do anchor.statement and anchor.scope identify the governed activity, component, artifact, or explicit global set, independent of whether the requirement itself is vague or otherwise defective?",
        "type": "choice"
      },
      "self_contained": {
        "criteria": {
          "no": "At least one decisive term is an undefined quality or private label, or compliance depends on an approval with no identified record.",
          "unclear": "A possible outside-context dependency exists but the statement does not show whether it is decisive.",
          "yes": "None of those outside-context dependencies is needed; ordinary technical terms, concrete prohibitions, lists, and explicit input/action/outcome conditions are sufficient."
        },
        "instructions": "Is anchor.statement independently understandable and applicable without any of these disqualifiers: an undefined subjective quality (for example robust), private shorthand, or a human approval that has no identified recorded artifact? Ignore grammar, bundling, fidelity, and scope.",
        "type": "choice"
      },
      "single_constraint": {
        "criteria": {
          "no": "It joins independently enforceable predicates requiring different behavior or policy.",
          "unclear": "The statement does not establish whether its clauses express one predicate or separate duties.",
          "yes": "The statement specifies one predicate, including a common predicate over several surfaces."
        },
        "instructions": "Evaluate whether anchor.statement governs one predicate. Repeating the same prohibition or outcome over terminal output, saved artifacts or other listed surfaces is one rule. A trigger restricts applicability rather than adding a separate duty. Different obligations such as formatting logs and retrying failures are independent even if the same service performs both. Ignore unused duties from the provenance quote.",
        "type": "choice"
      }
    },
    "gate": "testability",
    "operation": "testability",
    "production_confidence_threshold": 0.6,
    "repeat_count": 2,
    "runtime": {
      "agent": "anchor-tuning",
      "contract_script": "/tmp/plan-anchor-088-smoke-56bxrvbm/bd/.codex/skills/plan-anchoring/scripts/anchor_tuning_contract.py",
      "contract_sha256": "357b58b6de3b438d8945b5e087ea13eb265af22871e2b6032394786a66930e62",
      "harness": "codex",
      "model": "sol",
      "script": "/tmp/plan-anchor-088-smoke-56bxrvbm/bd/.codex/skills/plan-anchoring/scripts/jev_judge.py",
      "sha256": "a99b50920aa3516df2df09673f6e924166ab0390d98bd0c8a02bfb8cba6d84e3",
      "version": "0.8.8",
      "workspace": "/Users/randlee/github/sc-runtime-worktrees/plan/phase-c"
    },
    "schema_version": "2.0.0",
    "template": {
      "id": "anchor-tuning-testability-request",
      "sha256": "63a243019416001d3aa034523e510b0817e9af21058592961e413b13ff10b909",
      "version": "0.4.1"
    },
    "tournament_protocol_version": "plan-anchor/question-tournament/2.0.0"
  },
  "runtime": {
    "agent": "anchor-tuning",
    "harness": "codex",
    "model": "sol",
    "path": ".codex/agents/anchor-tuning.md",
    "sha256": "e47821f9906aade9ef5cb16d8d27754e0ffb6e09656cc6a226f1d18857ebea52",
    "version": "0.8.8"
  },
  "schema_version": "1.0.0"
}
```
