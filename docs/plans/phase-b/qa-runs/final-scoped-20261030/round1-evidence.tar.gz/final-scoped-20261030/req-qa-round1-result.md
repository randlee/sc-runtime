```json
{
  "status": "FAIL",
  "reviewed_branch": "plan/spinoff-monty-observability",
  "reviewed_commit": "67c9dc25aab0e4706db9637067b35d1a06690195",
  "errors": [],
  "scope": {
    "phase": "b",
    "sprint": "b-13..b-18"
  },
  "baselines_read": [
    ".claude/project/quality-policy.md",
    "docs/requirements.md",
    "docs/architecture.md",
    "docs/project-plan.md",
    "docs/framework-charter.md",
    "docs/sc-runtime-design.md",
    "docs/sc-cron/requirements.md",
    "docs/sc-cron/architecture.md",
    "docs/sc-runtime/requirements.md",
    "docs/sc-runtime/architecture.md",
    "docs/sc-runtime/observability-injection.md",
    "docs/sc-cron/hooks-sc-compose.md"
  ],
  "phase_or_sprint_docs_read": [
    "docs/plans/phase-b/phase-b-plan.md",
    "docs/plans/phase-b/sprint-b-13-observability-contract.md",
    "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md",
    "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md",
    "docs/plans/phase-b/sprint-b-16-monty-template-examples.md",
    "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md",
    "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
  ],
  "requirement_checks": [
    {
      "id": "NFR-CRON-0001",
      "source": "docs/sc-cron/requirements.md:122",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md"
      ]
    },
    {
      "id": "NFR-CRON-0002",
      "source": "docs/sc-cron/requirements.md:128",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "NFR-RT-0001",
      "source": "docs/sc-runtime/requirements.md:787",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "NFR-RT-0002",
      "source": "docs/sc-runtime/requirements.md:854",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "NFR-RT-0003",
      "source": "docs/sc-runtime/requirements.md:915",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "NFR-RT-0004",
      "source": "docs/sc-runtime/requirements.md:995",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "NFR-RUN-0002",
      "source": "docs/requirements.md:3778",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md",
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "NFR-RUN-0005",
      "source": "docs/requirements.md:3962",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md",
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "NFR-RUN-0008",
      "source": "docs/requirements.md:4126",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "NFR-RUN-0009",
      "source": "docs/requirements.md:4185",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md",
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "NFR-RUN-0010",
      "source": "docs/requirements.md:4302",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-CRON-0001",
      "source": "docs/sc-cron/requirements.md:5",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md"
      ]
    },
    {
      "id": "REQ-CRON-0003",
      "source": "docs/sc-cron/requirements.md:20",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-CRON-0004",
      "source": "docs/sc-cron/requirements.md:32",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-CRON-0005",
      "source": "docs/sc-cron/requirements.md:36",
      "listed_in_sprint_doc": true,
      "result": "violated",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-CRON-0019",
      "source": "docs/sc-cron/requirements.md:71",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-RT-0001",
      "source": "docs/sc-runtime/requirements.md:35",
      "listed_in_sprint_doc": true,
      "result": "violated",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-RT-0004",
      "source": "docs/sc-runtime/requirements.md:310",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-RT-0005",
      "source": "docs/sc-runtime/requirements.md:397",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-RUN-0002",
      "source": "docs/requirements.md:180",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-RUN-0003",
      "source": "docs/requirements.md:277",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-RUN-0004",
      "source": "docs/requirements.md:350",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-RUN-0005",
      "source": "docs/requirements.md:440",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-RUN-0301",
      "source": "docs/requirements.md:1428",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-RUN-0309",
      "source": "docs/requirements.md:2119",
      "listed_in_sprint_doc": true,
      "result": "violated",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-RUN-0503",
      "source": "docs/requirements.md:3213",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-RUN-0701",
      "source": "docs/requirements.md:3495",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-RUN-0702",
      "source": "docs/requirements.md:3617",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md"
      ]
    },
    {
      "id": "REQ-CRON-0005",
      "source": "docs/sc-cron/requirements.md:36",
      "listed_in_sprint_doc": false,
      "result": "violated",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:12"
      ],
      "notes": "The requirement governs current planned work but is missing from this sprint requirements list."
    },
    {
      "id": "REQ-RUN-0503",
      "source": "docs/requirements.md:3213",
      "listed_in_sprint_doc": false,
      "result": "violated",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:12"
      ],
      "notes": "The requirement governs current planned work but is missing from this sprint requirements list."
    },
    {
      "id": "REQ-RUN-0329",
      "source": "docs/requirements.md:2748",
      "listed_in_sprint_doc": false,
      "result": "violated",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:12"
      ],
      "notes": "The requirement governs current planned work but is missing from this sprint requirements list."
    },
    {
      "id": "REQ-RUN-0503",
      "source": "docs/requirements.md:3213",
      "listed_in_sprint_doc": false,
      "result": "violated",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:12"
      ],
      "notes": "The requirement governs current planned work but is missing from this sprint requirements list."
    }
  ],
  "deliverable_checks": [
    {
      "item": "b-13 deliverable 1: Amend ADR-RUN-0002, ADR-RUN-0003, ADR-RUN-0004, ADR-RUN-0007,",
      "status": "partially-present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:314"
      ],
      "notes": "Plan definition needs corrections REQ-QA-FINAL-001, REQ-QA-FINAL-002, REQ-QA-FINAL-003"
    },
    {
      "item": "b-13 deliverable 2: Add `sc-observability-types` to both boundary allowlists and crate",
      "status": "partially-present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:332"
      ],
      "notes": "Plan definition needs corrections REQ-QA-FINAL-001, REQ-QA-FINAL-002, REQ-QA-FINAL-003"
    },
    {
      "item": "b-13 deliverable 3: Implement the public signatures fixed above, propagate one handle through runtime",
      "status": "partially-present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:340"
      ],
      "notes": "Plan definition needs corrections REQ-QA-FINAL-001, REQ-QA-FINAL-002, REQ-QA-FINAL-003"
    },
    {
      "item": "b-13 deliverable 4: NFR-RT-0002 / NFR-CRON-0001 / NFR-RUN-0002 / NFR-RUN-0005: contract tests prove object safety, Noop compatibility, replacement,",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:356"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-13 deliverable 5: NFR-RT-0003 / NFR-RUN-0009: keep `tracing` manifest dependencies during the staged migration. Their",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:363"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-13 deliverable 6: REQ-RUN-0002 / REQ-RUN-0003 / REQ-RUN-0005 / REQ-RUN-0503 /",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:366"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-13 deliverable 7: NFR-RUN-0008: keep every changed production Rust source below the existing",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:375"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-13 deliverable 8: ADR-RUN-0011: production changes add no sleep or `block_on` call and hold",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:378"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-13 acceptance 1: ADR-RUN-0004 / ADR-RUN-0007 / ADR-RUN-0013 / ADR-RT-0001:",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:384"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-13 acceptance 2: ADR-RUN-0004: the required `sc-lint lint sc-boundary` command exits zero",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:388"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-13 acceptance 3: `boundary:BOUNDARY-sc-runtime`: the runtime `observability_contract` test",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:390"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-13 acceptance 4: `boundary:BOUNDARY-sc-cron`: the cron `observability_contract` and",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:393"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-13 acceptance 5: `boundary:BOUNDARY-sc-cron`: `observability_components` passes only when",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:397"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-13 acceptance 6: ADR-RUN-0004 / ADR-RUN-0007: both `observability_contract` tests pass only",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:400"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-13 acceptance 7: `boundary:observability-injection`: both `observability_contract` tests",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:403"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-13 acceptance 8: ADR-RUN-0002: both `cargo package --list` commands and `cargo metadata`",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:406"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-14 deliverable 1: REQ-RT-0004: replace `info_span!(\"http_request\", ...)` with the three events above.",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:77"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-14 deliverable 2: REQ-RT-0004: preserve the exact `x-request-id` used by responses and canonical events.",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:78"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-14 deliverable 3: REQ-RT-0005: preserve existing timeout/drain envelopes and stable codes",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:79"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-14 deliverable 4: NFR-RT-0004 / NFR-RUN-0009: add a recording-emitter fixture without a full-observability dependency.",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:81"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-14 deliverable 5: NFR-RT-0002 / NFR-RT-0003: remove direct tracing calls from runtime source. The shared manifest is",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:82"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-14 deliverable 6: REQ-RT-0005 / NFR-RUN-0005 / ADR-RT-0004: add a runtime regression that",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:84"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-14 deliverable 7: ADR-RUN-0011: production changes add no sleep or `block_on` call and hold",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:88"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-14 acceptance 1: `boundary:BOUNDARY-sc-runtime`: `observability_http` passes only when a",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:94"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-14 acceptance 2: `boundary:BOUNDARY-sc-runtime`: `observability_http` passes only when a",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:96"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-14 acceptance 3: ADR-RT-0001 / `boundary:BOUNDARY-sc-runtime`: `observability_http` passes only when",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:99"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-14 acceptance 4: ADR-RUN-0004 / ADR-RUN-0007 / NFR-RUN-0002: `observability_http` passes only when",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:102"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-14 acceptance 5: `boundary:BOUNDARY-sc-runtime`: the required boundary lint and",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:105"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-14 acceptance 6: `boundary:BOUNDARY-sc-runtime`: `observability_http` passes only when an",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:111"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-14 acceptance 7: `boundary:BOUNDARY-sc-runtime`: table-driven 1xx/2xx/3xx/4xx/5xx and",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:114"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-15 deliverable 1: REQ-CRON-0001 / REQ-CRON-0003: replace production trace calls in the owned files with canonical events;",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md:130"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-15 deliverable 2: REQ-CRON-0003 / NFR-CRON-0001: preserve the baseline's stable Monty codes (`DUE_JOIN_FAILED`,",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md:135"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-15 deliverable 3: REQ-CRON-0005: replace persisted `\"resolve: ...\"` and",
      "status": "partially-present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md:137"
      ],
      "notes": "Plan definition needs corrections REQ-QA-FINAL-004"
    },
    {
      "item": "b-15 deliverable 4: ADR-RUN-0007 / NFR-RUN-0002 / NFR-RUN-0005 / NFR-RUN-0009: test native",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md:143"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-15 deliverable 5: ADR-RUN-0004 / NFR-CRON-0001: remove direct tracing calls from owned",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md:148"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-15 deliverable 6: ADR-RUN-0011: production changes add no sleep or `block_on` call and hold",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md:151"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-15 acceptance 1: `boundary:BOUNDARY-sc-cron`: `observability` passes only when native and",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md:157"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-15 acceptance 2: ADR-RUN-0013: `observability` passes only when rejecting every event leaves",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md:161"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-15 acceptance 3: `boundary:BOUNDARY-sc-cron`: `observability` and `monty_hook` pass with",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md:163"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-15 acceptance 4: `boundary:BOUNDARY-sc-cron`: `observability` passes only when identifiers",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md:166"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-15 acceptance 5: `cargo +1.96.1 test -p sc-cron --features monty` passes against the landed",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md:171"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-15 acceptance 6: `boundary:BOUNDARY-sc-cron`: the table-driven `observability` test passes",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md:175"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-15 acceptance 7: `boundary:BOUNDARY-sc-cron`: worker cases in `observability` pass only when",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md:178"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 deliverable 1: REQ-CRON-0003 / REQ-CRON-0005 / ADR-RUN-0013 / NFR-CRON-0001: amend the ADR, requirements,",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:182"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 deliverable 2: REQ-CRON-0003 / ADR-RUN-0011 / ADR-RUN-0013: retain `sc_compose_run` only as the opt-in",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:189"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 deliverable 3: REQ-RUN-0301 / REQ-CRON-0001 / ADR-RUN-0303: add optional daemon dependency `sc-cron`, direct",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:196"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 deliverable 4: ADR-RUN-0002 / REQ-RUN-0003 / REQ-RUN-0309 / REQ-RUN-0702: update both template dependency",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:200"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 deliverable 5: REQ-CRON-0003: add `template/examples/monty/cron.py` with `cron_stop` and",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:208"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 deliverable 6: ADR-RUN-0013 / NFR-CRON-0001: create",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:214"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 deliverable 7: REQ-RUN-0005 / NFR-CRON-0001: enforce the tool-crate exclusion on all",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:222"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 deliverable 8: NFR-RUN-0005 / REQ-RUN-0503: require the freshly generated, unedited checkout",
      "status": "partially-present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:234"
      ],
      "notes": "Plan definition needs corrections REQ-QA-FINAL-001"
    },
    {
      "item": "b-16 acceptance 1: `REQ-CRON-0001`: `test_monty_example` and the two generated `cargo check`",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:244"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 acceptance 2: `REQ-CRON-0003`: `monty_host_bridge` passes empty-default, custom",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:247"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 acceptance 3: `NFR-CRON-0001`: the required `cargo tree` command passes inspection with",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:258"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 acceptance 4: `NFR-RUN-0005`: `test_monty_example` passes using a temporary output and",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:261"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 acceptance 5: ADR-RUN-0013: `monty_host_bridge` and `test_monty_example` pass only when",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:263"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 acceptance 6: ADR-RUN-0303: the required `cargo tree` and manifest `rg` commands pass",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:267"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 acceptance 7: ADR-RUN-0002: the manifest `rg` check and `test_monty_example` pass only",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:271"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 acceptance 8: `test_monty_example` passes with b-17 able to consume the exact feature",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:275"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 acceptance 9: `monty_host_bridge::render_helper_not_registered` passes only when default",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:277"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-16 acceptance 10: REQ-RUN-0005: `test_production_tool_boundary` and the production",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:282"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-17 deliverable 1: REQ-CRON-0001/0003/0004/0005/0019, ADR-RUN-0013/0016, NFR-CRON-0002:",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:356"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-17 deliverable 2: NFR-CRON-0001 / NFR-RUN-0009: export the types and boundary facade;",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:360"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-17 deliverable 3: REQ-CRON-0019 / NFR-RUN-0005: deliver the same snapshot through worker,",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:362"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-17 deliverable 4: REQ-RUN-0301 / REQ-CRON-0019 / ADR-RUN-0014: generate the specified empty",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:365"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-17 deliverable 5: NFR-RUN-0005: add Unix/Windows parity and canary tests below. Production adds",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:369"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-17 acceptance 1: The hook_environment suite proves exact canonical round-trip/default,",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:375"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-17 acceptance 2: Daemon identity/team cannot override schedule Set values. Caller-only and",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:379"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-17 acceptance 3: File cases cover optional/required absence, malformed dotenv, symlink escape,",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:382"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-17 acceptance 4: Python preserves hook protocol, process deadlines/kill/caps, explicit Inherit",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:386"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-17 acceptance 5: Both CLI fixtures echo allowed canaries and omit unlisted secrets while",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:391"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-17 acceptance 6: Canary cases include ENV, HOST, :, and 1: redaction must not alter fixed",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:395"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-17 acceptance 7: SQLite cases prove fresh schema creation, canonical round-trip, empty",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:399"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-17 acceptance 8: test_cron_environment proves empty administrator defaults, absolute paths,",
      "status": "partially-present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:402"
      ],
      "notes": "Plan definition needs corrections REQ-QA-FINAL-001"
    },
    {
      "item": "b-18 deliverable 1: ADR-RUN-0004 / REQ-RUN-0004 / REQ-RUN-0309: change generated `Observability` to Arc ownership and expose only the",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:291"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 deliverable 2: ADR-RT-0001 / REQ-RT-0001 / REQ-RT-0004: inject that handle into `DaemonBuilder` for every layout.",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:293"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 deliverable 3: ADR-RUN-0013 / REQ-RUN-0301 / REQ-CRON-0003/0004/0005/0019 /",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:294"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 deliverable 4: NFR-RUN-0005: add a generated-project smoke test that polls with a deadline, sends a",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:300"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 deliverable 5: ADR-RUN-0007 / ADR-RUN-0011 / NFR-RUN-0002 / NFR-RUN-0009: prove the fixed reachable result/shutdown precedence and that",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:304"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 deliverable 6: REQ-RUN-0503 / REQ-RUN-0701: make the PR template workflow create one",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:312"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 deliverable 7: ADR-RUN-0002 / REQ-RUN-0002 / REQ-RUN-0003 / REQ-RUN-0702: extend the existing sc-publish consumer input for the",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:319"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 deliverable 8: REQ-RUN-0702: after the five internal `0.1.1` crates are published, render",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:340"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 deliverable 9: REQ-RT-0005 / NFR-RUN-0010 / ADR-RT-0002 / ADR-TRN-0006: on an isolated ephemeral CI runner only,",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:348"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 deliverable 10: NFR-RUN-0008: keep every generated production Rust file below the existing",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:357"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 acceptance 1: REQ-RUN-0309 / REQ-RUN-0004: `test_observability` passes only when config",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:362"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 acceptance 2: REQ-RT-0001 / REQ-RT-0004 / NFR-RT-0001 / NFR-RT-0002 /",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:365"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 acceptance 3: REQ-CRON-0004 / REQ-CRON-0005 / ADR-RUN-0014: `test_schedule_limit_mapping` and the full",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:369"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 acceptance 4: ADR-RUN-0007 / NFR-RUN-0002 / NFR-RUN-0009: b-14/b-15",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:386"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 acceptance 5: REQ-RUN-0005: `cargo tree` for the generated daemon and b-13's direct-tree",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:390"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 acceptance 6: REQ-RUN-0002 / REQ-RUN-0003 / REQ-RUN-0503 / REQ-RUN-0701 /",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:393"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 acceptance 7: REQ-RT-0005 / NFR-RUN-0010 / ADR-RT-0002 / ADR-TRN-0006:",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:400"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    },
    {
      "item": "b-18 acceptance 8: NFR-RUN-0008: `just lint gates` exits zero with the line-count gate clean",
      "status": "present",
      "closure_state": "not-applicable",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:405"
      ],
      "notes": "Concrete planned work/acceptance is defined with named ownership/tests; implementation completion is not being asserted."
    }
  ],
  "findings": [
    {
      "id": "REQ-QA-FINAL-001",
      "severity": "Blocking",
      "category": "requirement-not-listed",
      "source_refs": [
        ".claude/agents/req-qa.md:98",
        "docs/sc-cron/requirements.md:36",
        "docs/requirements.md:3213",
        "docs/requirements.md:2748"
      ],
      "target_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:12",
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:178",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:12",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:155",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:234",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:12",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:405"
      ],
      "issue": "The final additions are not fully reflected in requirements frontmatter: b-13 omits REQ-CRON-0005 despite adding fallible public sc-cron signatures and an explicit CronError rule; b-16 omits REQ-RUN-0503 despite its new no-edits validation and REQ-RUN-0329 despite its generated package-name preservation obligation; b-17 omits REQ-RUN-0503 despite explicitly requiring that sequence.",
      "required_correction": "Add those already-governing IDs to the existing requirements lists (b-13: REQ-CRON-0005; b-16: REQ-RUN-0503 and REQ-RUN-0329; b-17: REQ-RUN-0503). This is metadata reconciliation only; no new scope, checker, or inventory is needed.",
      "compliance_result": "partially-compliant"
    },
    {
      "id": "REQ-QA-FINAL-002",
      "severity": "Blocking",
      "category": "cross-doc-conflict",
      "source_refs": [
        "docs/requirements.md:2169",
        "docs/sc-runtime/requirements.md:52",
        "docs/sc-runtime/requirements.md:811"
      ],
      "target_refs": [
        "docs/sc-runtime/requirements.md:192",
        "docs/sc-runtime/requirements.md:629",
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:183",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:200",
        "docs/requirements.md:2158",
        "docs/sc-runtime/requirements.md:72"
      ],
      "issue": "Canonical observability authority retains conflicting remnants: REQ-RT-0001 success criterion6 forbids every builder method except stores/routes/mcp/run while its own method table and NFR-RT-0001 permit logger; REQ-RT-0007 still says sc-runtime has no direct sc-observability-types dependency although REQ-RUN-0309 and the amended graph require it. The canonical main examples also call Observability::shared_log(), but b-18 fixes the generated getter as logger().",
      "required_correction": "Reconcile these existing canonical clauses/examples to the already approved injection contract: include logger in REQ-RT-0001 criterion6, state that StoresFailed remains string-based while types-only logging is permitted, and use the same generated Observability getter name everywhere. Make the b-13 authority-amendment scope/list explicitly cover REQ-RT-0007 if its text changes. Do not alter runtime error representation or the public interface to preserve stale prose.",
      "compliance_result": "non-compliant"
    },
    {
      "id": "REQ-QA-FINAL-003",
      "severity": "Blocking",
      "category": "acceptance-gap",
      "source_refs": [
        "docs/requirements.md:2131",
        "docs/requirements.md:2169",
        "Cargo.toml:3"
      ],
      "target_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:333",
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:339"
      ],
      "issue": "b-13 requires the root Cargo.lock to prove the exact 1.5.1 observability pair immediately after forbidding either library from resolving the full logger. The maintainer workspace contains crates/*, not the generated daemon, and has no permitted full-logger dependency edge. Its lockfile cannot prove full sc-observability resolution without adding an unplanned or forbidden edge. The canonical requirement correctly locates pair resolution in the generated lockfile.",
      "required_correction": "State that the root lockfile proves sc-observability-types 1.5.1 only; the matching full-logger release is an external entry prerequisite, and b-16/b-18 generated-project lockfiles prove the pair. Keep full logger dependencies out of library tests/manifests and do not add a new workspace harness merely to populate the root lockfile.",
      "compliance_result": "non-compliant"
    },
    {
      "id": "REQ-QA-FINAL-004",
      "severity": "Blocking",
      "category": "cross-doc-conflict",
      "source_refs": [
        "docs/sc-cron/requirements.md:42"
      ],
      "target_refs": [
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md:137",
        "docs/plans/phase-b/sprint-b-15-sc-cron-observability.md:142"
      ],
      "issue": "b-15 declares the CODE: detail; recovery display form to be neither public nor parseable schema. REQ-CRON-0005 explicitly documents RunOutcome::failure_parts/RunFailureParts as the public parser of that form for agents and UIs. The plan cannot both produce that stable format and disclaim the supported parser contract.",
      "required_correction": "Preserve the documented failure_parts format/parser. Clarify instead that canonical LogEvent diagnostic codes are chosen from typed outcomes/origin sites and must never be inferred by parsing arbitrary consumer prose. No new parser or public error variant is needed.",
      "compliance_result": "non-compliant"
    },
    {
      "id": "REQ-QA-FINAL-005",
      "severity": "Important",
      "category": "cross-doc-conflict",
      "source_refs": [
        "docs/sc-cron/requirements.md:38",
        "docs/requirements.md:4185"
      ],
      "target_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:178",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:155",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:162"
      ],
      "issue": "The new blanket sentence says every fallible public sc-cron function returns CronError, while the public application-implemented EnvironmentReferenceResolver::resolve protocol returns EnvironmentReferenceError. The finite callback result is appropriate for value-free provider failures, but the documentation does not distinguish that external provider protocol from fallible library entry points.",
      "required_correction": "Clarify REQ-CRON-0005 and the b-13 blanket sentence: library-originating fallible entry points use CronError; the application resolver callback has the narrow Denied/Unavailable result protocol and is mapped to the fixed ENV_REFERENCE class. Retain the existing callback design and no-provider-prose rule; do not add another library error channel or opaque provider errors.",
      "compliance_result": "partially-compliant"
    },
    {
      "id": "REQ-QA-FINAL-006",
      "severity": "Important",
      "category": "acceptance-gap",
      "source_refs": [
        "docs/sc-cron/requirements.md:46",
        "docs/sc-cron/requirements.md:47"
      ],
      "target_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:111",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:136",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:253"
      ],
      "issue": "The host error inventory says invalid registered-handler arguments yield HOST_DENIED, while b-16 maps every registered handler error to HOST_CALL_FAILED and exposes no generic argument-schema metadata. If an application handler rejects arguments by returning CronError::InvalidSpec, the two descriptions imply different codes.",
      "required_correction": "Fix the inventory boundary explicitly: HOST_DENIED covers bridge conversion/supplied CLI adapter shape rejection; custom-handler returned errors, including InvalidSpec, map to HOST_CALL_FAILED, or document one consistent alternative. Reuse the existing handler-error acceptance case to make the selected mapping explicit rather than adding schema machinery.",
      "compliance_result": "partially-compliant"
    }
  ],
  "summary": {
    "total_findings": 6,
    "blocking_findings": 4,
    "important_findings": 2,
    "minor_findings": 0,
    "overall_compliance": "non-compliant",
    "deliverables_total": 92,
    "deliverables_complete": 86,
    "deliverables_incomplete": 6,
    "deliverable_completion_percent": 93.5
  },
  "gate_reason": "Four blocking plan/authority consistency defects and two public error-contract clarifications remain. No product-intent reversal is recommended; corrections are existing metadata/text/acceptance alignment, not new implementation scope. Future code absence and external publication prerequisites were not treated as plan-merge blockers."
}
```
