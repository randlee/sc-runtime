```json
{
  "agent": "arch-qa",
  "branch": "plan/spinoff-monty-observability",
  "scope": {
    "phase": "b",
    "sprint": "b-13..b-18"
  },
  "commit": "67c9dc25aab0e4706db9637067b35d1a06690195",
  "verdict": "FAIL",
  "blocking": 3,
  "important": 0,
  "minor": 1,
  "findings": [
    {
      "id": "ARCH-001",
      "rule": "RULE-ADR-PLAN",
      "adr": "ADR-RUN-0003",
      "severity": "BLOCKING",
      "file": "docs/plans/phase-b/sprint-b-16-monty-template-examples.md",
      "line": 23,
      "description": "b-16 changes dependency/import enforcement in all five production boundary manifests and production feature/dependency-tree gates, but its adrs list omits ADR-RUN-0003, which governs the library dependency graph and feature/dependency enforcement. REQ-RUN-0005 and ADR-RUN-0013 do not replace the governing-ADR listing requirement.",
      "remediation": "Add ADR-RUN-0003 to b-16 adrs and cite it on the existing production tool-crate boundary deliverable/acceptance. Preserve the approved prohibition and existing enforcement plan; no new artifact or gate is needed."
    },
    {
      "id": "ARCH-002",
      "rule": "RULE-ADR-PLAN",
      "adr": "ADR-RUN-0002",
      "severity": "BLOCKING",
      "file": "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md",
      "line": 24,
      "description": "b-17 adds public library environment types while editing template configuration, daemon cron composition, and a generated example. Those deliverables are governed by ADR-RUN-0002 placement of reusable behavior in crates and application configuration/wiring in the template, but that ADR is absent from its adrs list even though the Goal now states the architecture explicitly.",
      "remediation": "Add ADR-RUN-0002 to b-17 adrs and cite it on the existing generated policy/configuration/example deliverable. Keep the existing library/template split; do not introduce a new acceptance artifact."
    },
    {
      "id": "ARCH-003",
      "rule": "RULE-ADR-PLAN",
      "adr": "ADR-RUN-0016",
      "severity": "BLOCKING",
      "file": "docs/sc-cron/architecture.md",
      "line": 134,
      "description": "The component architecture says every function call is denied during Monty source initialization. ADR-RUN-0016 decision 4 and b-17 deny registered host calls during initialization while permitting Getenv/GetEnviron; they do not prohibit ordinary VM-local function calls. The unqualified component rule is a broader incompatible execution contract and could even be read to prohibit the promised top-level os.getenv call.",
      "remediation": "Replace every function call with every registered host call (including sc_compose_run and atm_run), explicitly leaving ordinary Monty-local computation and configured environment reads intact. This aligns the component text to the existing ADR and sprint; no API or policy expansion is required."
    },
    {
      "id": "ARCH-004",
      "rule": "RULE-ADR-PLAN",
      "adr": "ADR-RT-0004",
      "severity": "MINOR",
      "file": "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md",
      "line": 99,
      "description": "The acceptance text calls the fixture-based shutdown proof a real signal regression, while ADR-RT-0004 requires the fixture to stop through a crate-private trigger rather than a process signal. The deliverable already selects the existing fixture, so the required behavior is recoverable, but this phrase unnecessarily blurs b-14 with b-18 real-signal CI testing.",
      "remediation": "Name the fixture-private shutdown trigger in the existing deliverable/acceptance and reserve real SIGINT/SIGTERM language for b-18. No new test or safety gate is needed."
    }
  ],
  "adr_checks": [
    {
      "adr": "ADR-RUN-0002",
      "source": "docs/architecture.md:311",
      "listed_in_sprint_doc": false,
      "result": "violated",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:24",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:76"
      ]
    },
    {
      "adr": "ADR-RUN-0003",
      "source": "docs/architecture.md:423",
      "listed_in_sprint_doc": false,
      "result": "violated",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:23",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:220"
      ]
    },
    {
      "adr": "ADR-RUN-0004",
      "source": "docs/architecture.md:584",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:107",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:192"
      ]
    },
    {
      "adr": "ADR-RUN-0007",
      "source": "docs/architecture.md:856",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:123",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:262"
      ]
    },
    {
      "adr": "ADR-RUN-0011",
      "source": "docs/architecture.md:2354",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:136",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:262"
      ]
    },
    {
      "adr": "ADR-RUN-0013",
      "source": "docs/architecture.md:2422",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:99",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:335"
      ]
    },
    {
      "adr": "ADR-RUN-0014",
      "source": "docs/architecture.md:2467",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:295"
      ]
    },
    {
      "adr": "ADR-RUN-0016",
      "source": "docs/architecture.md:2521",
      "listed_in_sprint_doc": true,
      "result": "violated",
      "evidence_refs": [
        "docs/sc-cron/architecture.md:134",
        "docs/architecture.md:2576",
        "docs/plans/phase-b/sprint-b-17-sc-cron-hook-environment.md:307"
      ]
    },
    {
      "adr": "ADR-RUN-0303",
      "source": "docs/architecture.md:1853",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:319",
        "docs/plans/phase-b/sprint-b-16-monty-template-examples.md:177"
      ]
    },
    {
      "adr": "ADR-RT-0001",
      "source": "docs/sc-runtime/architecture.md:62",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:181",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:292"
      ]
    },
    {
      "adr": "ADR-RT-0002",
      "source": "docs/sc-runtime/architecture.md:191",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:343"
      ]
    },
    {
      "adr": "ADR-RT-0004",
      "source": "docs/sc-runtime/architecture.md:331",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:84",
        "docs/plans/phase-b/sprint-b-14-sc-runtime-observability.md:99"
      ]
    },
    {
      "adr": "ADR-TRN-0006",
      "source": "docs/sc-transport/architecture.md:527",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:343"
      ]
    },
    {
      "adr": "ADR-CMD-0001",
      "source": "docs/sc-command/architecture.md:38",
      "listed_in_sprint_doc": true,
      "result": "upheld",
      "evidence_refs": [
        "docs/plans/phase-b/sprint-b-13-observability-contract.md:319"
      ]
    }
  ],
  "gate_artifact_checks": [
    {
      "artifact": ".sprints/b/structure.ttl",
      "status": "closed",
      "evidence_refs": [
        ".sprints/b/structure.ttl:114",
        "docs/plans/phase-b/phase-b-plan.md:208"
      ],
      "notes": "Continuation branch, criteria, integration branch, and follows records agree with six sprint frontmatters and phase DAG. Same-wave ownership remains disjoint."
    },
    {
      "artifact": "doc/plan/phase-current/anchor-runs/tuning-20261029/approval-gate-20261030/README.md",
      "status": "closed",
      "evidence_refs": [
        "doc/plan/phase-current/anchor-runs/tuning-20261029/approval-gate-20261030/README.md:1",
        "doc/plan/phase-current/anchor-runs/tuning-20261029/approval-gate-20261030/final-gate-summary.json"
      ],
      "notes": "Directly inspected final planning gate report and summary. Its claim is plan approval only, with recorded exclusions and baseline coverage; it does not claim runtime delivery."
    },
    {
      "artifact": "release/sc-publish-pin.toml",
      "status": "not-applicable",
      "evidence_refs": [
        "release/sc-publish-pin.toml:9",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:181"
      ],
      "notes": "Current pin remains explicitly rejected as a future b-18 entry artifact. Plan names the later qualifying revision condition, package-safe installer outputs, authorization, publication order, immutable source/tag, and registry proof. No implementation-entry closure is claimed by this planning PR."
    },
    {
      "artifact": "release/sc-publish-consumer-input.json",
      "status": "not-applicable",
      "evidence_refs": [
        "release/sc-publish-consumer-input.json:22",
        "docs/plans/phase-b/sprint-b-18-template-observability-integration.md:315"
      ],
      "notes": "Existing four-crate release input is baseline; b-18 explicitly plans the fifth crate and regenerates kit-owned outputs. No hand-authored workflow or current publication is claimed."
    }
  ],
  "merge_ready": false,
  "notes": "Docs-only pre-implementation review against exact assigned head. No planned runtime implementation was expected to exist. General-purpose app-owned host registration, both any-command adapters, production crate exclusions, shared explicit environment, no MVP signing option, and first-release schema align approved intent. Three local architectural traceability/wording defects require correction; no owner product decision or new sprint/process artifact is needed. No tests, Jev, network calls, or canonical source edits performed."
}
```
