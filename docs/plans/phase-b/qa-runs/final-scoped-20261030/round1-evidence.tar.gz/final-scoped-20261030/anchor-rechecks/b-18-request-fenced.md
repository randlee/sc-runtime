```json
{
  "schema_version": "1.0.0",
  "runtime": {"agent":"anchor-plan-review","harness":"codex","model":"luna","path":".codex/agents/anchor-plan-review.md","sha256":"f1edd0f1c5b77787b44f7f75bf344eeabf73962dfc84597299240be0ff8ecafa","version":"0.8.5"},
  "operation": "plan_review",
  "correlation_id": "pr85-scoped-qa-b18-20261030",
  "params": {"anchor_ids":"all","anchor_tracker":"bd","anchors_path":"/Volumes/Extreme Pro/github/sc-runtime-worktrees/plan/spinoff-monty-observability/doc/plan/phase-current/anchors.json","correlation_id":"pr85-scoped-qa-b18-20261030","dry_run":false,"item_file":"/Volumes/Extreme Pro/github/sc-runtime-worktrees/plan/spinoff-monty-observability/docs/plans/phase-b/sprint-b-18-template-observability-integration.md","item_id":"b-18","item_title":"Sprint b-18 — generated daemon observability integration","run_dir":"/Volumes/Extreme Pro/github/sc-runtime-worktrees/plan/spinoff-monty-observability/doc/plan/phase-current/qa-runs/final-scoped-20261030/anchor-rechecks","script":"/Volumes/Extreme Pro/github/sc-runtime-worktrees/plan/spinoff-monty-observability/.codex/skills/plan-anchoring/scripts/jev_judge.py","threshold":0.6}
}
```
