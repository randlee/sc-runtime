```json
{
  "schema_version": "1.0.0",
  "success": true,
  "canceled": false,
  "aborted_by": null,
  "data": {
    "gate": "plan",
    "item_id": "b-18",
    "run_id": "plan-20261030T073031Z-b-18",
    "run_path": "/Volumes/Extreme Pro/github/sc-runtime-worktrees/plan/spinoff-monty-observability/doc/plan/phase-current/qa-runs/final-scoped-20261030/anchor-rechecks/plan-20261030T073031Z-b-18.json",
    "dry_run": false,
    "reused_run": false,
    "pass": true,
    "failing": [],
    "errors": [],
    "excluded": [
      {
        "anchor_id": "ADR-RUN-0013",
        "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
      },
      {
        "anchor_id": "ADR-RUN-0305",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "ANC-027",
        "reason": "This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema."
      },
      {
        "anchor_id": "ANC-029",
        "reason": "b-18 forwards an opaque prebuilt registry; it changes neither CLI adapter, argv dispatch, nor adapter examples."
      },
      {
        "anchor_id": "ANC-030",
        "reason": "b-18 forwards an opaque prebuilt registry; it changes neither CLI adapter, argv dispatch, nor adapter examples."
      },
      {
        "anchor_id": "ANC-032",
        "reason": "This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema."
      },
      {
        "anchor_id": "ANC-042",
        "reason": "This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema."
      },
      {
        "anchor_id": "REQ-CRON-0001",
        "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
      },
      {
        "anchor_id": "REQ-CRON-0002",
        "reason": "This sprint does not change the cron expression parser or five-field schedule semantics."
      },
      {
        "anchor_id": "REQ-CRON-0004",
        "reason": "This sprint does not add the schedule table or change table creation, consumer-table migrations, or SqliteWriter-independent row writes."
      },
      {
        "anchor_id": "REQ-CRON-0005",
        "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
      },
      {
        "anchor_id": "REQ-RUN-0313",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0314",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0315",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0316",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0317",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0318",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0319",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0320",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0321",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0322",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0323",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0324",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0325",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0326",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0327",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0328",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0329",
        "reason": "This sprint does not change generated package names or their naming algorithm."
      },
      {
        "anchor_id": "REQ-RUN-0330",
        "reason": "This sprint does not add or generate database schema/types crates or relocate row structs."
      },
      {
        "anchor_id": "REQ-RUN-0331",
        "reason": "This sprint does not change the generated CLI/MCP/HTTP database command surface."
      }
    ],
    "results": [
      {
        "anchor_id": "ADR-RUN-0002",
        "source_type": "ADR",
        "source_ref": "ADR-RUN-0002",
        "statement": "sc-runtime is a cargo-generate template plus published library crates.",
        "quote": "sc-runtime is a cargo-generate template plus published library crates.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "requirements register",
        "anchor_version": 2,
        "deterministic_check": "Generated projects depend on the library crates by version, and template code is rendered into the project.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.99,
              "no": 0.01,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        },
        "min_confidence": 0.98,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6953,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20481,
        "item_shortened": false,
        "request_bytes": 23855
      },
      {
        "anchor_id": "ANC-028",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Embedding applications can register additional Monty host functions without modifying sc-cron.",
        "quote": "the primary requirement of being able to be extensible w/ other apps/calls is supported.",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "An integration test registers and invokes a consumer-defined host function.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The anchor does not apply to this item.",
              "unclear": "The item does not identify enough work to decide applicability.",
              "yes": "The anchor applies to this item."
            },
            "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item is silent, merely topical, or includes only the opposite behavior.",
              "unclear": "The text might include the requirement but is too indefinite to tell.",
              "yes": "The item explicitly plans or preserves the required behavior or boundary."
            },
            "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "The item can coexist with the anchor, including when silent.",
              "unclear": "The item leaves a potentially decisive choice unspecified.",
              "yes": "A stated plan would violate the anchor."
            },
            "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
            "type": "choice"
          }
        },
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.86,
            "probabilities": {
              "no": 0.09,
              "unclear": 0.0,
              "yes": 0.91
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "no": 0.96,
              "unclear": 0.01,
              "yes": 0.03
            }
          }
        },
        "min_confidence": 0.86,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6651,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20481,
        "item_shortened": false,
        "request_bytes": 22503
      },
      {
        "anchor_id": "ANC-031",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Every production release crate excludes sc-compose and ATM crate dependencies and Rust imports, enforced by boundary lint; test and benchmark references are permitted.",
        "quote": "sc-compose and atm crates should be blocked from any production release crate.  sc-compose and atm can be referenced for tests i.e. benchmark tests",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 3,
        "deterministic_check": "Boundary lint rejects production imports/dependencies while permitting test-only references.",
        "kind": "prohibition",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The anchor does not apply to this item.",
              "unclear": "The item does not identify enough work to decide applicability.",
              "yes": "The anchor applies to this item."
            },
            "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item is silent, merely topical, or includes only the opposite behavior.",
              "unclear": "The text might include the requirement but is too indefinite to tell.",
              "yes": "The item explicitly plans or preserves the required behavior or boundary."
            },
            "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "The item can coexist with the anchor, including when silent.",
              "unclear": "The item leaves a potentially decisive choice unspecified.",
              "yes": "A stated plan would violate the anchor."
            },
            "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
            "type": "choice"
          }
        },
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.86,
            "probabilities": {
              "no": 0.08,
              "unclear": 0.01,
              "yes": 0.91
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "no": 0.94,
              "unclear": 0.02,
              "yes": 0.04
            }
          }
        },
        "min_confidence": 0.86,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6666,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20481,
        "item_shortened": false,
        "request_bytes": 22606
      },
      {
        "anchor_id": "ANC-033",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "MVP executes application-supplied Monty scripts without script signing or a separate approval mechanism.",
        "quote": "for mvp this is not something available for consumers to do.",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 3,
        "deterministic_check": "MVP execution requires neither signatures nor approval configuration.",
        "kind": "prohibition",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "51ecb3cc44b751a0719c40aba67ba5d6ee1de19e77bdc74ffbf6b1265932fa10",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The item is about a different part of the system or a different activity, and completing it would neither follow nor break the anchor.",
              "unclear": "The item text is too vague to tell what part of the system it touches.",
              "yes": "The item plans, changes, or depends on the thing the anchor statement is about, directly or as a clear prerequisite."
            },
            "instructions": "The state holds one planning item (`item.title`, `item.text`) and one anchor: a directive the user stated verbatim in `anchor.statement`, with the area it governs in `anchor.scope`. Does the work described in `item.text` touch the subject that `anchor.statement` talks about? Judge overlap of subject matter only. Do not judge whether the item obeys the anchor.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item omits this complete rule or retains either gate.",
              "unclear": "The item names the gates but leaves whether either is mandatory unresolved.",
              "yes": "The item explicitly permits MVP execution without signatures and without separate approval."
            },
            "instructions": "Does item.text explicitly preserve BOTH parts of the MVP execution rule in anchor.statement: no mandatory script signing and no separate approval mechanism? A plan that retains either gate does not carry the complete rule forward.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "Nothing in the item text conflicts with the directive, whether or not the directive is mentioned.",
              "unclear": "The item text is ambiguous enough that it might or might not conflict with the directive.",
              "yes": "The item text states a plan, approach, or decision that cannot be reconciled with the directive in the anchor statement."
            },
            "instructions": "Does `item.text` propose doing something that `anchor.statement` rules out, or propose a different approach than the one `anchor.statement` requires? Examples of contradiction: the anchor says to start from an existing implementation and the item plans a fresh implementation; the anchor forbids a dependency and the item adds it; the anchor fixes an order of work and the item reverses it. Silence about the directive is not a contradiction. Judge conflict only.",
            "type": "choice"
          }
        },
        "near_threshold": true,
        "confirmed": true,
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.88,
            "probabilities": {
              "no": 0.08,
              "unclear": 0.0,
              "yes": 0.92
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "no": 0.97,
              "unclear": 0.0,
              "yes": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.66,
            "probabilities": {
              "no": 0.77,
              "unclear": 0.04,
              "yes": 0.19
            }
          }
        },
        "min_confidence": 0.66,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6867,
          "output_tokens": 117
        },
        "attempts": 2,
        "item_chars_sent": 20481,
        "item_shortened": false,
        "request_bytes": 23509
      },
      {
        "anchor_id": "ANC-034",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Python and Monty hooks use the same schedule-environment configuration and resolution rules.",
        "quote": "python/monty having consistent settings would be least confusing",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "The same environment cases produce equivalent Python and Monty results.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The anchor does not apply to this item.",
              "unclear": "The item does not identify enough work to decide applicability.",
              "yes": "The anchor applies to this item."
            },
            "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item is silent, merely topical, or includes only the opposite behavior.",
              "unclear": "The text might include the requirement but is too indefinite to tell.",
              "yes": "The item explicitly plans or preserves the required behavior or boundary."
            },
            "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "The item can coexist with the anchor, including when silent.",
              "unclear": "The item leaves a potentially decisive choice unspecified.",
              "yes": "A stated plan would violate the anchor."
            },
            "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
            "type": "choice"
          }
        },
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.91,
            "probabilities": {
              "no": 0.06,
              "unclear": 0.0,
              "yes": 0.94
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.98,
              "unclear": 0.01,
              "yes": 0.01
            }
          }
        },
        "min_confidence": 0.91,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6652,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20481,
        "item_shortened": false,
        "request_bytes": 22502
      },
      {
        "anchor_id": "ANC-035",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Hooks inherit daemon-process environment values only through variable names explicitly allowed by daemon configuration.",
        "quote": "whitelisting api keys globally (by name) in config file (this is really a daemon scope decision)",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "An allowed daemon value is delivered and an unlisted value is absent.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f826ddd4cc1178bb42b5729fb97e85e6b3b2ab65498cde66ea0ee1dfa98a0a26",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The work is independent of the governed subject.",
              "unclear": "The work area is too vague to determine applicability.",
              "yes": "The work touches the governed subject directly or as a clear prerequisite."
            },
            "instructions": "Does item.text plan work on the governed activity, component, or artifact named by anchor.statement and anchor.scope? Judge applicability only, including dependencies.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item omits the obligation or describes only a conflicting action.",
              "unclear": "The item gestures at the obligation but does not settle whether it is included.",
              "yes": "The required action or constraint is explicitly included."
            },
            "instructions": "Does item.text expressly include the specific obligation in anchor.statement as a planned step or constraint? A subject mention, silence, or opposing action does not satisfy the obligation.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "No incompatible behavior is proposed.",
              "unclear": "A possible conflict depends on an unresolved detail.",
              "yes": "The item commits to an incompatible behavior or boundary."
            },
            "instructions": "Does item.text commit to behavior that cannot coexist with anchor.statement? Silence, topical mention, and an expressly permitted exception are not conflicts.",
            "type": "choice"
          }
        },
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.86,
            "probabilities": {
              "no": 0.09,
              "unclear": 0.0,
              "yes": 0.91
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          }
        },
        "min_confidence": 0.86,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6674,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20481,
        "item_shortened": false,
        "request_bytes": 22669
      },
      {
        "anchor_id": "ANC-036",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Each schedule can explicitly set or clear its own environment variables.",
        "quote": "having each entry having the ability to set or clear specific environment variables",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "Two schedules set distinct identities and clearing removes a prior value.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The anchor does not apply to this item.",
              "unclear": "The item does not identify enough work to decide applicability.",
              "yes": "The anchor applies to this item."
            },
            "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item is silent, merely topical, or includes only the opposite behavior.",
              "unclear": "The text might include the requirement but is too indefinite to tell.",
              "yes": "The item explicitly plans or preserves the required behavior or boundary."
            },
            "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "The item can coexist with the anchor, including when silent.",
              "unclear": "The item leaves a potentially decisive choice unspecified.",
              "yes": "A stated plan would violate the anchor."
            },
            "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
            "type": "choice"
          }
        },
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.91,
            "probabilities": {
              "no": 0.06,
              "unclear": 0.0,
              "yes": 0.94
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.94,
            "probabilities": {
              "no": 0.04,
              "unclear": 0.0,
              "yes": 0.96
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "no": 0.95,
              "unclear": 0.01,
              "yes": 0.04
            }
          }
        },
        "min_confidence": 0.91,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6645,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20481,
        "item_shortened": false,
        "request_bytes": 22492
      },
      {
        "anchor_id": "ANC-037",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Schedule creation and updates never implicitly capture environment values from the caller or daemon process.",
        "quote": "Never capture or persist inherited host values accidentally",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 3,
        "deterministic_check": "Ambient canaries are absent from persisted rows without explicit set input.",
        "kind": "prohibition",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f826ddd4cc1178bb42b5729fb97e85e6b3b2ab65498cde66ea0ee1dfa98a0a26",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The work is independent of the governed subject.",
              "unclear": "The work area is too vague to determine applicability.",
              "yes": "The work touches the governed subject directly or as a clear prerequisite."
            },
            "instructions": "Does item.text plan work on the governed activity, component, or artifact named by anchor.statement and anchor.scope? Judge applicability only, including dependencies.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item omits the obligation or describes only a conflicting action.",
              "unclear": "The item gestures at the obligation but does not settle whether it is included.",
              "yes": "The required action or constraint is explicitly included."
            },
            "instructions": "Does item.text expressly include the specific obligation in anchor.statement as a planned step or constraint? A subject mention, silence, or opposing action does not satisfy the obligation.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "No incompatible behavior is proposed.",
              "unclear": "A possible conflict depends on an unresolved detail.",
              "yes": "The item commits to an incompatible behavior or boundary."
            },
            "instructions": "Does item.text commit to behavior that cannot coexist with anchor.statement? Silence, topical mention, and an expressly permitted exception are not conflicts.",
            "type": "choice"
          }
        },
        "near_threshold": true,
        "confirmed": true,
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.85,
            "probabilities": {
              "no": 0.1,
              "unclear": 0.0,
              "yes": 0.9
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.33,
            "probabilities": {
              "no": 0.55,
              "unclear": 0.03,
              "yes": 0.42
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.66,
            "probabilities": {
              "no": 0.77,
              "unclear": 0.02,
              "yes": 0.21
            }
          }
        },
        "min_confidence": 0.66,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6675,
          "output_tokens": 117
        },
        "attempts": 2,
        "item_chars_sent": 20481,
        "item_shortened": false,
        "request_bytes": 22647
      },
      {
        "anchor_id": "ANC-038",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "The schedule registry permits deliberately supplied environment values as plaintext configuration.",
        "quote": "why can we never add values?  all environment variables are not api keys?",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "An explicit set value round-trips through the registry.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "e9965576f4baeafd046cab1602c342cfba185667897278270cdc80eb069acb36",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The item is about a different part of the system or a different activity, and completing it would neither follow nor break the anchor.",
              "unclear": "The item text is too vague to tell what part of the system it touches.",
              "yes": "The item plans, changes, or depends on the thing the anchor statement is about, directly or as a clear prerequisite."
            },
            "instructions": "The state holds one planning item (`item.title`, `item.text`) and one anchor: a directive the user stated verbatim in `anchor.statement`, with the area it governs in `anchor.scope`. Does the work described in `item.text` touch the subject that `anchor.statement` talks about? Judge overlap of subject matter only. Do not judge whether the item obeys the anchor.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The plan is silent or denies any permitted class, even if it mentions plaintext.",
              "unclear": "The plan names plaintext values but leaves the allowed class unresolved.",
              "yes": "The plan explicitly preserves the full permitted class of deliberate plaintext set values."
            },
            "instructions": "Does item.text expressly preserve the schedule registry permission to accept every deliberately supplied plaintext environment value, including secret and nonsecret values? Merely mentioning plaintext while banning a value class does not carry the permission forward.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "No incompatible restriction is planned.",
              "unclear": "The planned restriction or its applicability to deliberate set values is unresolved.",
              "yes": "The plan denies or narrows the anchor-permitted plaintext set-value capability."
            },
            "instructions": "Does item.text prohibit or narrow a class of deliberately supplied plaintext environment values that anchor.statement permits in the schedule registry? Treat an explicit secret-only ban as a conflict; silence and permitted handling are not conflicts.",
            "type": "choice"
          }
        },
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.94,
            "probabilities": {
              "no": 0.03,
              "unclear": 0.01,
              "yes": 0.96
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "no": 0.95,
              "unclear": 0.0,
              "yes": 0.05
            }
          }
        },
        "min_confidence": 0.92,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6787,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20481,
        "item_shortened": false,
        "request_bytes": 23240
      },
      {
        "anchor_id": "ANC-039",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Schedules can resolve environment values through an application-provided resolver for opaque references.",
        "quote": "I also like allowing this:   \"OTHER_API_KEY\": { \"reference\": \"keychain://agents/planner-7/api-key\" }",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "A consumer resolver supplies a referenced value without persisting the result.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The anchor does not apply to this item.",
              "unclear": "The item does not identify enough work to decide applicability.",
              "yes": "The anchor applies to this item."
            },
            "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item is silent, merely topical, or includes only the opposite behavior.",
              "unclear": "The text might include the requirement but is too indefinite to tell.",
              "yes": "The item explicitly plans or preserves the required behavior or boundary."
            },
            "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "The item can coexist with the anchor, including when silent.",
              "unclear": "The item leaves a potentially decisive choice unspecified.",
              "yes": "A stated plan would violate the anchor."
            },
            "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
            "type": "choice"
          }
        },
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.94,
            "probabilities": {
              "no": 0.04,
              "unclear": 0.0,
              "yes": 0.96
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.94,
            "probabilities": {
              "no": 0.04,
              "unclear": 0.0,
              "yes": 0.96
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "no": 0.95,
              "unclear": 0.01,
              "yes": 0.04
            }
          }
        },
        "min_confidence": 0.92,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6648,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20481,
        "item_shortened": false,
        "request_bytes": 22510
      },
      {
        "anchor_id": "ANC-040",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Schedules can load environment variables from full-path .env files.",
        "quote": "Another useful way to specify would be loading from a full-path .env file.",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "An authorized absolute dotenv file supplies hook values.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f826ddd4cc1178bb42b5729fb97e85e6b3b2ab65498cde66ea0ee1dfa98a0a26",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The work is independent of the governed subject.",
              "unclear": "The work area is too vague to determine applicability.",
              "yes": "The work touches the governed subject directly or as a clear prerequisite."
            },
            "instructions": "Does item.text plan work on the governed activity, component, or artifact named by anchor.statement and anchor.scope? Judge applicability only, including dependencies.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item omits the obligation or describes only a conflicting action.",
              "unclear": "The item gestures at the obligation but does not settle whether it is included.",
              "yes": "The required action or constraint is explicitly included."
            },
            "instructions": "Does item.text expressly include the specific obligation in anchor.statement as a planned step or constraint? A subject mention, silence, or opposing action does not satisfy the obligation.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "No incompatible behavior is proposed.",
              "unclear": "A possible conflict depends on an unresolved detail.",
              "yes": "The item commits to an incompatible behavior or boundary."
            },
            "instructions": "Does item.text commit to behavior that cannot coexist with anchor.statement? Silence, topical mention, and an expressly permitted exception are not conflicts.",
            "type": "choice"
          }
        },
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.02,
              "unclear": 0.0,
              "yes": 0.98
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.76,
            "probabilities": {
              "no": 0.15,
              "unclear": 0.01,
              "yes": 0.84
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.86,
            "probabilities": {
              "no": 0.91,
              "unclear": 0.01,
              "yes": 0.08
            }
          }
        },
        "min_confidence": 0.76,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6672,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20481,
        "item_shortened": false,
        "request_bytes": 22606
      },
      {
        "anchor_id": "ANC-041",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Monty scripts can read their configured environment during source initialization, before hook functions run.",
        "quote": "there should also be the ability to set environment variables in a monty script before it runs.",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "A top-level getenv reads the configured snapshot before cron_stop or cron_tick.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f826ddd4cc1178bb42b5729fb97e85e6b3b2ab65498cde66ea0ee1dfa98a0a26",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The work is independent of the governed subject.",
              "unclear": "The work area is too vague to determine applicability.",
              "yes": "The work touches the governed subject directly or as a clear prerequisite."
            },
            "instructions": "Does item.text plan work on the governed activity, component, or artifact named by anchor.statement and anchor.scope? Judge applicability only, including dependencies.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item omits the obligation or describes only a conflicting action.",
              "unclear": "The item gestures at the obligation but does not settle whether it is included.",
              "yes": "The required action or constraint is explicitly included."
            },
            "instructions": "Does item.text expressly include the specific obligation in anchor.statement as a planned step or constraint? A subject mention, silence, or opposing action does not satisfy the obligation.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "No incompatible behavior is proposed.",
              "unclear": "A possible conflict depends on an unresolved detail.",
              "yes": "The item commits to an incompatible behavior or boundary."
            },
            "instructions": "Does item.text commit to behavior that cannot coexist with anchor.statement? Silence, topical mention, and an expressly permitted exception are not conflicts.",
            "type": "choice"
          }
        },
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.83,
            "probabilities": {
              "no": 0.11,
              "unclear": 0.0,
              "yes": 0.89
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.02,
              "unclear": 0.0,
              "yes": 0.98
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.99,
              "unclear": 0.0,
              "yes": 0.01
            }
          }
        },
        "min_confidence": 0.83,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6676,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20481,
        "item_shortened": false,
        "request_bytes": 22654
      },
      {
        "anchor_id": "REQ-CRON-0003",
        "source_type": "REQ",
        "source_ref": "REQ-CRON-0003",
        "statement": "sc-cron must run application-defined Rust, Python, and optional Monty jobs; applications can extend Monty host calls, including sc_compose_run and atm_run CLI adapters, without changing sc-cron.",
        "quote": "A schedule row names either an in-process Rust job or a Python module. For Python, the crate runs python3 <module> cron.tick or python3 <module> cron.stop and writes one JSON object to stdin. The crate exposes no HTTP route, MCP tool, or binary.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "Historical register quote retained as immutable provenance. Current statement follows the amended REQ-CRON-0003 authority and owner-approved Phase B continuation ANC-027 through ANC-042 (2026-10-29); the historical quote is not the current normative contract.",
        "anchor_version": 5,
        "deterministic_check": "Host registry integration tests invoke custom, sc-compose, and ATM functions through one extension interface.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.99,
              "no": 0.01,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.99,
              "no": 0.01,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.03,
              "no": 0.97,
              "unclear": 0.0
            }
          }
        },
        "min_confidence": 0.96,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6981,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20481,
        "item_shortened": false,
        "request_bytes": 23966
      },
      {
        "anchor_id": "REQ-RUN-0503",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0503",
        "statement": "A project generated by just new passes lint, test, and both builds with no file edited.",
        "quote": "A project generated by just new passes lint, test, and both builds with no file edited.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "requirements register",
        "anchor_version": 2,
        "deterministic_check": "just new on the sqlite fixture exits 0, and just lint, just test, just build-cli, and just build-daemon exit 0 with no file edited.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.97,
              "no": 0.03,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.04,
              "no": 0.96,
              "unclear": 0.0
            }
          }
        },
        "min_confidence": 0.94,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6958,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20481,
        "item_shortened": false,
        "request_bytes": 23874
      },
      {
        "anchor_id": "ADR-RUN-0013",
        "source_type": "ADR",
        "source_ref": "ADR-RUN-0013",
        "statement": "sc-cron is an optional general-purpose SQLite cron library with Rust/Python/Monty hooks, application-owned host registration, and no MVP script signing or separate approval mechanism.",
        "quote": "sc-cron is an optional SQLite cron crate. A normal schedule string is five fields, minute first. The hook target is a Rust function or a Python module run as python3 <module> cron.tick or cron.stop with one JSON object on stdin.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "Historical register quote retained as immutable provenance. Current statement follows the amended ADR-RUN-0013 authority and owner-approved Phase B continuation ANC-027 through ANC-042 (2026-10-29); the historical quote is not the current normative contract.",
        "anchor_version": 5,
        "deterministic_check": "The optional library provides application-defined job and Monty registration tests, and no MVP signing configuration.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures.",
        "attempts": 0
      },
      {
        "anchor_id": "ADR-RUN-0305",
        "source_type": "ADR",
        "source_ref": "ADR-RUN-0305",
        "statement": "SQLite and Postgres meet in an adaptor crate generated into the consumer repository.",
        "quote": "SQLite and Postgres meet in an adaptor crate generated into the consumer repository.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "docs/architecture.md contains ADR-RUN-0305.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "ANC-027",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "sc-cron is a general-purpose cron library supporting application-defined jobs.",
        "quote": "sc-cron is a general-purpose cron library.",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "A consumer can schedule an application-defined job without a tool-specific payload.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema.",
        "attempts": 0
      },
      {
        "anchor_id": "ANC-029",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "The sc_compose_run integration supports any sc-compose command/subcommand supplied by an application script.",
        "quote": "sc_compose_run (any subcommand) would be a useful working example for showing how to use sc-cron",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "Argument-forwarding tests cover render and non-render subcommands.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "b-18 forwards an opaque prebuilt registry; it changes neither CLI adapter, argv dispatch, nor adapter examples."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: b-18 forwards an opaque prebuilt registry; it changes neither CLI adapter, argv dispatch, nor adapter examples.",
        "attempts": 0
      },
      {
        "anchor_id": "ANC-030",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Phase B provides an atm_run host integration supporting any ATM CLI command/subcommand through the same extension interface used by sc_compose_run.",
        "quote": "i am in agreement.",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Owner approved the preceding proposal: \"Phase B provides an atm_run host integration supporting any ATM CLI command/subcommand through the same extension interface used by sc_compose_run.\" The immutable quote \"i am in agreement.\" is the owner's response approving that exact statement.",
        "anchor_version": 3,
        "deterministic_check": "An ATM executable fixture is invoked through the same registry as sc_compose_run.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "b-18 forwards an opaque prebuilt registry; it changes neither CLI adapter, argv dispatch, nor adapter examples."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: b-18 forwards an opaque prebuilt registry; it changes neither CLI adapter, argv dispatch, nor adapter examples.",
        "attempts": 0
      },
      {
        "anchor_id": "ANC-032",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "render_template is not required by the sc-cron product contract.",
        "quote": "render_template is not a product requirement",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 3,
        "deterministic_check": "Product requirements and acceptance do not require render_template.",
        "kind": "prohibition",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema.",
        "attempts": 0
      },
      {
        "anchor_id": "ANC-042",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "The first released schedule schema establishes one baseline without requiring migrations among unreleased development schemas.",
        "quote": "i don't know why we are on schema v4 when we haven't even released binaries yet.",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "First-release schema validation does not require a v1-v4 development migration ladder.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-CRON-0001",
        "source_type": "REQ",
        "source_ref": "REQ-CRON-0001",
        "statement": "sc-cron must remain an optional workspace crate; the generated daemon may enable it through cron/monty features while sc-runtime remains independent of sc-cron.",
        "quote": "crates/sc-cron is a workspace member. It depends on no other workspace crate. The template does not name it. The sc-runtime library crate does not name it.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "Historical register quote retained as immutable provenance. Current statement follows the amended REQ-CRON-0001 authority and owner-approved Phase B continuation ANC-027 through ANC-042 (2026-10-29); the historical quote is not the current normative contract.",
        "anchor_version": 5,
        "deterministic_check": "Cargo manifests keep sc-cron optional in generated daemons and absent from sc-runtime dependencies.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-CRON-0002",
        "source_type": "REQ",
        "source_ref": "REQ-CRON-0002",
        "statement": "A sc-cron schedule is a normal crontab string of five fields: minute, hour, day of month, month, and day of week.",
        "quote": "CronExpr::parse of */5 * * * * succeeds and means every fifth minute. CronExpr::parse of 0 */5 * * * * succeeds and means second 0 of every fifth minute. CronExpr::parse of @hourly succeeds.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "requirements register",
        "anchor_version": 3,
        "deterministic_check": "A test expects parsing */5 * * * * to mean every fifth minute.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not change the cron expression parser or five-field schedule semantics."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not change the cron expression parser or five-field schedule semantics.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-CRON-0004",
        "source_type": "REQ",
        "source_ref": "REQ-CRON-0004",
        "statement": "The sc-cron crate creates one schedule table. A test writes a row without constructing SqliteWriter. The crate does not migrate the consumer's other tables.",
        "quote": "The sc-cron crate creates one schedule table. A test writes a row without constructing SqliteWriter. The crate does not migrate the consumer's other tables.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "requirements register",
        "anchor_version": 2,
        "deterministic_check": "A test writes a schedule row without constructing SqliteWriter.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add the schedule table or change table creation, consumer-table migrations, or SqliteWriter-independent row writes."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add the schedule table or change table creation, consumer-table migrations, or SqliteWriter-independent row writes.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-CRON-0005",
        "source_type": "REQ",
        "source_ref": "REQ-CRON-0005",
        "statement": "Fallible public library entry points in sc-cron must return CronError.",
        "quote": "Fallible public functions in sc-cron return CronError.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "requirements register",
        "anchor_version": 5,
        "deterministic_check": "The public error type in crates/sc-cron is CronError.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0313",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0313",
        "statement": "The relationship between the local SQLite store and the remote Postgres or SQL store is defined in an adaptor crate on the consumer repository.",
        "quote": "The relationship between the local SQLite store and the remote Postgres or SQL store is defined in an adaptor crate on the consumer repository.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "A generated repository contains an adaptor crate that names both stores.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0314",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0314",
        "statement": "The copy adaptor is a local SQLite database with the remote schema, for faster or offline access.",
        "quote": "The copy adaptor is a local SQLite database with the remote schema, for faster or offline access.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "A generated copy adaptor creates the shared remote tables in SQLite.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0315",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0315",
        "statement": "The host-aggregate adaptor is one SQLite database for this host and a Postgres database that aggregates many hosts.",
        "quote": "The host-aggregate adaptor is one SQLite database for this host and a Postgres database that aggregates many hosts.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "A generated host-aggregate adaptor documents one SQLite database per host and one Postgres aggregate.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0316",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0316",
        "statement": "The consumer repository defines the rollup from host rows into the Postgres aggregate.",
        "quote": "The consumer repository defines the rollup from host rows into the Postgres aggregate.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "The host-aggregate adaptor has a consumer-owned function that maps host rows into the Postgres aggregate.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0317",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0317",
        "statement": "Adaptor Rust code and models in a new repository are generated by the command just new (scripts/new_project.py).",
        "quote": "Adaptor Rust code and models in a new repository are generated by the command just new (scripts/new_project.py).",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "just new writes the adaptor crate and its models into the new repository.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0318",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0318",
        "statement": "The library crate named sc-runtime does not generate adaptor code.",
        "quote": "The library crate named sc-runtime does not generate adaptor code.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "crates/sc-runtime contains no generator.",
        "kind": "prohibition",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0319",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0319",
        "statement": "Generation flags name tables and columns that exist on only one of the two stores. A skipped table may be the SQLite table or the SQL-server table.",
        "quote": "Generation flags name tables and columns that exist on only one of the two stores.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 3,
        "deterministic_check": "Generation input can name a SQLite-only table, a SQL-server-only table, and a column that exists on only one side.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0320",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0320",
        "statement": "Every consumer repository uses the same generated implementation of the copy pattern and the same generated implementation of the host-aggregate pattern.",
        "quote": "Every consumer repository uses the same generated implementation of the copy pattern and the same generated implementation of the host-aggregate pattern.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "Two generated repositories that select the same pattern contain the same adaptor implementation.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0321",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0321",
        "statement": "Each database engine's SQL is in that engine's store crate.",
        "quote": "Generated SQLite code and generated Postgres code are separate files.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 3,
        "deterministic_check": "store-sqlite contains no Postgres SQL, and store-postgres contains no SQLite SQL.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0322",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0322",
        "statement": "An adaptor that is neither the copy pattern nor the host-aggregate pattern is written by the consumer from the store building blocks.",
        "quote": "An adaptor that is neither the copy pattern nor the host-aggregate pattern is written by the consumer from the store building blocks.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 3,
        "deterministic_check": "A third adaptor is a file the consumer wrote.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0323",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0323",
        "statement": "Store synchronization is scheduled by the consuming application. The adaptor starts no timer.",
        "quote": "Store synchronization is scheduled by the consuming application. The adaptor starts no timer.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "The adaptor crate starts no timer. A schedule is registered by application code.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0324",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0324",
        "statement": "The consumer adaptor moves rows between the local store and the remote store.",
        "quote": "The consumer adaptor moves rows between the local store and the remote store.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "The adaptor crate contains the copy from one store to the other.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0325",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0325",
        "statement": "The sc-runtime crates do not move rows between stores.",
        "quote": "The sc-runtime crates do not move rows between stores.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "crates/ contains no store-to-store copy.",
        "kind": "prohibition",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0326",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0326",
        "statement": "A new application is created with no database, with SQLite only, with one sqlx SQL engine only, or with SQLite plus one sqlx SQL engine.",
        "quote": "A new application is created with no database, with SQLite only, with one sqlx SQL engine only, or with SQLite plus one sqlx SQL engine.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 3,
        "deterministic_check": "wizard/answers.schema.json accepts no database, SQLite only, one sqlx SQL engine, and SQLite plus one sqlx SQL engine.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0327",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0327",
        "statement": "Two stores in one application use the same schema or a similar schema.",
        "quote": "Two stores in one application use the same schema or a similar schema.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "The copy pattern uses the same schema on both stores. The host-aggregate pattern uses a similar schema.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0328",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0328",
        "statement": "Two stores in one application use one shared trait or a different trait per store.",
        "quote": "Two stores in one application use one shared trait or a different trait per store.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "A generated pair names one trait that both stores implement, or a trait for each store.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0329",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0329",
        "statement": "A generated crate's package name is the project name, a hyphen, and its role.",
        "quote": "A generated crate's package name is the project name, a hyphen, and its role. The adaptor depends on <project>-types and <project>-schema.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 4,
        "deterministic_check": "Two projects with different names produce no package name in common.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not change generated package names or their naming algorithm."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not change generated package names or their naming algorithm.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0330",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0330",
        "statement": "Row type structs are in the schema crate. The types crate is for non-database types.",
        "quote": "Row type structs are in the schema crate. The types crate is for non-database types.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "The schema crate contains the row structs. The types crate contains no database row struct. The adaptor depends on the schema crate.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not add or generate database schema/types crates or relocate row structs."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add or generate database schema/types crates or relocate row structs.",
        "attempts": 0
      },
      {
        "anchor_id": "REQ-RUN-0331",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0331",
        "statement": "The template ships general database commands on the CLI, MCP, and HTTP, including delete row <table> <id>. The consumer can disable that surface.",
        "quote": "The template ships general database commands on the CLI, MCP, and HTTP, including delete row <table> <id>. The consumer can disable that surface.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "requirements register",
        "anchor_version": 2,
        "deterministic_check": "A generated project with a store registers delete row <table> <id> on the CLI, MCP, and HTTP, and a flag removes those commands.",
        "kind": "directive",
        "leaning": null,
        "verdict": "excluded",
        "answers": null,
        "min_confidence": null,
        "exclusion": {
          "item": "b-18",
          "reason": "This sprint does not change the generated CLI/MCP/HTTP database command surface."
        },
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not change the generated CLI/MCP/HTTP database command surface.",
        "attempts": 0
      }
    ],
    "overrides_applied": [
      "ANC-028",
      "ANC-031",
      "ANC-033",
      "ANC-034",
      "ANC-035",
      "ANC-036",
      "ANC-037",
      "ANC-038",
      "ANC-039",
      "ANC-040",
      "ANC-041"
    ],
    "item_truncated": false,
    "shortened": [],
    "report_markdown": "## Anchor gate: plan · b-18 - Sprint b-18 — generated daemon observability integration\n\nRun `plan-20261030T073031Z-b-18`, model `jev-1.14.0`, threshold 0.6. Counts: satisfied 14, excluded 30.\n\n> **b-18 · ADR-RUN-0013 · excluded** Anchor: sc-cron is an optional general-purpose SQLite cron library with Rust/Python/Monty hooks, application-owned host registration, and no MVP script signing or separate approval mechanism. Not judged: This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures.\n\n> **b-18 · ADR-RUN-0305 · excluded** Anchor: SQLite and Postgres meet in an adaptor crate generated into the consumer repository. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · ANC-027 · excluded** Anchor: sc-cron is a general-purpose cron library supporting application-defined jobs. Not judged: This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema.\n\n> **b-18 · ANC-029 · excluded** Anchor: The sc_compose_run integration supports any sc-compose command/subcommand supplied by an application script. Not judged: b-18 forwards an opaque prebuilt registry; it changes neither CLI adapter, argv dispatch, nor adapter examples.\n\n> **b-18 · ANC-030 · excluded** Anchor: Phase B provides an atm_run host integration supporting any ATM CLI command/subcommand through the same extension interface used by sc_compose_run. Not judged: b-18 forwards an opaque prebuilt registry; it changes neither CLI adapter, argv dispatch, nor adapter examples.\n\n> **b-18 · ANC-032 · excluded** Anchor: render_template is not required by the sc-cron product contract. Not judged: This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema.\n\n> **b-18 · ANC-042 · excluded** Anchor: The first released schedule schema establishes one baseline without requiring migrations among unreleased development schemas. Not judged: This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema.\n\n> **b-18 · REQ-CRON-0001 · excluded** Anchor: sc-cron must remain an optional workspace crate; the generated daemon may enable it through cron/monty features while sc-runtime remains independent of sc-cron. Not judged: This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures.\n\n> **b-18 · REQ-CRON-0002 · excluded** Anchor: A sc-cron schedule is a normal crontab string of five fields: minute, hour, day of month, month, and day of week. Not judged: This sprint does not change the cron expression parser or five-field schedule semantics.\n\n> **b-18 · REQ-CRON-0004 · excluded** Anchor: The sc-cron crate creates one schedule table. A test writes a row without constructing SqliteWriter. The crate does not migrate the consumer's other tables. Not judged: This sprint does not add the schedule table or change table creation, consumer-table migrations, or SqliteWriter-independent row writes.\n\n> **b-18 · REQ-CRON-0005 · excluded** Anchor: Fallible public library entry points in sc-cron must return CronError. Not judged: This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures.\n\n> **b-18 · REQ-RUN-0313 · excluded** Anchor: The relationship between the local SQLite store and the remote Postgres or SQL store is defined in an adaptor crate on the consumer repository. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0314 · excluded** Anchor: The copy adaptor is a local SQLite database with the remote schema, for faster or offline access. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0315 · excluded** Anchor: The host-aggregate adaptor is one SQLite database for this host and a Postgres database that aggregates many hosts. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0316 · excluded** Anchor: The consumer repository defines the rollup from host rows into the Postgres aggregate. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0317 · excluded** Anchor: Adaptor Rust code and models in a new repository are generated by the command just new (scripts/new_project.py). Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0318 · excluded** Anchor: The library crate named sc-runtime does not generate adaptor code. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0319 · excluded** Anchor: Generation flags name tables and columns that exist on only one of the two stores. A skipped table may be the SQLite table or the SQL-server table. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0320 · excluded** Anchor: Every consumer repository uses the same generated implementation of the copy pattern and the same generated implementation of the host-aggregate pattern. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0321 · excluded** Anchor: Each database engine's SQL is in that engine's store crate. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0322 · excluded** Anchor: An adaptor that is neither the copy pattern nor the host-aggregate pattern is written by the consumer from the store building blocks. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0323 · excluded** Anchor: Store synchronization is scheduled by the consuming application. The adaptor starts no timer. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0324 · excluded** Anchor: The consumer adaptor moves rows between the local store and the remote store. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0325 · excluded** Anchor: The sc-runtime crates do not move rows between stores. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0326 · excluded** Anchor: A new application is created with no database, with SQLite only, with one sqlx SQL engine only, or with SQLite plus one sqlx SQL engine. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0327 · excluded** Anchor: Two stores in one application use the same schema or a similar schema. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0328 · excluded** Anchor: Two stores in one application use one shared trait or a different trait per store. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-18 · REQ-RUN-0329 · excluded** Anchor: A generated crate's package name is the project name, a hyphen, and its role. Not judged: This sprint does not change generated package names or their naming algorithm.\n\n> **b-18 · REQ-RUN-0330 · excluded** Anchor: Row type structs are in the schema crate. The types crate is for non-database types. Not judged: This sprint does not add or generate database schema/types crates or relocate row structs.\n\n> **b-18 · REQ-RUN-0331 · excluded** Anchor: The template ships general database commands on the CLI, MCP, and HTTP, including delete row <table> <id>. The consumer can disable that surface. Not judged: This sprint does not change the generated CLI/MCP/HTTP database command surface.\n\nAll judged anchors are satisfied or not applicable.\n\n",
    "raw_run": {
      "schema": "plan-anchoring/run/1",
      "run_id": "plan-20261030T073031Z-b-18",
      "gate": "plan",
      "created_at": "2026-10-30T07:30:31+00:00",
      "anchors_path": "/Volumes/Extreme Pro/github/sc-runtime-worktrees/plan/spinoff-monty-observability/doc/plan/phase-current/anchors.json",
      "plan": "phase-current",
      "item": {
        "id": "b-18",
        "title": "Sprint b-18 — generated daemon observability integration",
        "source": "/Volumes/Extreme Pro/github/sc-runtime-worktrees/plan/spinoff-monty-observability/docs/plans/phase-b/sprint-b-18-template-observability-integration.md",
        "chars": 20481,
        "truncated": false,
        "chars_before_reduction": 24176,
        "code_reduced": {
          "blocks": 3,
          "lines": 64
        }
      },
      "model_requested": "jev-latest",
      "model_answered": "jev-1.14.0",
      "threshold": 0.6,
      "max_request_bytes": 24000,
      "min_item_chars": 2000,
      "dry_run": false,
      "fixture": false,
      "results": [
        {
          "anchor_id": "ADR-RUN-0002",
          "source_type": "ADR",
          "source_ref": "ADR-RUN-0002",
          "statement": "sc-runtime is a cargo-generate template plus published library crates.",
          "quote": "sc-runtime is a cargo-generate template plus published library crates.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "requirements register",
          "anchor_version": 2,
          "deterministic_check": "Generated projects depend on the library crates by version, and template code is rendered into the project.",
          "kind": "directive",
          "leaning": "satisfied",
          "question_set": {
            "gate": "plan",
            "version": 1,
            "overridden": false
          },
          "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
          "verdict": "satisfied",
          "answers": {
            "relevant": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.98,
              "probabilities": {
                "yes": 0.99,
                "no": 0.01,
                "unclear": 0.0
              }
            },
            "addressed": {
              "type": "choice",
              "choice": "yes",
              "confidence": 1.0,
              "probabilities": {
                "yes": 1.0,
                "no": 0.0,
                "unclear": 0.0
              }
            },
            "contradicted": {
              "type": "choice",
              "choice": "no",
              "confidence": 0.98,
              "probabilities": {
                "yes": 0.01,
                "no": 0.99,
                "unclear": 0.0
              }
            }
          },
          "min_confidence": 0.98,
          "explanation": "The directive is carried forward.",
          "usage": {
            "input_tokens": 6953,
            "output_tokens": 117
          },
          "attempts": 1,
          "item_chars_sent": 20481,
          "item_shortened": false,
          "request_bytes": 23855
        },
        {
          "anchor_id": "ANC-028",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "Embedding applications can register additional Monty host functions without modifying sc-cron.",
          "quote": "the primary requirement of being able to be extensible w/ other apps/calls is supported.",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
          "anchor_version": 2,
          "deterministic_check": "An integration test registers and invokes a consumer-defined host function.",
          "kind": "directive",
          "leaning": "satisfied",
          "question_set": {
            "gate": "plan",
            "version": 1,
            "overridden": true
          },
          "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
          "questions": {
            "relevant": {
              "criteria": {
                "no": "The anchor does not apply to this item.",
                "unclear": "The item does not identify enough work to decide applicability.",
                "yes": "The anchor applies to this item."
              },
              "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
              "type": "choice"
            },
            "addressed": {
              "criteria": {
                "no": "The item is silent, merely topical, or includes only the opposite behavior.",
                "unclear": "The text might include the requirement but is too indefinite to tell.",
                "yes": "The item explicitly plans or preserves the required behavior or boundary."
              },
              "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
              "type": "choice"
            },
            "contradicted": {
              "criteria": {
                "no": "The item can coexist with the anchor, including when silent.",
                "unclear": "The item leaves a potentially decisive choice unspecified.",
                "yes": "A stated plan would violate the anchor."
              },
              "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
              "type": "choice"
            }
          },
          "verdict": "satisfied",
          "answers": {
            "relevant": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.86,
              "probabilities": {
                "no": 0.09,
                "unclear": 0.0,
                "yes": 0.91
              }
            },
            "addressed": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.98,
              "probabilities": {
                "no": 0.01,
                "unclear": 0.0,
                "yes": 0.99
              }
            },
            "contradicted": {
              "type": "choice",
              "choice": "no",
              "confidence": 0.94,
              "probabilities": {
                "no": 0.96,
                "unclear": 0.01,
                "yes": 0.03
              }
            }
          },
          "min_confidence": 0.86,
          "explanation": "The directive is carried forward.",
          "usage": {
            "input_tokens": 6651,
            "output_tokens": 117
          },
          "attempts": 1,
          "item_chars_sent": 20481,
          "item_shortened": false,
          "request_bytes": 22503
        },
        {
          "anchor_id": "ANC-031",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "Every production release crate excludes sc-compose and ATM crate dependencies and Rust imports, enforced by boundary lint; test and benchmark references are permitted.",
          "quote": "sc-compose and atm crates should be blocked from any production release crate.  sc-compose and atm can be referenced for tests i.e. benchmark tests",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
          "anchor_version": 3,
          "deterministic_check": "Boundary lint rejects production imports/dependencies while permitting test-only references.",
          "kind": "prohibition",
          "leaning": "satisfied",
          "question_set": {
            "gate": "plan",
            "version": 1,
            "overridden": true
          },
          "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
          "questions": {
            "relevant": {
              "criteria": {
                "no": "The anchor does not apply to this item.",
                "unclear": "The item does not identify enough work to decide applicability.",
                "yes": "The anchor applies to this item."
              },
              "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
              "type": "choice"
            },
            "addressed": {
              "criteria": {
                "no": "The item is silent, merely topical, or includes only the opposite behavior.",
                "unclear": "The text might include the requirement but is too indefinite to tell.",
                "yes": "The item explicitly plans or preserves the required behavior or boundary."
              },
              "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
              "type": "choice"
            },
            "contradicted": {
              "criteria": {
                "no": "The item can coexist with the anchor, including when silent.",
                "unclear": "The item leaves a potentially decisive choice unspecified.",
                "yes": "A stated plan would violate the anchor."
              },
              "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
              "type": "choice"
            }
          },
          "verdict": "satisfied",
          "answers": {
            "relevant": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.86,
              "probabilities": {
                "no": 0.08,
                "unclear": 0.01,
                "yes": 0.91
              }
            },
            "addressed": {
              "type": "choice",
              "choice": "yes",
              "confidence": 1.0,
              "probabilities": {
                "no": 0.0,
                "unclear": 0.0,
                "yes": 1.0
              }
            },
            "contradicted": {
              "type": "choice",
              "choice": "no",
              "confidence": 0.91,
              "probabilities": {
                "no": 0.94,
                "unclear": 0.02,
                "yes": 0.04
              }
            }
          },
          "min_confidence": 0.86,
          "explanation": "The directive is carried forward.",
          "usage": {
            "input_tokens": 6666,
            "output_tokens": 117
          },
          "attempts": 1,
          "item_chars_sent": 20481,
          "item_shortened": false,
          "request_bytes": 22606
        },
        {
          "anchor_id": "ANC-033",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "MVP executes application-supplied Monty scripts without script signing or a separate approval mechanism.",
          "quote": "for mvp this is not something available for consumers to do.",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
          "anchor_version": 3,
          "deterministic_check": "MVP execution requires neither signatures nor approval configuration.",
          "kind": "prohibition",
          "leaning": "satisfied",
          "question_set": {
            "gate": "plan",
            "version": 1,
            "overridden": true
          },
          "questions_sha256": "51ecb3cc44b751a0719c40aba67ba5d6ee1de19e77bdc74ffbf6b1265932fa10",
          "questions": {
            "relevant": {
              "criteria": {
                "no": "The item is about a different part of the system or a different activity, and completing it would neither follow nor break the anchor.",
                "unclear": "The item text is too vague to tell what part of the system it touches.",
                "yes": "The item plans, changes, or depends on the thing the anchor statement is about, directly or as a clear prerequisite."
              },
              "instructions": "The state holds one planning item (`item.title`, `item.text`) and one anchor: a directive the user stated verbatim in `anchor.statement`, with the area it governs in `anchor.scope`. Does the work described in `item.text` touch the subject that `anchor.statement` talks about? Judge overlap of subject matter only. Do not judge whether the item obeys the anchor.",
              "type": "choice"
            },
            "addressed": {
              "criteria": {
                "no": "The item omits this complete rule or retains either gate.",
                "unclear": "The item names the gates but leaves whether either is mandatory unresolved.",
                "yes": "The item explicitly permits MVP execution without signatures and without separate approval."
              },
              "instructions": "Does item.text explicitly preserve BOTH parts of the MVP execution rule in anchor.statement: no mandatory script signing and no separate approval mechanism? A plan that retains either gate does not carry the complete rule forward.",
              "type": "choice"
            },
            "contradicted": {
              "criteria": {
                "no": "Nothing in the item text conflicts with the directive, whether or not the directive is mentioned.",
                "unclear": "The item text is ambiguous enough that it might or might not conflict with the directive.",
                "yes": "The item text states a plan, approach, or decision that cannot be reconciled with the directive in the anchor statement."
              },
              "instructions": "Does `item.text` propose doing something that `anchor.statement` rules out, or propose a different approach than the one `anchor.statement` requires? Examples of contradiction: the anchor says to start from an existing implementation and the item plans a fresh implementation; the anchor forbids a dependency and the item adds it; the anchor fixes an order of work and the item reverses it. Silence about the directive is not a contradiction. Judge conflict only.",
              "type": "choice"
            }
          },
          "near_threshold": true,
          "confirmed": true,
          "verdict": "satisfied",
          "answers": {
            "relevant": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.88,
              "probabilities": {
                "no": 0.08,
                "unclear": 0.0,
                "yes": 0.92
              }
            },
            "addressed": {
              "type": "choice",
              "choice": "no",
              "confidence": 0.96,
              "probabilities": {
                "no": 0.97,
                "unclear": 0.0,
                "yes": 0.03
              }
            },
            "contradicted": {
              "type": "choice",
              "choice": "no",
              "confidence": 0.66,
              "probabilities": {
                "no": 0.77,
                "unclear": 0.04,
                "yes": 0.19
              }
            }
          },
          "min_confidence": 0.66,
          "explanation": "The directive is carried forward.",
          "usage": {
            "input_tokens": 6867,
            "output_tokens": 117
          },
          "attempts": 2,
          "item_chars_sent": 20481,
          "item_shortened": false,
          "request_bytes": 23509
        },
        {
          "anchor_id": "ANC-034",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "Python and Monty hooks use the same schedule-environment configuration and resolution rules.",
          "quote": "python/monty having consistent settings would be least confusing",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
          "anchor_version": 2,
          "deterministic_check": "The same environment cases produce equivalent Python and Monty results.",
          "kind": "directive",
          "leaning": "satisfied",
          "question_set": {
            "gate": "plan",
            "version": 1,
            "overridden": true
          },
          "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
          "questions": {
            "relevant": {
              "criteria": {
                "no": "The anchor does not apply to this item.",
                "unclear": "The item does not identify enough work to decide applicability.",
                "yes": "The anchor applies to this item."
              },
              "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
              "type": "choice"
            },
            "addressed": {
              "criteria": {
                "no": "The item is silent, merely topical, or includes only the opposite behavior.",
                "unclear": "The text might include the requirement but is too indefinite to tell.",
                "yes": "The item explicitly plans or preserves the required behavior or boundary."
              },
              "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
              "type": "choice"
            },
            "contradicted": {
              "criteria": {
                "no": "The item can coexist with the anchor, including when silent.",
                "unclear": "The item leaves a potentially decisive choice unspecified.",
                "yes": "A stated plan would violate the anchor."
              },
              "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
              "type": "choice"
            }
          },
          "verdict": "satisfied",
          "answers": {
            "relevant": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.91,
              "probabilities": {
                "no": 0.06,
                "unclear": 0.0,
                "yes": 0.94
              }
            },
            "addressed": {
              "type": "choice",
              "choice": "yes",
              "confidence": 1.0,
              "probabilities": {
                "no": 0.0,
                "unclear": 0.0,
                "yes": 1.0
              }
            },
            "contradicted": {
              "type": "choice",
              "choice": "no",
              "confidence": 0.97,
              "probabilities": {
                "no": 0.98,
                "unclear": 0.01,
                "yes": 0.01
              }
            }
          },
          "min_confidence": 0.91,
          "explanation": "The directive is carried forward.",
          "usage": {
            "input_tokens": 6652,
            "output_tokens": 117
          },
          "attempts": 1,
          "item_chars_sent": 20481,
          "item_shortened": false,
          "request_bytes": 22502
        },
        {
          "anchor_id": "ANC-035",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "Hooks inherit daemon-process environment values only through variable names explicitly allowed by daemon configuration.",
          "quote": "whitelisting api keys globally (by name) in config file (this is really a daemon scope decision)",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
          "anchor_version": 2,
          "deterministic_check": "An allowed daemon value is delivered and an unlisted value is absent.",
          "kind": "directive",
          "leaning": "satisfied",
          "question_set": {
            "gate": "plan",
            "version": 1,
            "overridden": true
          },
          "questions_sha256": "f826ddd4cc1178bb42b5729fb97e85e6b3b2ab65498cde66ea0ee1dfa98a0a26",
          "questions": {
            "relevant": {
              "criteria": {
                "no": "The work is independent of the governed subject.",
                "unclear": "The work area is too vague to determine applicability.",
                "yes": "The work touches the governed subject directly or as a clear prerequisite."
              },
              "instructions": "Does item.text plan work on the governed activity, component, or artifact named by anchor.statement and anchor.scope? Judge applicability only, including dependencies.",
              "type": "choice"
            },
            "addressed": {
              "criteria": {
                "no": "The item omits the obligation or describes only a conflicting action.",
                "unclear": "The item gestures at the obligation but does not settle whether it is included.",
                "yes": "The required action or constraint is explicitly included."
              },
              "instructions": "Does item.text expressly include the specific obligation in anchor.statement as a planned step or constraint? A subject mention, silence, or opposing action does not satisfy the obligation.",
              "type": "choice"
            },
            "contradicted": {
              "criteria": {
                "no": "No incompatible behavior is proposed.",
                "unclear": "A possible conflict depends on an unresolved detail.",
                "yes": "The item commits to an incompatible behavior or boundary."
              },
              "instructions": "Does item.text commit to behavior that cannot coexist with anchor.statement? Silence, topical mention, and an expressly permitted exception are not conflicts.",
              "type": "choice"
            }
          },
          "verdict": "satisfied",
          "answers": {
            "relevant": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.86,
              "probabilities": {
                "no": 0.09,
                "unclear": 0.0,
                "yes": 0.91
              }
            },
            "addressed": {
              "type": "choice",
              "choice": "yes",
              "confidence": 1.0,
              "probabilities": {
                "no": 0.0,
                "unclear": 0.0,
                "yes": 1.0
              }
            },
            "contradicted": {
              "type": "choice",
              "choice": "no",
              "confidence": 1.0,
              "probabilities": {
                "no": 1.0,
                "unclear": 0.0,
                "yes": 0.0
              }
            }
          },
          "min_confidence": 0.86,
          "explanation": "The directive is carried forward.",
          "usage": {
            "input_tokens": 6674,
            "output_tokens": 117
          },
          "attempts": 1,
          "item_chars_sent": 20481,
          "item_shortened": false,
          "request_bytes": 22669
        },
        {
          "anchor_id": "ANC-036",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "Each schedule can explicitly set or clear its own environment variables.",
          "quote": "having each entry having the ability to set or clear specific environment variables",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
          "anchor_version": 2,
          "deterministic_check": "Two schedules set distinct identities and clearing removes a prior value.",
          "kind": "directive",
          "leaning": "satisfied",
          "question_set": {
            "gate": "plan",
            "version": 1,
            "overridden": true
          },
          "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
          "questions": {
            "relevant": {
              "criteria": {
                "no": "The anchor does not apply to this item.",
                "unclear": "The item does not identify enough work to decide applicability.",
                "yes": "The anchor applies to this item."
              },
              "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
              "type": "choice"
            },
            "addressed": {
              "criteria": {
                "no": "The item is silent, merely topical, or includes only the opposite behavior.",
                "unclear": "The text might include the requirement but is too indefinite to tell.",
                "yes": "The item explicitly plans or preserves the required behavior or boundary."
              },
              "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
              "type": "choice"
            },
            "contradicted": {
              "criteria": {
                "no": "The item can coexist with the anchor, including when silent.",
                "unclear": "The item leaves a potentially decisive choice unspecified.",
                "yes": "A stated plan would violate the anchor."
              },
              "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
              "type": "choice"
            }
          },
          "verdict": "satisfied",
          "answers": {
            "relevant": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.91,
              "probabilities": {
                "no": 0.06,
                "unclear": 0.0,
                "yes": 0.94
              }
            },
            "addressed": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.94,
              "probabilities": {
                "no": 0.04,
                "unclear": 0.0,
                "yes": 0.96
              }
            },
            "contradicted": {
              "type": "choice",
              "choice": "no",
              "confidence": 0.92,
              "probabilities": {
                "no": 0.95,
                "unclear": 0.01,
                "yes": 0.04
              }
            }
          },
          "min_confidence": 0.91,
          "explanation": "The directive is carried forward.",
          "usage": {
            "input_tokens": 6645,
            "output_tokens": 117
          },
          "attempts": 1,
          "item_chars_sent": 20481,
          "item_shortened": false,
          "request_bytes": 22492
        },
        {
          "anchor_id": "ANC-037",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "Schedule creation and updates never implicitly capture environment values from the caller or daemon process.",
          "quote": "Never capture or persist inherited host values accidentally",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
          "anchor_version": 3,
          "deterministic_check": "Ambient canaries are absent from persisted rows without explicit set input.",
          "kind": "prohibition",
          "leaning": "satisfied",
          "question_set": {
            "gate": "plan",
            "version": 1,
            "overridden": true
          },
          "questions_sha256": "f826ddd4cc1178bb42b5729fb97e85e6b3b2ab65498cde66ea0ee1dfa98a0a26",
          "questions": {
            "relevant": {
              "criteria": {
                "no": "The work is independent of the governed subject.",
                "unclear": "The work area is too vague to determine applicability.",
                "yes": "The work touches the governed subject directly or as a clear prerequisite."
              },
              "instructions": "Does item.text plan work on the governed activity, component, or artifact named by anchor.statement and anchor.scope? Judge applicability only, including dependencies.",
              "type": "choice"
            },
            "addressed": {
              "criteria": {
                "no": "The item omits the obligation or describes only a conflicting action.",
                "unclear": "The item gestures at the obligation but does not settle whether it is included.",
                "yes": "The required action or constraint is explicitly included."
              },
              "instructions": "Does item.text expressly include the specific obligation in anchor.statement as a planned step or constraint? A subject mention, silence, or opposing action does not satisfy the obligation.",
              "type": "choice"
            },
            "contradicted": {
              "criteria": {
                "no": "No incompatible behavior is proposed.",
                "unclear": "A possible conflict depends on an unresolved detail.",
                "yes": "The item commits to an incompatible behavior or boundary."
              },
              "instructions": "Does item.text commit to behavior that cannot coexist with anchor.statement? Silence, topical mention, and an expressly permitted exception are not conflicts.",
              "type": "choice"
            }
          },
          "near_threshold": true,
          "confirmed": true,
          "verdict": "satisfied",
          "answers": {
            "relevant": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.85,
              "probabilities": {
                "no": 0.1,
                "unclear": 0.0,
                "yes": 0.9
              }
            },
            "addressed": {
              "type": "choice",
              "choice": "no",
              "confidence": 0.33,
              "probabilities": {
                "no": 0.55,
                "unclear": 0.03,
                "yes": 0.42
              }
            },
            "contradicted": {
              "type": "choice",
              "choice": "no",
              "confidence": 0.66,
              "probabilities": {
                "no": 0.77,
                "unclear": 0.02,
                "yes": 0.21
              }
            }
          },
          "min_confidence": 0.66,
          "explanation": "The directive is carried forward.",
          "usage": {
            "input_tokens": 6675,
            "output_tokens": 117
          },
          "attempts": 2,
          "item_chars_sent": 20481,
          "item_shortened": false,
          "request_bytes": 22647
        },
        {
          "anchor_id": "ANC-038",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "The schedule registry permits deliberately supplied environment values as plaintext configuration.",
          "quote": "why can we never add values?  all environment variables are not api keys?",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
          "anchor_version": 2,
          "deterministic_check": "An explicit set value round-trips through the registry.",
          "kind": "directive",
          "leaning": "satisfied",
          "question_set": {
            "gate": "plan",
            "version": 1,
            "overridden": true
          },
          "questions_sha256": "e9965576f4baeafd046cab1602c342cfba185667897278270cdc80eb069acb36",
          "questions": {
            "relevant": {
              "criteria": {
                "no": "The item is about a different part of the system or a different activity, and completing it would neither follow nor break the anchor.",
                "unclear": "The item text is too vague to tell what part of the system it touches.",
                "yes": "The item plans, changes, or depends on the thing the anchor statement is about, directly or as a clear prerequisite."
              },
              "instructions": "The state holds one planning item (`item.title`, `item.text`) and one anchor: a directive the user stated verbatim in `anchor.statement`, with the area it governs in `anchor.scope`. Does the work described in `item.text` touch the subject that `anchor.statement` talks about? Judge overlap of subject matter only. Do not judge whether the item obeys the anchor.",
              "type": "choice"
            },
            "addressed": {
              "criteria": {
                "no": "The plan is silent or denies any permitted class, even if it mentions plaintext.",
                "unclear": "The plan names plaintext values but leaves the allowed class unresolved.",
                "yes": "The plan explicitly preserves the full permitted class of deliberate plaintext set values."
              },
              "instructions": "Does item.text expressly preserve the schedule registry permission to accept every deliberately supplied plaintext environment value, including secret and nonsecret values? Merely mentioning plaintext while banning a value class does not carry the permission forward.",
              "type": "choice"
            },
            "contradicted": {
              "criteria": {
                "no": "No incompatible restriction is planned.",
                "unclear": "The planned restriction or its applicability to deliberate set values is unresolved.",
                "yes": "The plan denies or narrows the anchor-permitted plaintext set-value capability."
              },
              "instructions": "Does item.text prohibit or narrow a class of deliberately supplied plaintext environment values that anchor.statement permits in the schedule registry? Treat an explicit secret-only ban as a conflict; silence and permitted handling are not conflicts.",
              "type": "choice"
            }
          },
          "verdict": "satisfied",
          "answers": {
            "relevant": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.98,
              "probabilities": {
                "no": 0.01,
                "unclear": 0.0,
                "yes": 0.99
              }
            },
            "addressed": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.94,
              "probabilities": {
                "no": 0.03,
                "unclear": 0.01,
                "yes": 0.96
              }
            },
            "contradicted": {
              "type": "choice",
              "choice": "no",
              "confidence": 0.92,
              "probabilities": {
                "no": 0.95,
                "unclear": 0.0,
                "yes": 0.05
              }
            }
          },
          "min_confidence": 0.92,
          "explanation": "The directive is carried forward.",
          "usage": {
            "input_tokens": 6787,
            "output_tokens": 117
          },
          "attempts": 1,
          "item_chars_sent": 20481,
          "item_shortened": false,
          "request_bytes": 23240
        },
        {
          "anchor_id": "ANC-039",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "Schedules can resolve environment values through an application-provided resolver for opaque references.",
          "quote": "I also like allowing this:   \"OTHER_API_KEY\": { \"reference\": \"keychain://agents/planner-7/api-key\" }",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
          "anchor_version": 2,
          "deterministic_check": "A consumer resolver supplies a referenced value without persisting the result.",
          "kind": "directive",
          "leaning": "satisfied",
          "question_set": {
            "gate": "plan",
            "version": 1,
            "overridden": true
          },
          "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
          "questions": {
            "relevant": {
              "criteria": {
                "no": "The anchor does not apply to this item.",
                "unclear": "The item does not identify enough work to decide applicability.",
                "yes": "The anchor applies to this item."
              },
              "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
              "type": "choice"
            },
            "addressed": {
              "criteria": {
                "no": "The item is silent, merely topical, or includes only the opposite behavior.",
                "unclear": "The text might include the requirement but is too indefinite to tell.",
                "yes": "The item explicitly plans or preserves the required behavior or boundary."
              },
              "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
              "type": "choice"
            },
            "contradicted": {
              "criteria": {
                "no": "The item can coexist with the anchor, including when silent.",
                "unclear": "The item leaves a potentially decisive choice unspecified.",
                "yes": "A stated plan would violate the anchor."
              },
              "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
              "type": "choice"
            }
          },
          "verdict": "satisfied",
          "answers": {
            "relevant": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.94,
              "probabilities": {
                "no": 0.04,
                "unclear": 0.0,
                "yes": 0.96
              }
            },
            "addressed": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.94,
              "probabilities": {
                "no": 0.04,
                "unclear": 0.0,
                "yes": 0.96
              }
            },
            "contradicted": {
              "type": "choice",
              "choice": "no",
              "confidence": 0.92,
              "probabilities": {
                "no": 0.95,
                "unclear": 0.01,
                "yes": 0.04
              }
            }
          },
          "min_confidence": 0.92,
          "explanation": "The directive is carried forward.",
          "usage": {
            "input_tokens": 6648,
            "output_tokens": 117
          },
          "attempts": 1,
          "item_chars_sent": 20481,
          "item_shortened": false,
          "request_bytes": 22510
        },
        {
          "anchor_id": "ANC-040",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "Schedules can load environment variables from full-path .env files.",
          "quote": "Another useful way to specify would be loading from a full-path .env file.",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
          "anchor_version": 2,
          "deterministic_check": "An authorized absolute dotenv file supplies hook values.",
          "kind": "directive",
          "leaning": "satisfied",
          "question_set": {
            "gate": "plan",
            "version": 1,
            "overridden": true
          },
          "questions_sha256": "f826ddd4cc1178bb42b5729fb97e85e6b3b2ab65498cde66ea0ee1dfa98a0a26",
          "questions": {
            "relevant": {
              "criteria": {
                "no": "The work is independent of the governed subject.",
                "unclear": "The work area is too vague to determine applicability.",
                "yes": "The work touches the governed subject directly or as a clear prerequisite."
              },
              "instructions": "Does item.text plan work on the governed activity, component, or artifact named by anchor.statement and anchor.scope? Judge applicability only, including dependencies.",
              "type": "choice"
            },
            "addressed": {
              "criteria": {
                "no": "The item omits the obligation or describes only a conflicting action.",
                "unclear": "The item gestures at the obligation but does not settle whether it is included.",
                "yes": "The required action or constraint is explicitly included."
              },
              "instructions": "Does item.text expressly include the specific obligation in anchor.statement as a planned step or constraint? A subject mention, silence, or opposing action does not satisfy the obligation.",
              "type": "choice"
            },
            "contradicted": {
              "criteria": {
                "no": "No incompatible behavior is proposed.",
                "unclear": "A possible conflict depends on an unresolved detail.",
                "yes": "The item commits to an incompatible behavior or boundary."
              },
              "instructions": "Does item.text commit to behavior that cannot coexist with anchor.statement? Silence, topical mention, and an expressly permitted exception are not conflicts.",
              "type": "choice"
            }
          },
          "verdict": "satisfied",
          "answers": {
            "relevant": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.97,
              "probabilities": {
                "no": 0.02,
                "unclear": 0.0,
                "yes": 0.98
              }
            },
            "addressed": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.76,
              "probabilities": {
                "no": 0.15,
                "unclear": 0.01,
                "yes": 0.84
              }
            },
            "contradicted": {
              "type": "choice",
              "choice": "no",
              "confidence": 0.86,
              "probabilities": {
                "no": 0.91,
                "unclear": 0.01,
                "yes": 0.08
              }
            }
          },
          "min_confidence": 0.76,
          "explanation": "The directive is carried forward.",
          "usage": {
            "input_tokens": 6672,
            "output_tokens": 117
          },
          "attempts": 1,
          "item_chars_sent": 20481,
          "item_shortened": false,
          "request_bytes": 22606
        },
        {
          "anchor_id": "ANC-041",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "Monty scripts can read their configured environment during source initialization, before hook functions run.",
          "quote": "there should also be the ability to set environment variables in a monty script before it runs.",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
          "anchor_version": 2,
          "deterministic_check": "A top-level getenv reads the configured snapshot before cron_stop or cron_tick.",
          "kind": "directive",
          "leaning": "satisfied",
          "question_set": {
            "gate": "plan",
            "version": 1,
            "overridden": true
          },
          "questions_sha256": "f826ddd4cc1178bb42b5729fb97e85e6b3b2ab65498cde66ea0ee1dfa98a0a26",
          "questions": {
            "relevant": {
              "criteria": {
                "no": "The work is independent of the governed subject.",
                "unclear": "The work area is too vague to determine applicability.",
                "yes": "The work touches the governed subject directly or as a clear prerequisite."
              },
              "instructions": "Does item.text plan work on the governed activity, component, or artifact named by anchor.statement and anchor.scope? Judge applicability only, including dependencies.",
              "type": "choice"
            },
            "addressed": {
              "criteria": {
                "no": "The item omits the obligation or describes only a conflicting action.",
                "unclear": "The item gestures at the obligation but does not settle whether it is included.",
                "yes": "The required action or constraint is explicitly included."
              },
              "instructions": "Does item.text expressly include the specific obligation in anchor.statement as a planned step or constraint? A subject mention, silence, or opposing action does not satisfy the obligation.",
              "type": "choice"
            },
            "contradicted": {
              "criteria": {
                "no": "No incompatible behavior is proposed.",
                "unclear": "A possible conflict depends on an unresolved detail.",
                "yes": "The item commits to an incompatible behavior or boundary."
              },
              "instructions": "Does item.text commit to behavior that cannot coexist with anchor.statement? Silence, topical mention, and an expressly permitted exception are not conflicts.",
              "type": "choice"
            }
          },
          "verdict": "satisfied",
          "answers": {
            "relevant": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.83,
              "probabilities": {
                "no": 0.11,
                "unclear": 0.0,
                "yes": 0.89
              }
            },
            "addressed": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.97,
              "probabilities": {
                "no": 0.02,
                "unclear": 0.0,
                "yes": 0.98
              }
            },
            "contradicted": {
              "type": "choice",
              "choice": "no",
              "confidence": 0.98,
              "probabilities": {
                "no": 0.99,
                "unclear": 0.0,
                "yes": 0.01
              }
            }
          },
          "min_confidence": 0.83,
          "explanation": "The directive is carried forward.",
          "usage": {
            "input_tokens": 6676,
            "output_tokens": 117
          },
          "attempts": 1,
          "item_chars_sent": 20481,
          "item_shortened": false,
          "request_bytes": 22654
        },
        {
          "anchor_id": "REQ-CRON-0003",
          "source_type": "REQ",
          "source_ref": "REQ-CRON-0003",
          "statement": "sc-cron must run application-defined Rust, Python, and optional Monty jobs; applications can extend Monty host calls, including sc_compose_run and atm_run CLI adapters, without changing sc-cron.",
          "quote": "A schedule row names either an in-process Rust job or a Python module. For Python, the crate runs python3 <module> cron.tick or python3 <module> cron.stop and writes one JSON object to stdin. The crate exposes no HTTP route, MCP tool, or binary.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "Historical register quote retained as immutable provenance. Current statement follows the amended REQ-CRON-0003 authority and owner-approved Phase B continuation ANC-027 through ANC-042 (2026-10-29); the historical quote is not the current normative contract.",
          "anchor_version": 5,
          "deterministic_check": "Host registry integration tests invoke custom, sc-compose, and ATM functions through one extension interface.",
          "kind": "directive",
          "leaning": "satisfied",
          "question_set": {
            "gate": "plan",
            "version": 1,
            "overridden": false
          },
          "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
          "verdict": "satisfied",
          "answers": {
            "relevant": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.98,
              "probabilities": {
                "yes": 0.99,
                "no": 0.01,
                "unclear": 0.0
              }
            },
            "addressed": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.98,
              "probabilities": {
                "yes": 0.99,
                "no": 0.01,
                "unclear": 0.0
              }
            },
            "contradicted": {
              "type": "choice",
              "choice": "no",
              "confidence": 0.96,
              "probabilities": {
                "yes": 0.03,
                "no": 0.97,
                "unclear": 0.0
              }
            }
          },
          "min_confidence": 0.96,
          "explanation": "The directive is carried forward.",
          "usage": {
            "input_tokens": 6981,
            "output_tokens": 117
          },
          "attempts": 1,
          "item_chars_sent": 20481,
          "item_shortened": false,
          "request_bytes": 23966
        },
        {
          "anchor_id": "REQ-RUN-0503",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0503",
          "statement": "A project generated by just new passes lint, test, and both builds with no file edited.",
          "quote": "A project generated by just new passes lint, test, and both builds with no file edited.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "requirements register",
          "anchor_version": 2,
          "deterministic_check": "just new on the sqlite fixture exits 0, and just lint, just test, just build-cli, and just build-daemon exit 0 with no file edited.",
          "kind": "directive",
          "leaning": "satisfied",
          "question_set": {
            "gate": "plan",
            "version": 1,
            "overridden": false
          },
          "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
          "verdict": "satisfied",
          "answers": {
            "relevant": {
              "type": "choice",
              "choice": "yes",
              "confidence": 0.96,
              "probabilities": {
                "yes": 0.97,
                "no": 0.03,
                "unclear": 0.0
              }
            },
            "addressed": {
              "type": "choice",
              "choice": "yes",
              "confidence": 1.0,
              "probabilities": {
                "yes": 1.0,
                "no": 0.0,
                "unclear": 0.0
              }
            },
            "contradicted": {
              "type": "choice",
              "choice": "no",
              "confidence": 0.94,
              "probabilities": {
                "yes": 0.04,
                "no": 0.96,
                "unclear": 0.0
              }
            }
          },
          "min_confidence": 0.94,
          "explanation": "The directive is carried forward.",
          "usage": {
            "input_tokens": 6958,
            "output_tokens": 117
          },
          "attempts": 1,
          "item_chars_sent": 20481,
          "item_shortened": false,
          "request_bytes": 23874
        },
        {
          "anchor_id": "ADR-RUN-0013",
          "source_type": "ADR",
          "source_ref": "ADR-RUN-0013",
          "statement": "sc-cron is an optional general-purpose SQLite cron library with Rust/Python/Monty hooks, application-owned host registration, and no MVP script signing or separate approval mechanism.",
          "quote": "sc-cron is an optional SQLite cron crate. A normal schedule string is five fields, minute first. The hook target is a Rust function or a Python module run as python3 <module> cron.tick or cron.stop with one JSON object on stdin.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "Historical register quote retained as immutable provenance. Current statement follows the amended ADR-RUN-0013 authority and owner-approved Phase B continuation ANC-027 through ANC-042 (2026-10-29); the historical quote is not the current normative contract.",
          "anchor_version": 5,
          "deterministic_check": "The optional library provides application-defined job and Monty registration tests, and no MVP signing configuration.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures.",
          "attempts": 0
        },
        {
          "anchor_id": "ADR-RUN-0305",
          "source_type": "ADR",
          "source_ref": "ADR-RUN-0305",
          "statement": "SQLite and Postgres meet in an adaptor crate generated into the consumer repository.",
          "quote": "SQLite and Postgres meet in an adaptor crate generated into the consumer repository.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 2,
          "deterministic_check": "docs/architecture.md contains ADR-RUN-0305.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "ANC-027",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "sc-cron is a general-purpose cron library supporting application-defined jobs.",
          "quote": "sc-cron is a general-purpose cron library.",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
          "anchor_version": 2,
          "deterministic_check": "A consumer can schedule an application-defined job without a tool-specific payload.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema.",
          "attempts": 0
        },
        {
          "anchor_id": "ANC-029",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "The sc_compose_run integration supports any sc-compose command/subcommand supplied by an application script.",
          "quote": "sc_compose_run (any subcommand) would be a useful working example for showing how to use sc-cron",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
          "anchor_version": 2,
          "deterministic_check": "Argument-forwarding tests cover render and non-render subcommands.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "b-18 forwards an opaque prebuilt registry; it changes neither CLI adapter, argv dispatch, nor adapter examples."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: b-18 forwards an opaque prebuilt registry; it changes neither CLI adapter, argv dispatch, nor adapter examples.",
          "attempts": 0
        },
        {
          "anchor_id": "ANC-030",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "Phase B provides an atm_run host integration supporting any ATM CLI command/subcommand through the same extension interface used by sc_compose_run.",
          "quote": "i am in agreement.",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Owner approved the preceding proposal: \"Phase B provides an atm_run host integration supporting any ATM CLI command/subcommand through the same extension interface used by sc_compose_run.\" The immutable quote \"i am in agreement.\" is the owner's response approving that exact statement.",
          "anchor_version": 3,
          "deterministic_check": "An ATM executable fixture is invoked through the same registry as sc_compose_run.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "b-18 forwards an opaque prebuilt registry; it changes neither CLI adapter, argv dispatch, nor adapter examples."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: b-18 forwards an opaque prebuilt registry; it changes neither CLI adapter, argv dispatch, nor adapter examples.",
          "attempts": 0
        },
        {
          "anchor_id": "ANC-032",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "render_template is not required by the sc-cron product contract.",
          "quote": "render_template is not a product requirement",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
          "anchor_version": 3,
          "deterministic_check": "Product requirements and acceptance do not require render_template.",
          "kind": "prohibition",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema.",
          "attempts": 0
        },
        {
          "anchor_id": "ANC-042",
          "source_type": "ANC",
          "source_ref": null,
          "statement": "The first released schedule schema establishes one baseline without requiring migrations among unreleased development schemas.",
          "quote": "i don't know why we are on schema v4 when we haven't even released binaries yet.",
          "stated_by": "randlee",
          "stated_at": "2026-10-29",
          "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
          "anchor_version": 2,
          "deterministic_check": "First-release schema validation does not require a v1-v4 development migration ladder.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-CRON-0001",
          "source_type": "REQ",
          "source_ref": "REQ-CRON-0001",
          "statement": "sc-cron must remain an optional workspace crate; the generated daemon may enable it through cron/monty features while sc-runtime remains independent of sc-cron.",
          "quote": "crates/sc-cron is a workspace member. It depends on no other workspace crate. The template does not name it. The sc-runtime library crate does not name it.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "Historical register quote retained as immutable provenance. Current statement follows the amended REQ-CRON-0001 authority and owner-approved Phase B continuation ANC-027 through ANC-042 (2026-10-29); the historical quote is not the current normative contract.",
          "anchor_version": 5,
          "deterministic_check": "Cargo manifests keep sc-cron optional in generated daemons and absent from sc-runtime dependencies.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-CRON-0002",
          "source_type": "REQ",
          "source_ref": "REQ-CRON-0002",
          "statement": "A sc-cron schedule is a normal crontab string of five fields: minute, hour, day of month, month, and day of week.",
          "quote": "CronExpr::parse of */5 * * * * succeeds and means every fifth minute. CronExpr::parse of 0 */5 * * * * succeeds and means second 0 of every fifth minute. CronExpr::parse of @hourly succeeds.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "requirements register",
          "anchor_version": 3,
          "deterministic_check": "A test expects parsing */5 * * * * to mean every fifth minute.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not change the cron expression parser or five-field schedule semantics."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not change the cron expression parser or five-field schedule semantics.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-CRON-0004",
          "source_type": "REQ",
          "source_ref": "REQ-CRON-0004",
          "statement": "The sc-cron crate creates one schedule table. A test writes a row without constructing SqliteWriter. The crate does not migrate the consumer's other tables.",
          "quote": "The sc-cron crate creates one schedule table. A test writes a row without constructing SqliteWriter. The crate does not migrate the consumer's other tables.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "requirements register",
          "anchor_version": 2,
          "deterministic_check": "A test writes a schedule row without constructing SqliteWriter.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add the schedule table or change table creation, consumer-table migrations, or SqliteWriter-independent row writes."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add the schedule table or change table creation, consumer-table migrations, or SqliteWriter-independent row writes.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-CRON-0005",
          "source_type": "REQ",
          "source_ref": "REQ-CRON-0005",
          "statement": "Fallible public library entry points in sc-cron must return CronError.",
          "quote": "Fallible public functions in sc-cron return CronError.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "requirements register",
          "anchor_version": 5,
          "deterministic_check": "The public error type in crates/sc-cron is CronError.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0313",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0313",
          "statement": "The relationship between the local SQLite store and the remote Postgres or SQL store is defined in an adaptor crate on the consumer repository.",
          "quote": "The relationship between the local SQLite store and the remote Postgres or SQL store is defined in an adaptor crate on the consumer repository.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 2,
          "deterministic_check": "A generated repository contains an adaptor crate that names both stores.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0314",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0314",
          "statement": "The copy adaptor is a local SQLite database with the remote schema, for faster or offline access.",
          "quote": "The copy adaptor is a local SQLite database with the remote schema, for faster or offline access.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 2,
          "deterministic_check": "A generated copy adaptor creates the shared remote tables in SQLite.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0315",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0315",
          "statement": "The host-aggregate adaptor is one SQLite database for this host and a Postgres database that aggregates many hosts.",
          "quote": "The host-aggregate adaptor is one SQLite database for this host and a Postgres database that aggregates many hosts.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 2,
          "deterministic_check": "A generated host-aggregate adaptor documents one SQLite database per host and one Postgres aggregate.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0316",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0316",
          "statement": "The consumer repository defines the rollup from host rows into the Postgres aggregate.",
          "quote": "The consumer repository defines the rollup from host rows into the Postgres aggregate.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 2,
          "deterministic_check": "The host-aggregate adaptor has a consumer-owned function that maps host rows into the Postgres aggregate.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0317",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0317",
          "statement": "Adaptor Rust code and models in a new repository are generated by the command just new (scripts/new_project.py).",
          "quote": "Adaptor Rust code and models in a new repository are generated by the command just new (scripts/new_project.py).",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 2,
          "deterministic_check": "just new writes the adaptor crate and its models into the new repository.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0318",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0318",
          "statement": "The library crate named sc-runtime does not generate adaptor code.",
          "quote": "The library crate named sc-runtime does not generate adaptor code.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 2,
          "deterministic_check": "crates/sc-runtime contains no generator.",
          "kind": "prohibition",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0319",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0319",
          "statement": "Generation flags name tables and columns that exist on only one of the two stores. A skipped table may be the SQLite table or the SQL-server table.",
          "quote": "Generation flags name tables and columns that exist on only one of the two stores.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 3,
          "deterministic_check": "Generation input can name a SQLite-only table, a SQL-server-only table, and a column that exists on only one side.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0320",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0320",
          "statement": "Every consumer repository uses the same generated implementation of the copy pattern and the same generated implementation of the host-aggregate pattern.",
          "quote": "Every consumer repository uses the same generated implementation of the copy pattern and the same generated implementation of the host-aggregate pattern.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 2,
          "deterministic_check": "Two generated repositories that select the same pattern contain the same adaptor implementation.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0321",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0321",
          "statement": "Each database engine's SQL is in that engine's store crate.",
          "quote": "Generated SQLite code and generated Postgres code are separate files.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 3,
          "deterministic_check": "store-sqlite contains no Postgres SQL, and store-postgres contains no SQLite SQL.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0322",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0322",
          "statement": "An adaptor that is neither the copy pattern nor the host-aggregate pattern is written by the consumer from the store building blocks.",
          "quote": "An adaptor that is neither the copy pattern nor the host-aggregate pattern is written by the consumer from the store building blocks.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 3,
          "deterministic_check": "A third adaptor is a file the consumer wrote.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0323",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0323",
          "statement": "Store synchronization is scheduled by the consuming application. The adaptor starts no timer.",
          "quote": "Store synchronization is scheduled by the consuming application. The adaptor starts no timer.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 2,
          "deterministic_check": "The adaptor crate starts no timer. A schedule is registered by application code.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0324",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0324",
          "statement": "The consumer adaptor moves rows between the local store and the remote store.",
          "quote": "The consumer adaptor moves rows between the local store and the remote store.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 2,
          "deterministic_check": "The adaptor crate contains the copy from one store to the other.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0325",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0325",
          "statement": "The sc-runtime crates do not move rows between stores.",
          "quote": "The sc-runtime crates do not move rows between stores.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 2,
          "deterministic_check": "crates/ contains no store-to-store copy.",
          "kind": "prohibition",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0326",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0326",
          "statement": "A new application is created with no database, with SQLite only, with one sqlx SQL engine only, or with SQLite plus one sqlx SQL engine.",
          "quote": "A new application is created with no database, with SQLite only, with one sqlx SQL engine only, or with SQLite plus one sqlx SQL engine.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 3,
          "deterministic_check": "wizard/answers.schema.json accepts no database, SQLite only, one sqlx SQL engine, and SQLite plus one sqlx SQL engine.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0327",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0327",
          "statement": "Two stores in one application use the same schema or a similar schema.",
          "quote": "Two stores in one application use the same schema or a similar schema.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 2,
          "deterministic_check": "The copy pattern uses the same schema on both stores. The host-aggregate pattern uses a similar schema.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0328",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0328",
          "statement": "Two stores in one application use one shared trait or a different trait per store.",
          "quote": "Two stores in one application use one shared trait or a different trait per store.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 2,
          "deterministic_check": "A generated pair names one trait that both stores implement, or a trait for each store.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0329",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0329",
          "statement": "A generated crate's package name is the project name, a hyphen, and its role.",
          "quote": "A generated crate's package name is the project name, a hyphen, and its role. The adaptor depends on <project>-types and <project>-schema.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 4,
          "deterministic_check": "Two projects with different names produce no package name in common.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not change generated package names or their naming algorithm."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not change generated package names or their naming algorithm.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0330",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0330",
          "statement": "Row type structs are in the schema crate. The types crate is for non-database types.",
          "quote": "Row type structs are in the schema crate. The types crate is for non-database types.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "ADR-RUN-0305",
          "anchor_version": 2,
          "deterministic_check": "The schema crate contains the row structs. The types crate contains no database row struct. The adaptor depends on the schema crate.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not add or generate database schema/types crates or relocate row structs."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add or generate database schema/types crates or relocate row structs.",
          "attempts": 0
        },
        {
          "anchor_id": "REQ-RUN-0331",
          "source_type": "REQ",
          "source_ref": "REQ-RUN-0331",
          "statement": "The template ships general database commands on the CLI, MCP, and HTTP, including delete row <table> <id>. The consumer can disable that surface.",
          "quote": "The template ships general database commands on the CLI, MCP, and HTTP, including delete row <table> <id>. The consumer can disable that surface.",
          "stated_by": "randlee",
          "stated_at": "2026-10-25",
          "context": "requirements register",
          "anchor_version": 2,
          "deterministic_check": "A generated project with a store registers delete row <table> <id> on the CLI, MCP, and HTTP, and a flag removes those commands.",
          "kind": "directive",
          "leaning": null,
          "verdict": "excluded",
          "answers": null,
          "min_confidence": null,
          "exclusion": {
            "item": "b-18",
            "reason": "This sprint does not change the generated CLI/MCP/HTTP database command surface."
          },
          "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not change the generated CLI/MCP/HTTP database command surface.",
          "attempts": 0
        }
      ],
      "summary": {
        "counts": {
          "satisfied": 14,
          "excluded": 30
        },
        "failing": [],
        "leaning_counts": {
          "satisfied": 14
        },
        "unstable": [],
        "errors": [],
        "excluded": [
          {
            "anchor_id": "ADR-RUN-0013",
            "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
          },
          {
            "anchor_id": "ADR-RUN-0305",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "ANC-027",
            "reason": "This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema."
          },
          {
            "anchor_id": "ANC-029",
            "reason": "b-18 forwards an opaque prebuilt registry; it changes neither CLI adapter, argv dispatch, nor adapter examples."
          },
          {
            "anchor_id": "ANC-030",
            "reason": "b-18 forwards an opaque prebuilt registry; it changes neither CLI adapter, argv dispatch, nor adapter examples."
          },
          {
            "anchor_id": "ANC-032",
            "reason": "This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema."
          },
          {
            "anchor_id": "ANC-042",
            "reason": "This sprint composes the generated daemon; it does not change sc-cron scheduling/job interfaces, Monty product examples, or the first-release database schema."
          },
          {
            "anchor_id": "REQ-CRON-0001",
            "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
          },
          {
            "anchor_id": "REQ-CRON-0002",
            "reason": "This sprint does not change the cron expression parser or five-field schedule semantics."
          },
          {
            "anchor_id": "REQ-CRON-0004",
            "reason": "This sprint does not add the schedule table or change table creation, consumer-table migrations, or SqliteWriter-independent row writes."
          },
          {
            "anchor_id": "REQ-CRON-0005",
            "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
          },
          {
            "anchor_id": "REQ-RUN-0313",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0314",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0315",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0316",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0317",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0318",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0319",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0320",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0321",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0322",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0323",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0324",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0325",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0326",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0327",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0328",
            "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
          },
          {
            "anchor_id": "REQ-RUN-0329",
            "reason": "This sprint does not change generated package names or their naming algorithm."
          },
          {
            "anchor_id": "REQ-RUN-0330",
            "reason": "This sprint does not add or generate database schema/types crates or relocate row structs."
          },
          {
            "anchor_id": "REQ-RUN-0331",
            "reason": "This sprint does not change the generated CLI/MCP/HTTP database command surface."
          }
        ],
        "shortened": [],
        "pass": true
      }
    }
  },
  "error": null,
  "metadata": {
    "duration_ms": 10900,
    "tool_calls": 16,
    "retry_count": 2,
    "correlation_id": "pr85-scoped-qa-b18-20261030"
  }
}
```
