```json
{
  "schema_version": "1.0.0",
  "success": true,
  "canceled": false,
  "aborted_by": null,
  "data": {
    "gate": "plan",
    "item_id": "b-14",
    "run_id": "plan-20261030T072921Z-b-14",
    "run_path": "doc/plan/phase-current/qa-runs/final-scoped-20261030/anchor-rechecks/plan-20261030T072921Z-b-14.json",
    "dry_run": false,
    "reused_run": false,
    "pass": true,
    "failing": [],
    "errors": [],
    "excluded": [
      {
        "anchor_id": "ADR-RUN-0002",
        "reason": "This sprint edits existing library event emission; it adds no library crate and does not edit the cargo-generate template."
      },
      {
        "anchor_id": "ADR-RUN-0013",
        "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
      },
      {
        "anchor_id": "ADR-RUN-0305",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "ANC-027",
        "reason": "This sprint changes HTTP events in sc-runtime and does not change sc-cron job or Monty execution interfaces."
      },
      {
        "anchor_id": "ANC-028",
        "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
      },
      {
        "anchor_id": "ANC-029",
        "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
      },
      {
        "anchor_id": "ANC-030",
        "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
      },
      {
        "anchor_id": "ANC-032",
        "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
      },
      {
        "anchor_id": "ANC-033",
        "reason": "This sprint changes HTTP events in sc-runtime and does not change sc-cron job or Monty execution interfaces."
      },
      {
        "anchor_id": "ANC-034",
        "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
      },
      {
        "anchor_id": "ANC-035",
        "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
      },
      {
        "anchor_id": "ANC-036",
        "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
      },
      {
        "anchor_id": "ANC-037",
        "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
      },
      {
        "anchor_id": "ANC-038",
        "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
      },
      {
        "anchor_id": "ANC-039",
        "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
      },
      {
        "anchor_id": "ANC-040",
        "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
      },
      {
        "anchor_id": "ANC-041",
        "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
      },
      {
        "anchor_id": "ANC-042",
        "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
      },
      {
        "anchor_id": "REQ-CRON-0001",
        "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
      },
      {
        "anchor_id": "REQ-CRON-0002",
        "reason": "This sprint does not change the cron expression parser or five-field schedule semantics."
      },
      {
        "anchor_id": "REQ-CRON-0004",
        "reason": "This sprint does not add the schedule table or change table creation, consumer-table migrations, or SqliteWriter-independent row writes."
      },
      {
        "anchor_id": "REQ-CRON-0005",
        "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
      },
      {
        "anchor_id": "REQ-RUN-0313",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0314",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0315",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0316",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0317",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0318",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0319",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0320",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0321",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0322",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0323",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0324",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0325",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0326",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0327",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0328",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0329",
        "reason": "This sprint does not change generated package names or their naming algorithm."
      },
      {
        "anchor_id": "REQ-RUN-0330",
        "reason": "This sprint does not add or generate database schema/types crates or relocate row structs."
      },
      {
        "anchor_id": "REQ-RUN-0331",
        "reason": "This sprint does not change the generated CLI/MCP/HTTP database command surface."
      },
      {
        "anchor_id": "REQ-RUN-0503",
        "reason": "This sprint does not edit the template or project generator; generated-project acceptance is owned by the later template-editing sprints."
      }
    ],
    "results": [
      {
        "anchor_id": "ANC-031",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.82,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.82,
            "probabilities": {
              "no": 0.11,
              "unclear": 0.01,
              "yes": 0.88
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "no": 0.97,
              "unclear": 0.01,
              "yes": 0.02
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0003",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.97,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.02,
              "no": 0.98,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.01,
              "no": 0.98,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        },
        "to_fix": {
          "where": null,
          "change": "Review the sprint text against the failed anchor and state the missing commitment explicitly."
        }
      },
      {
        "anchor_id": "ADR-RUN-0002",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint edits existing library event emission; it adds no library crate and does not edit the cargo-generate template.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint edits existing library event emission; it adds no library crate and does not edit the cargo-generate template."
        }
      },
      {
        "anchor_id": "ADR-RUN-0013",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
        }
      },
      {
        "anchor_id": "ADR-RUN-0305",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "ANC-027",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint changes HTTP events in sc-runtime and does not change sc-cron job or Monty execution interfaces.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint changes HTTP events in sc-runtime and does not change sc-cron job or Monty execution interfaces."
        }
      },
      {
        "anchor_id": "ANC-028",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
        }
      },
      {
        "anchor_id": "ANC-029",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
        }
      },
      {
        "anchor_id": "ANC-030",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
        }
      },
      {
        "anchor_id": "ANC-032",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
        }
      },
      {
        "anchor_id": "ANC-033",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint changes HTTP events in sc-runtime and does not change sc-cron job or Monty execution interfaces.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint changes HTTP events in sc-runtime and does not change sc-cron job or Monty execution interfaces."
        }
      },
      {
        "anchor_id": "ANC-034",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
        }
      },
      {
        "anchor_id": "ANC-035",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
        }
      },
      {
        "anchor_id": "ANC-036",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
        }
      },
      {
        "anchor_id": "ANC-037",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
        }
      },
      {
        "anchor_id": "ANC-038",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
        }
      },
      {
        "anchor_id": "ANC-039",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
        }
      },
      {
        "anchor_id": "ANC-040",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
        }
      },
      {
        "anchor_id": "ANC-041",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
        }
      },
      {
        "anchor_id": "ANC-042",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema."
        }
      },
      {
        "anchor_id": "REQ-CRON-0001",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
        }
      },
      {
        "anchor_id": "REQ-CRON-0002",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not change the cron expression parser or five-field schedule semantics.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not change the cron expression parser or five-field schedule semantics."
        }
      },
      {
        "anchor_id": "REQ-CRON-0004",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add the schedule table or change table creation, consumer-table migrations, or SqliteWriter-independent row writes.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add the schedule table or change table creation, consumer-table migrations, or SqliteWriter-independent row writes."
        }
      },
      {
        "anchor_id": "REQ-CRON-0005",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures."
        }
      },
      {
        "anchor_id": "REQ-RUN-0313",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0314",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0315",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0316",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0317",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0318",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0319",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0320",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0321",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0322",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0323",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0324",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0325",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0326",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0327",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0328",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0329",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not change generated package names or their naming algorithm.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not change generated package names or their naming algorithm."
        }
      },
      {
        "anchor_id": "REQ-RUN-0330",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add or generate database schema/types crates or relocate row structs.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not add or generate database schema/types crates or relocate row structs."
        }
      },
      {
        "anchor_id": "REQ-RUN-0331",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not change the generated CLI/MCP/HTTP database command surface.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not change the generated CLI/MCP/HTTP database command surface."
        }
      },
      {
        "anchor_id": "REQ-RUN-0503",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not edit the template or project generator; generated-project acceptance is owned by the later template-editing sprints.",
        "answers": null,
        "exclusion": {
          "item": "b-14",
          "reason": "This sprint does not edit the template or project generator; generated-project acceptance is owned by the later template-editing sprints."
        }
      }
    ],
    "overrides_applied": [
      "ANC-031"
    ],
    "item_truncated": false,
    "shortened": [],
    "report_markdown": "## Anchor gate: plan · b-14 - Sprint b-14 — sc-runtime canonical HTTP events\n\nRun `plan-20261030T072921Z-b-14`, model `jev-1.14.0`, threshold 0.6. Counts: satisfied 1, not_applicable 1, excluded 42.\n\n> **b-14 · ADR-RUN-0002 · excluded** Anchor: sc-runtime is a cargo-generate template plus published library crates. Not judged: This sprint edits existing library event emission; it adds no library crate and does not edit the cargo-generate template.\n\n> **b-14 · ADR-RUN-0013 · excluded** Anchor: sc-cron is an optional general-purpose SQLite cron library with Rust/Python/Monty hooks, application-owned host registration, and no MVP script signing or separate approval mechanism. Not judged: This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures.\n\n> **b-14 · ADR-RUN-0305 · excluded** Anchor: SQLite and Postgres meet in an adaptor crate generated into the consumer repository. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · ANC-027 · excluded** Anchor: sc-cron is a general-purpose cron library supporting application-defined jobs. Not judged: This sprint changes HTTP events in sc-runtime and does not change sc-cron job or Monty execution interfaces.\n\n> **b-14 · ANC-028 · excluded** Anchor: Embedding applications can register additional Monty host functions without modifying sc-cron. Not judged: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.\n\n> **b-14 · ANC-029 · excluded** Anchor: The sc_compose_run integration supports any sc-compose command/subcommand supplied by an application script. Not judged: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.\n\n> **b-14 · ANC-030 · excluded** Anchor: Phase B provides an atm_run host integration supporting any ATM CLI command/subcommand through the same extension interface used by sc_compose_run. Not judged: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.\n\n> **b-14 · ANC-032 · excluded** Anchor: render_template is not required by the sc-cron product contract. Not judged: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.\n\n> **b-14 · ANC-033 · excluded** Anchor: MVP executes application-supplied Monty scripts without script signing or a separate approval mechanism. Not judged: This sprint changes HTTP events in sc-runtime and does not change sc-cron job or Monty execution interfaces.\n\n> **b-14 · ANC-034 · excluded** Anchor: Python and Monty hooks use the same schedule-environment configuration and resolution rules. Not judged: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.\n\n> **b-14 · ANC-035 · excluded** Anchor: Hooks inherit daemon-process environment values only through variable names explicitly allowed by daemon configuration. Not judged: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.\n\n> **b-14 · ANC-036 · excluded** Anchor: Each schedule can explicitly set or clear its own environment variables. Not judged: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.\n\n> **b-14 · ANC-037 · excluded** Anchor: Schedule creation and updates never implicitly capture environment values from the caller or daemon process. Not judged: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.\n\n> **b-14 · ANC-038 · excluded** Anchor: The schedule registry permits deliberately supplied environment values as plaintext configuration. Not judged: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.\n\n> **b-14 · ANC-039 · excluded** Anchor: Schedules can resolve environment values through an application-provided resolver for opaque references. Not judged: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.\n\n> **b-14 · ANC-040 · excluded** Anchor: Schedules can load environment variables from full-path .env files. Not judged: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.\n\n> **b-14 · ANC-041 · excluded** Anchor: Monty scripts can read their configured environment during source initialization, before hook functions run. Not judged: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.\n\n> **b-14 · ANC-042 · excluded** Anchor: The first released schedule schema establishes one baseline without requiring migrations among unreleased development schemas. Not judged: This sprint changes observability injection or event emission only; b-16 owns host-extension behavior and b-17 owns environment configuration/resolution/schema.\n\n> **b-14 · REQ-CRON-0001 · excluded** Anchor: sc-cron must remain an optional workspace crate; the generated daemon may enable it through cron/monty features while sc-runtime remains independent of sc-cron. Not judged: This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures.\n\n> **b-14 · REQ-CRON-0002 · excluded** Anchor: A sc-cron schedule is a normal crontab string of five fields: minute, hour, day of month, month, and day of week. Not judged: This sprint does not change the cron expression parser or five-field schedule semantics.\n\n> **b-14 · REQ-CRON-0004 · excluded** Anchor: The sc-cron crate creates one schedule table. A test writes a row without constructing SqliteWriter. The crate does not migrate the consumer's other tables. Not judged: This sprint does not add the schedule table or change table creation, consumer-table migrations, or SqliteWriter-independent row writes.\n\n> **b-14 · REQ-CRON-0005 · excluded** Anchor: Fallible public library entry points in sc-cron must return CronError. Not judged: This sprint edits HTTP events or generated-daemon integration, not Cargo manifests or sc-cron library implementations/public fallible signatures.\n\n> **b-14 · REQ-RUN-0313 · excluded** Anchor: The relationship between the local SQLite store and the remote Postgres or SQL store is defined in an adaptor crate on the consumer repository. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0314 · excluded** Anchor: The copy adaptor is a local SQLite database with the remote schema, for faster or offline access. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0315 · excluded** Anchor: The host-aggregate adaptor is one SQLite database for this host and a Postgres database that aggregates many hosts. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0316 · excluded** Anchor: The consumer repository defines the rollup from host rows into the Postgres aggregate. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0317 · excluded** Anchor: Adaptor Rust code and models in a new repository are generated by the command just new (scripts/new_project.py). Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0318 · excluded** Anchor: The library crate named sc-runtime does not generate adaptor code. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0319 · excluded** Anchor: Generation flags name tables and columns that exist on only one of the two stores. A skipped table may be the SQLite table or the SQL-server table. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0320 · excluded** Anchor: Every consumer repository uses the same generated implementation of the copy pattern and the same generated implementation of the host-aggregate pattern. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0321 · excluded** Anchor: Each database engine's SQL is in that engine's store crate. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0322 · excluded** Anchor: An adaptor that is neither the copy pattern nor the host-aggregate pattern is written by the consumer from the store building blocks. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0323 · excluded** Anchor: Store synchronization is scheduled by the consuming application. The adaptor starts no timer. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0324 · excluded** Anchor: The consumer adaptor moves rows between the local store and the remote store. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0325 · excluded** Anchor: The sc-runtime crates do not move rows between stores. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0326 · excluded** Anchor: A new application is created with no database, with SQLite only, with one sqlx SQL engine only, or with SQLite plus one sqlx SQL engine. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0327 · excluded** Anchor: Two stores in one application use the same schema or a similar schema. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0328 · excluded** Anchor: Two stores in one application use one shared trait or a different trait per store. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-14 · REQ-RUN-0329 · excluded** Anchor: A generated crate's package name is the project name, a hyphen, and its role. Not judged: This sprint does not change generated package names or their naming algorithm.\n\n> **b-14 · REQ-RUN-0330 · excluded** Anchor: Row type structs are in the schema crate. The types crate is for non-database types. Not judged: This sprint does not add or generate database schema/types crates or relocate row structs.\n\n> **b-14 · REQ-RUN-0331 · excluded** Anchor: The template ships general database commands on the CLI, MCP, and HTTP, including delete row <table> <id>. The consumer can disable that surface. Not judged: This sprint does not change the generated CLI/MCP/HTTP database command surface.\n\n> **b-14 · REQ-RUN-0503 · excluded** Anchor: A project generated by just new passes lint, test, and both builds with no file edited. Not judged: This sprint does not edit the template or project generator; generated-project acceptance is owned by the later template-editing sprints.\n\nAll judged anchors are satisfied or not applicable.\n\n"
  },
  "error": null,
  "metadata": {
    "duration_ms": 30000,
    "tool_calls": 36,
    "retry_count": 0,
    "correlation_id": "pr85-scoped-qa-b14-20261030"
  }
}
```
