```json
{
  "schema_version": "1.0.0",
  "success": true,
  "canceled": false,
  "aborted_by": null,
  "data": {
    "gate": "plan",
    "item_id": "b-17",
    "run_id": "plan-20261030T073601Z-b-17",
    "run_path": "/Volumes/Extreme Pro/github/sc-runtime-worktrees/plan/spinoff-monty-observability/doc/plan/phase-current/qa-runs/final-scoped-20261030/anchor-rechecks/plan-20261030T073601Z-b-17.json",
    "dry_run": false,
    "reused_run": false,
    "pass": true,
    "failing": [],
    "errors": [],
    "excluded": [
      "ADR-RUN-0305",
      "REQ-CRON-0002",
      "REQ-RUN-0313",
      "REQ-RUN-0314",
      "REQ-RUN-0315",
      "REQ-RUN-0316",
      "REQ-RUN-0317",
      "REQ-RUN-0318",
      "REQ-RUN-0319",
      "REQ-RUN-0320",
      "REQ-RUN-0321",
      "REQ-RUN-0322",
      "REQ-RUN-0323",
      "REQ-RUN-0324",
      "REQ-RUN-0325",
      "REQ-RUN-0326",
      "REQ-RUN-0327",
      "REQ-RUN-0328",
      "REQ-RUN-0329",
      "REQ-RUN-0330",
      "REQ-RUN-0331"
    ],
    "results": [
      {
        "anchor_id": "ADR-RUN-0002",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.92,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.95,
              "no": 0.05,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ADR-RUN-0013",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.96,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.98,
              "no": 0.02,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.03,
              "no": 0.97,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ANC-027",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.91,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.91,
            "probabilities": {
              "no": 0.06,
              "unclear": 0.0,
              "yes": 0.94
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.02,
              "unclear": 0.0,
              "yes": 0.98
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "no": 0.94,
              "unclear": 0.0,
              "yes": 0.06
            }
          }
        }
      },
      {
        "anchor_id": "ANC-028",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.76,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.96,
            "probabilities": {
              "no": 0.03,
              "unclear": 0.0,
              "yes": 0.97
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.91,
            "probabilities": {
              "no": 0.06,
              "unclear": 0.0,
              "yes": 0.94
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.76,
            "probabilities": {
              "no": 0.84,
              "unclear": 0.01,
              "yes": 0.15
            }
          }
        }
      },
      {
        "anchor_id": "ANC-029",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.8,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.02,
              "unclear": 0.0,
              "yes": 0.98
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.94,
            "probabilities": {
              "no": 0.04,
              "unclear": 0.0,
              "yes": 0.96
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.8,
            "probabilities": {
              "no": 0.87,
              "unclear": 0.03,
              "yes": 0.1
            }
          }
        }
      },
      {
        "anchor_id": "ANC-030",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.77,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.96,
            "probabilities": {
              "no": 0.03,
              "unclear": 0.0,
              "yes": 0.97
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.94,
            "probabilities": {
              "no": 0.04,
              "unclear": 0.0,
              "yes": 0.96
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.77,
            "probabilities": {
              "no": 0.85,
              "unclear": 0.03,
              "yes": 0.12
            }
          }
        }
      },
      {
        "anchor_id": "ANC-031",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.85,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.02,
              "unclear": 0.0,
              "yes": 0.98
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.85,
            "probabilities": {
              "no": 0.9,
              "unclear": 0.02,
              "yes": 0.08
            }
          }
        }
      },
      {
        "anchor_id": "ANC-032",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.66,
        "attempts": 2,
        "confirmed": true,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.66,
            "probabilities": {
              "no": 0.22,
              "unclear": 0.01,
              "yes": 0.77
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.02,
              "unclear": 0.0,
              "yes": 0.98
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ANC-033",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.86,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.86,
            "probabilities": {
              "no": 0.91,
              "unclear": 0.0,
              "yes": 0.09
            }
          }
        }
      },
      {
        "anchor_id": "ANC-034",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.86,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.86,
            "probabilities": {
              "no": 0.91,
              "unclear": 0.01,
              "yes": 0.08
            }
          }
        }
      },
      {
        "anchor_id": "ANC-035",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.97,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.98,
              "unclear": 0.0,
              "yes": 0.02
            }
          }
        }
      },
      {
        "anchor_id": "ANC-036",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.91,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "no": 0.94,
              "unclear": 0.01,
              "yes": 0.05
            }
          }
        }
      },
      {
        "anchor_id": "ANC-037",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.97,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.98,
              "unclear": 0.0,
              "yes": 0.02
            }
          }
        }
      },
      {
        "anchor_id": "ANC-038",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.96,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.96,
            "probabilities": {
              "no": 0.02,
              "unclear": 0.01,
              "yes": 0.97
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "no": 0.97,
              "unclear": 0.0,
              "yes": 0.03
            }
          }
        }
      },
      {
        "anchor_id": "ANC-039",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.99,
              "unclear": 0.0,
              "yes": 0.01
            }
          }
        }
      },
      {
        "anchor_id": "ANC-040",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ANC-041",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.96,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "no": 0.97,
              "unclear": 0.0,
              "yes": 0.03
            }
          }
        }
      },
      {
        "anchor_id": "ANC-042",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.89,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.89,
            "probabilities": {
              "no": 0.07,
              "unclear": 0.0,
              "yes": 0.93
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.98,
              "unclear": 0.0,
              "yes": 0.02
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0001",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.96,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.97,
              "no": 0.02,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.03,
              "no": 0.97,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0003",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.88,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.98,
              "no": 0.02,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "yes": 0.08,
              "no": 0.92,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0004",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.85,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.89,
            "probabilities": {
              "yes": 0.93,
              "no": 0.06,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.85,
            "probabilities": {
              "yes": 0.08,
              "no": 0.9,
              "unclear": 0.02
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0005",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0503",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.86,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.97,
              "no": 0.03,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.99,
              "no": 0.01,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.86,
            "probabilities": {
              "yes": 0.08,
              "no": 0.91,
              "unclear": 0.01
            }
          }
        }
      },
      {
        "anchor_id": "ADR-RUN-0305",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-CRON-0002",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not change the cron expression parser or five-field schedule semantics.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not change the cron expression parser or five-field schedule semantics."
        }
      },
      {
        "anchor_id": "REQ-RUN-0313",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0314",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0315",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0316",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0317",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0318",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0319",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0320",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0321",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0322",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0323",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0324",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0325",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0326",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0327",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0328",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0329",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not change generated package names or their naming algorithm.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not change generated package names or their naming algorithm."
        }
      },
      {
        "anchor_id": "REQ-RUN-0330",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add or generate database schema/types crates or relocate row structs.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not add or generate database schema/types crates or relocate row structs."
        }
      },
      {
        "anchor_id": "REQ-RUN-0331",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not change the generated CLI/MCP/HTTP database command surface.",
        "answers": null,
        "exclusion": {
          "item": "b-17",
          "reason": "This sprint does not change the generated CLI/MCP/HTTP database command surface."
        }
      }
    ],
    "overrides_applied": [
      "ANC-027",
      "ANC-028",
      "ANC-029",
      "ANC-030",
      "ANC-031",
      "ANC-032",
      "ANC-033",
      "ANC-034",
      "ANC-035",
      "ANC-036",
      "ANC-037",
      "ANC-038",
      "ANC-039",
      "ANC-040",
      "ANC-041",
      "ANC-042"
    ],
    "item_truncated": false,
    "shortened": [],
    "report_markdown": "## Anchor gate: plan · b-17 - Sprint b-17 — shared Python/Monty hook environment\n\nRun `plan-20261030T073601Z-b-17`, model `jev-1.14.0`, threshold 0.6. Counts: satisfied 23, excluded 21.\n\n> **b-17 · ADR-RUN-0305 · excluded** Anchor: SQLite and Postgres meet in an adaptor crate generated into the consumer repository. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-CRON-0002 · excluded** Anchor: A sc-cron schedule is a normal crontab string of five fields: minute, hour, day of month, month, and day of week. Not judged: This sprint does not change the cron expression parser or five-field schedule semantics.\n\n> **b-17 · REQ-RUN-0313 · excluded** Anchor: The relationship between the local SQLite store and the remote Postgres or SQL store is defined in an adaptor crate on the consumer repository. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0314 · excluded** Anchor: The copy adaptor is a local SQLite database with the remote schema, for faster or offline access. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0315 · excluded** Anchor: The host-aggregate adaptor is one SQLite database for this host and a Postgres database that aggregates many hosts. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0316 · excluded** Anchor: The consumer repository defines the rollup from host rows into the Postgres aggregate. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0317 · excluded** Anchor: Adaptor Rust code and models in a new repository are generated by the command just new (scripts/new_project.py). Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0318 · excluded** Anchor: The library crate named sc-runtime does not generate adaptor code. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0319 · excluded** Anchor: Generation flags name tables and columns that exist on only one of the two stores. A skipped table may be the SQLite table or the SQL-server table. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0320 · excluded** Anchor: Every consumer repository uses the same generated implementation of the copy pattern and the same generated implementation of the host-aggregate pattern. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0321 · excluded** Anchor: Each database engine's SQL is in that engine's store crate. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0322 · excluded** Anchor: An adaptor that is neither the copy pattern nor the host-aggregate pattern is written by the consumer from the store building blocks. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0323 · excluded** Anchor: Store synchronization is scheduled by the consuming application. The adaptor starts no timer. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0324 · excluded** Anchor: The consumer adaptor moves rows between the local store and the remote store. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0325 · excluded** Anchor: The sc-runtime crates do not move rows between stores. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0326 · excluded** Anchor: A new application is created with no database, with SQLite only, with one sqlx SQL engine only, or with SQLite plus one sqlx SQL engine. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0327 · excluded** Anchor: Two stores in one application use the same schema or a similar schema. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0328 · excluded** Anchor: Two stores in one application use one shared trait or a different trait per store. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-17 · REQ-RUN-0329 · excluded** Anchor: A generated crate's package name is the project name, a hyphen, and its role. Not judged: This sprint does not change generated package names or their naming algorithm.\n\n> **b-17 · REQ-RUN-0330 · excluded** Anchor: Row type structs are in the schema crate. The types crate is for non-database types. Not judged: This sprint does not add or generate database schema/types crates or relocate row structs.\n\n> **b-17 · REQ-RUN-0331 · excluded** Anchor: The template ships general database commands on the CLI, MCP, and HTTP, including delete row <table> <id>. The consumer can disable that surface. Not judged: This sprint does not change the generated CLI/MCP/HTTP database command surface.\n\nAll judged anchors are satisfied or not applicable.\n\n"
  },
  "error": null,
  "metadata": {
    "duration_ms": 10000,
    "tool_calls": 35,
    "retry_count": 1,
    "correlation_id": "pr85-scoped-qa-b17-20261030"
  }
}
```
