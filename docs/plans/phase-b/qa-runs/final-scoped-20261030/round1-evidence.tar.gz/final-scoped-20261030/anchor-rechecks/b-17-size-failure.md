```json
{
  "schema_version": "1.0.0",
  "success": false,
  "canceled": false,
  "aborted_by": null,
  "data": null,
  "error": {
    "code": "PLAN.TOO_LARGE",
    "message": "plan bead b-17 is 20600 characters after long code was reduced to signatures (17147 prose, 3453 code; by section: Public model 5327, Resolution and authorization 2941, Runtime delivery and redaction 2562, Acceptance criteria 2530, (title) 2009, Persisted and daemon configuration 1410, Goal and relations 1371, Required work and deliverables 1290, First-release schema 611, Required validation 283, This sprint does not close 233); with REQ-CRON-0001 and its questions the request is 24011 bytes, over --max-request-bytes 24000. A reasonable plan bead fits in one Jev request; this one is asking too much",
    "recoverable": false,
    "suggested_action": "Oversize is a symptom; judge its cause before changing the bead. First remove work that no anchor, requirement or user-approved issue asks for and the change does not need. Then cut prose and process ceremony that does not serve a deliverable. Split only approved work that is still too large after that. Never split, trim or raise a limit just to pass the gate. See references/plan-size-and-shape.md"
  },
  "metadata": {
    "duration_ms": 8900,
    "tool_calls": 33,
    "retry_count": 0,
    "correlation_id": "pr85-scoped-qa-b17-20261030"
  }
}
```
