```json
{
  "schema_version": "1.0.0",
  "success": false,
  "canceled": false,
  "aborted_by": null,
  "data": null,
  "error": {
    "code": "JEV.NETWORK",
    "message": "23 of 23 judged cells got no answer from Jev: ADR-RUN-0002: JEV.NETWORK (Could not reach Jev: [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1006)); ADR-RUN-0013: JEV.NETWORK (Could not reach Jev: [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1006)); ANC-027: JEV.NETWORK (Could not reach Jev: [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1006)); ANC-028: JEV.NETWORK (Could not reach Jev: [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1006)); ANC-029: JEV.NETWORK (Could not reach Jev: [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1006)); +18 more",
    "recoverable": true,
    "suggested_action": "Check network access and retry."
  },
  "metadata": {
    "duration_ms": 57000,
    "tool_calls": 35,
    "retry_count": 46,
    "correlation_id": "pr85-scoped-qa-b17-20261030"
  }
}
```
