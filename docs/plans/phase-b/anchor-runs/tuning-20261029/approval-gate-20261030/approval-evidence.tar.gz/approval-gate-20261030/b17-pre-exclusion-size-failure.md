```json
{
  "schema_version": "1.0.0",
  "success": false,
  "canceled": false,
  "aborted_by": null,
  "data": null,
  "error": {
    "code": "PLAN.TOO_LARGE",
    "message": "plan bead b-17 is 20627 characters after long code was reduced to signatures (17174 prose, 3453 code; by section: Public model 5327, Resolution and authorization 2941, Runtime delivery and redaction 2562, Acceptance criteria 2530, (title) 1975, Goal and relations 1489, Persisted and daemon configuration 1473, Required work and deliverables 1142, First-release schema 611, Required validation 283, This sprint does not close 261); with REQ-CRON-0001 and its questions the request is 24036 bytes, over --max-request-bytes 24000. A reasonable plan bead fits in one Jev request; this one is asking too much",
    "recoverable": false,
    "suggested_action": "Oversize is a symptom; judge its cause before changing the bead. First remove work that no anchor, requirement or user-approved issue asks for and the change does not need. Then cut prose and process ceremony that does not serve a deliverable. Split only approved work that is still too large after that. Never split, trim or raise a limit just to pass the gate. See references/plan-size-and-shape.md"
  },
  "metadata": {
    "duration_ms": 40000,
    "tool_calls": 44,
    "retry_count": 0,
    "correlation_id": "phase-b-approval-b17-planfix-20261030"
  }
}
```
