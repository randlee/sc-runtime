```json
{
  "schema_version": "1.0.0",
  "success": false,
  "canceled": false,
  "aborted_by": null,
  "data": null,
  "error": {
    "code": "PLAN.TOO_LARGE",
    "message": "plan bead b-13 is 20638 characters after long code was reduced to signatures (18592 prose, 2046 code; by section: Required work and deliverables 5216, Public signatures fixed here 4413, Upstream artifact consumed 3035, (title) 1973, Acceptance criteria 1794, Canonical `LogEvent` construction 1746, Public release contract 893, Goal 869, Required validation 234, Relations 208, This sprint does not close 200); with REQ-CRON-0001 and its questions the request is 24082 bytes, over --max-request-bytes 24000. A reasonable plan bead fits in one Jev request; this one is asking too much",
    "recoverable": false,
    "suggested_action": "Oversize is a symptom; judge its cause before changing the bead. First remove work that no anchor, requirement or user-approved issue asks for and the change does not need. Then cut prose and process ceremony that does not serve a deliverable. Split only approved work that is still too large after that. Never split, trim or raise a limit just to pass the gate. See references/plan-size-and-shape.md"
  },
  "metadata": {
    "duration_ms": 56115,
    "tool_calls": 7,
    "retry_count": 0,
    "correlation_id": "phase-b-approval-b13-planfix-20261030"
  }
}
```
