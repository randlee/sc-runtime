```json
{
  "schema_version": "1.0.0",
  "success": false,
  "canceled": false,
  "aborted_by": null,
  "data": null,
  "error": {
    "code": "PLAN.TOO_LARGE",
    "message": "plan bead b-18 is 21075 characters after long code was reduced to signatures (20321 prose, 754 code; by section: Required work and deliverables 5355, (title) 5213, Fixed composition signatures 4189, Acceptance criteria 3356, Consumed artifacts 1338, Required validation 664, Relations 439, Goal 311, This sprint does not close 177); with REQ-CRON-0001 and its questions the request is 24529 bytes, over --max-request-bytes 24000. A reasonable plan bead fits in one Jev request; this one is asking too much",
    "recoverable": false,
    "suggested_action": "Oversize is a symptom; judge its cause before changing the bead. First remove work that no anchor, requirement or user-approved issue asks for and the change does not need. Then cut prose and process ceremony that does not serve a deliverable. Split only approved work that is still too large after that. Never split, trim or raise a limit just to pass the gate. See references/plan-size-and-shape.md"
  },
  "script_data": {
    "item_id": "b-18",
    "size": {
      "sections": {
        "(title)": 5213,
        "Goal": 311,
        "Relations": 439,
        "Consumed artifacts": 1338,
        "Fixed composition signatures": 4189,
        "Required work and deliverables": 5355,
        "Acceptance criteria": 3356,
        "Required validation": 664,
        "This sprint does not close": 177
      },
      "code_chars": 754,
      "prose_chars": 20321
    },
    "shape": {
      "chars": 21075,
      "chars_after_reduction": 21075,
      "code_reduced": {"blocks": 3, "lines": 64},
      "sections": {
        "title": 5213,
        "goal": 311,
        "relations": 439,
        "consumed_artifacts": 1338,
        "fixed_composition_signatures": 4189,
        "required_work_and_deliverables": 5355,
        "acceptance_criteria": 3356,
        "required_validation": 664,
        "this_sprint_does_not_close": 177
      },
      "code_chars": 754,
      "prose_chars": 20321,
      "code_lines": 14,
      "prose_lines": 360,
      "fenced_blocks": 3,
      "bullets": 150,
      "table_rows": 10,
      "references": {"github": [], "req": [], "adr": [], "anc": ["ANC-031", "ANC-034"]},
      "no_issue_reference": false,
      "chars_before_reduction": 24770
    }
  },
  "metadata": {
    "duration_ms": 23000,
    "tool_calls": 35,
    "retry_count": 0,
    "correlation_id": "phase-b-approval-b18-planfix-20261030"
  }
}
```
