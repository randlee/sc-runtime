```json
{
  "schema_version": "1.0.0",
  "success": true,
  "canceled": false,
  "aborted_by": null,
  "data": {
    "gate": "plan",
    "item_id": "b-13",
    "run_id": "plan-20261030T050531Z-b-13",
    "run_path": "doc/plan/phase-current/anchor-runs/tuning-20261029/approval-gate-20261030/plan-20261030T050531Z-b-13.json",
    "dry_run": false,
    "reused_run": false,
    "pass": false,
    "failing": [
      "ANC-028",
      "ANC-032",
      "ANC-033",
      "ANC-035",
      "ANC-037",
      "ANC-041",
      "REQ-CRON-0002",
      "REQ-CRON-0004",
      "REQ-RUN-0318",
      "REQ-RUN-0323"
    ],
    "errors": [],
    "excluded": [],
    "results": [
      {
        "anchor_id": "ANC-028",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Embedding applications can register additional Monty host functions without modifying sc-cron.",
        "quote": "the primary requirement of being able to be extensible w/ other apps/calls is supported.",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "An integration test registers and invokes a consumer-defined host function.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The anchor does not apply to this item.",
              "unclear": "The item does not identify enough work to decide applicability.",
              "yes": "The anchor applies to this item."
            },
            "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item is silent, merely topical, or includes only the opposite behavior.",
              "unclear": "The text might include the requirement but is too indefinite to tell.",
              "yes": "The item explicitly plans or preserves the required behavior or boundary."
            },
            "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "The item can coexist with the anchor, including when silent.",
              "unclear": "The item leaves a potentially decisive choice unspecified.",
              "yes": "A stated plan would violate the anchor."
            },
            "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
            "type": "choice"
          }
        },
        "near_threshold": true,
        "confirmed": true,
        "verdict": "underspecified",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.26,
            "probabilities": {
              "no": 0.51,
              "unclear": 0.01,
              "yes": 0.48
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.56,
            "probabilities": {
              "no": 0.71,
              "unclear": 0.05,
              "yes": 0.24
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.52,
            "probabilities": {
              "no": 0.68,
              "unclear": 0.06,
              "yes": 0.26
            }
          }
        },
        "min_confidence": 0.26,
        "explanation": "Jev was not confident (min confidence 0.26); the anchor or the bead may be underspecified.",
        "usage": {
          "input_tokens": 6356,
          "output_tokens": 117
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.26
          },
          {
            "ask": "first",
            "role": "compliance",
            "question_id": "addressed",
            "choice": "no",
            "confidence": 0.56
          },
          {
            "ask": "first",
            "role": "conflict",
            "question_id": "contradicted",
            "choice": "no",
            "confidence": 0.52
          }
        ],
        "attempts": 2,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 22291,
        "to_fix": {
          "where": null,
          "change": "exclude --id ANC-028 --item b-13 --reason \"This item carries the logger through internal Monty execution paths; it does not change the application-owned host-function registration seam, which is assigned to b-16.\""
        }
      },
      {
        "anchor_id": "ANC-032",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "render_template is not required by the sc-cron product contract.",
        "quote": "render_template is not a product requirement",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 3,
        "deterministic_check": "Product requirements and acceptance do not require render_template.",
        "kind": "prohibition",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f826ddd4cc1178bb42b5729fb97e85e6b3b2ab65498cde66ea0ee1dfa98a0a26",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The work is independent of the governed subject.",
              "unclear": "The work area is too vague to determine applicability.",
              "yes": "The work touches the governed subject directly or as a clear prerequisite."
            },
            "instructions": "Does item.text plan work on the governed activity, component, or artifact named by anchor.statement and anchor.scope? Judge applicability only, including dependencies.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item omits the obligation or describes only a conflicting action.",
              "unclear": "The item gestures at the obligation but does not settle whether it is included.",
              "yes": "The required action or constraint is explicitly included."
            },
            "instructions": "Does item.text expressly include the specific obligation in anchor.statement as a planned step or constraint? A subject mention, silence, or opposing action does not satisfy the obligation.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "No incompatible behavior is proposed.",
              "unclear": "A possible conflict depends on an unresolved detail.",
              "yes": "The item commits to an incompatible behavior or boundary."
            },
            "instructions": "Does item.text commit to behavior that cannot coexist with anchor.statement? Silence, topical mention, and an expressly permitted exception are not conflicts.",
            "type": "choice"
          }
        },
        "near_threshold": true,
        "confirmed": true,
        "verdict": "underspecified",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.5,
            "probabilities": {
              "no": 0.67,
              "unclear": 0.02,
              "yes": 0.31
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.98,
              "unclear": 0.01,
              "yes": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "no": 0.95,
              "unclear": 0.02,
              "yes": 0.03
            }
          }
        },
        "min_confidence": 0.5,
        "explanation": "Jev was not confident (min confidence 0.50); the anchor or the bead may be underspecified.",
        "usage": {
          "input_tokens": 6379,
          "output_tokens": 117
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.5
          }
        ],
        "attempts": 2,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 22398,
        "to_fix": {
          "where": null,
          "change": "exclude --id ANC-032 --item b-13 --reason \"This observability and release-contract item does not implement or change render_template.\""
        }
      },
      {
        "anchor_id": "ANC-033",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "MVP executes application-supplied Monty scripts without script signing or a separate approval mechanism.",
        "quote": "for mvp this is not something available for consumers to do.",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 3,
        "deterministic_check": "MVP execution requires neither signatures nor approval configuration.",
        "kind": "prohibition",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "51ecb3cc44b751a0719c40aba67ba5d6ee1de19e77bdc74ffbf6b1265932fa10",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The item is about a different part of the system or a different activity, and completing it would neither follow nor break the anchor.",
              "unclear": "The item text is too vague to tell what part of the system it touches.",
              "yes": "The item plans, changes, or depends on the thing the anchor statement is about, directly or as a clear prerequisite."
            },
            "instructions": "The state holds one planning item (`item.title`, `item.text`) and one anchor: a directive the user stated verbatim in `anchor.statement`, with the area it governs in `anchor.scope`. Does the work described in `item.text` touch the subject that `anchor.statement` talks about? Judge overlap of subject matter only. Do not judge whether the item obeys the anchor.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item omits this complete rule or retains either gate.",
              "unclear": "The item names the gates but leaves whether either is mandatory unresolved.",
              "yes": "The item explicitly permits MVP execution without signatures and without separate approval."
            },
            "instructions": "Does item.text explicitly preserve BOTH parts of the MVP execution rule in anchor.statement: no mandatory script signing and no separate approval mechanism? A plan that retains either gate does not carry the complete rule forward.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "Nothing in the item text conflicts with the directive, whether or not the directive is mentioned.",
              "unclear": "The item text is ambiguous enough that it might or might not conflict with the directive.",
              "yes": "The item text states a plan, approach, or decision that cannot be reconciled with the directive in the anchor statement."
            },
            "instructions": "Does `item.text` propose doing something that `anchor.statement` rules out, or propose a different approach than the one `anchor.statement` requires? Examples of contradiction: the anchor says to start from an existing implementation and the item plans a fresh implementation; the anchor forbids a dependency and the item adds it; the anchor fixes an order of work and the item reverses it. Silence about the directive is not a contradiction. Judge conflict only.",
            "type": "choice"
          }
        },
        "verdict": "underspecified",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.82,
            "probabilities": {
              "no": 0.12,
              "unclear": 0.0,
              "yes": 0.88
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.34,
            "probabilities": {
              "no": 0.56,
              "unclear": 0.02,
              "yes": 0.42
            }
          }
        },
        "min_confidence": 0.34,
        "explanation": "Jev was not confident (min confidence 0.34); the anchor or the bead may be underspecified.",
        "usage": {
          "input_tokens": 6572,
          "output_tokens": 117
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "conflict",
            "question_id": "contradicted",
            "choice": "no",
            "confidence": 0.34
          }
        ],
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23297,
        "to_fix": {
          "where": "It preserves execution and recovery behavior and adds no MVP script signing, separate approval mechanism, or consumer option enabling either.",
          "change": "No plan defect is apparent: the item explicitly preserves the no-signing/no-approval policy. Report Jev’s low-confidence conflict result for user triage."
        }
      },
      {
        "anchor_id": "ANC-035",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Hooks inherit daemon-process environment values only through variable names explicitly allowed by daemon configuration.",
        "quote": "whitelisting api keys globally (by name) in config file (this is really a daemon scope decision)",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "An allowed daemon value is delivered and an unlisted value is absent.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f826ddd4cc1178bb42b5729fb97e85e6b3b2ab65498cde66ea0ee1dfa98a0a26",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The work is independent of the governed subject.",
              "unclear": "The work area is too vague to determine applicability.",
              "yes": "The work touches the governed subject directly or as a clear prerequisite."
            },
            "instructions": "Does item.text plan work on the governed activity, component, or artifact named by anchor.statement and anchor.scope? Judge applicability only, including dependencies.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item omits the obligation or describes only a conflicting action.",
              "unclear": "The item gestures at the obligation but does not settle whether it is included.",
              "yes": "The required action or constraint is explicitly included."
            },
            "instructions": "Does item.text expressly include the specific obligation in anchor.statement as a planned step or constraint? A subject mention, silence, or opposing action does not satisfy the obligation.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "No incompatible behavior is proposed.",
              "unclear": "A possible conflict depends on an unresolved detail.",
              "yes": "The item commits to an incompatible behavior or boundary."
            },
            "instructions": "Does item.text commit to behavior that cannot coexist with anchor.statement? Silence, topical mention, and an expressly permitted exception are not conflicts.",
            "type": "choice"
          }
        },
        "verdict": "underspecified",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.43,
            "probabilities": {
              "no": 0.62,
              "unclear": 0.02,
              "yes": 0.36
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "no": 0.97,
              "unclear": 0.02,
              "yes": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.83,
            "probabilities": {
              "no": 0.89,
              "unclear": 0.05,
              "yes": 0.06
            }
          }
        },
        "min_confidence": 0.43,
        "explanation": "Jev was not confident (min confidence 0.43); the anchor or the bead may be underspecified.",
        "usage": {
          "input_tokens": 6379,
          "output_tokens": 117
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.43
          }
        ],
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 22457,
        "to_fix": {
          "where": null,
          "change": "exclude --id ANC-035 --item b-13 --reason \"The item changes logging propagation, not daemon environment inheritance or the configured variable allowlist.\""
        }
      },
      {
        "anchor_id": "ANC-037",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Schedule creation and updates never implicitly capture environment values from the caller or daemon process.",
        "quote": "Never capture or persist inherited host values accidentally",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 3,
        "deterministic_check": "Ambient canaries are absent from persisted rows without explicit set input.",
        "kind": "prohibition",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f826ddd4cc1178bb42b5729fb97e85e6b3b2ab65498cde66ea0ee1dfa98a0a26",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The work is independent of the governed subject.",
              "unclear": "The work area is too vague to determine applicability.",
              "yes": "The work touches the governed subject directly or as a clear prerequisite."
            },
            "instructions": "Does item.text plan work on the governed activity, component, or artifact named by anchor.statement and anchor.scope? Judge applicability only, including dependencies.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item omits the obligation or describes only a conflicting action.",
              "unclear": "The item gestures at the obligation but does not settle whether it is included.",
              "yes": "The required action or constraint is explicitly included."
            },
            "instructions": "Does item.text expressly include the specific obligation in anchor.statement as a planned step or constraint? A subject mention, silence, or opposing action does not satisfy the obligation.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "No incompatible behavior is proposed.",
              "unclear": "A possible conflict depends on an unresolved detail.",
              "yes": "The item commits to an incompatible behavior or boundary."
            },
            "instructions": "Does item.text commit to behavior that cannot coexist with anchor.statement? Silence, topical mention, and an expressly permitted exception are not conflicts.",
            "type": "choice"
          }
        },
        "verdict": "underspecified",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.28,
            "probabilities": {
              "no": 0.52,
              "unclear": 0.01,
              "yes": 0.47
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.64,
            "probabilities": {
              "no": 0.76,
              "unclear": 0.04,
              "yes": 0.2
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "no": 0.92,
              "unclear": 0.01,
              "yes": 0.07
            }
          }
        },
        "min_confidence": 0.28,
        "explanation": "Jev was not confident (min confidence 0.28); the anchor or the bead may be underspecified.",
        "usage": {
          "input_tokens": 6380,
          "output_tokens": 117
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.28
          }
        ],
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 22435,
        "to_fix": {
          "where": null,
          "change": "exclude --id ANC-037 --item b-13 --reason \"The item does not change schedule creation or updates or capture environment values.\""
        }
      },
      {
        "anchor_id": "ANC-041",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Monty scripts can read their configured environment during source initialization, before hook functions run.",
        "quote": "there should also be the ability to set environment variables in a monty script before it runs.",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "A top-level getenv reads the configured snapshot before cron_stop or cron_tick.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f826ddd4cc1178bb42b5729fb97e85e6b3b2ab65498cde66ea0ee1dfa98a0a26",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The work is independent of the governed subject.",
              "unclear": "The work area is too vague to determine applicability.",
              "yes": "The work touches the governed subject directly or as a clear prerequisite."
            },
            "instructions": "Does item.text plan work on the governed activity, component, or artifact named by anchor.statement and anchor.scope? Judge applicability only, including dependencies.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item omits the obligation or describes only a conflicting action.",
              "unclear": "The item gestures at the obligation but does not settle whether it is included.",
              "yes": "The required action or constraint is explicitly included."
            },
            "instructions": "Does item.text expressly include the specific obligation in anchor.statement as a planned step or constraint? A subject mention, silence, or opposing action does not satisfy the obligation.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "No incompatible behavior is proposed.",
              "unclear": "A possible conflict depends on an unresolved detail.",
              "yes": "The item commits to an incompatible behavior or boundary."
            },
            "instructions": "Does item.text commit to behavior that cannot coexist with anchor.statement? Silence, topical mention, and an expressly permitted exception are not conflicts.",
            "type": "choice"
          }
        },
        "near_threshold": true,
        "unstable": true,
        "answers_second": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.6,
            "probabilities": {
              "no": 0.73,
              "unclear": 0.01,
              "yes": 0.26
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.98,
              "unclear": 0.01,
              "yes": 0.01
            }
          }
        },
        "verdict_first": "underspecified",
        "verdict_second": "not_applicable",
        "verdict": "underspecified",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.52,
            "probabilities": {
              "no": 0.68,
              "unclear": 0.01,
              "yes": 0.31
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "no": 0.97,
              "unclear": 0.01,
              "yes": 0.02
            }
          }
        },
        "min_confidence": 0.52,
        "explanation": "Jev was not confident (min confidence 0.52); the anchor or the bead may be underspecified.",
        "usage": {
          "input_tokens": 6381,
          "output_tokens": 117
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.52
          }
        ],
        "attempts": 2,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 22442,
        "to_fix": {
          "where": "Internal `run_compose_*_with_logger`, `drive_feed`, and `execute_feed_with_logger` functions carry the same handle through `monty_compose.rs`, `monty_host.rs`, and `monty_run.rs`; their legacy forms delegate with the Noop.",
          "change": "State that logger propagation preserves configured Monty environment availability during source initialization, before hook functions run. Authority: ANC-041."
        }
      },
      {
        "anchor_id": "REQ-CRON-0002",
        "source_type": "REQ",
        "source_ref": "REQ-CRON-0002",
        "statement": "A sc-cron schedule is a normal crontab string of five fields: minute, hour, day of month, month, and day of week.",
        "quote": "CronExpr::parse of */5 * * * * succeeds and means every fifth minute. CronExpr::parse of 0 */5 * * * * succeeds and means second 0 of every fifth minute. CronExpr::parse of @hourly succeeds.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "requirements register",
        "anchor_version": 3,
        "deterministic_check": "A test expects parsing */5 * * * * to mean every fifth minute.",
        "kind": "directive",
        "leaning": "not_addressed",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "underspecified",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.25,
            "probabilities": {
              "yes": 0.5,
              "no": 0.49,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.01,
              "no": 0.95,
              "unclear": 0.04
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        },
        "min_confidence": 0.25,
        "explanation": "Jev was not confident (min confidence 0.25); the anchor or the bead may be underspecified.",
        "usage": {
          "input_tokens": 6675,
          "output_tokens": 117
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "yes",
            "confidence": 0.25
          }
        ],
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23680,
        "to_fix": {
          "where": null,
          "change": "exclude --id REQ-CRON-0002 --item b-13 --reason \"The item preserves scheduling behavior and does not change CronExpr parsing or the five-field schedule format.\""
        }
      },
      {
        "anchor_id": "REQ-CRON-0004",
        "source_type": "REQ",
        "source_ref": "REQ-CRON-0004",
        "statement": "The sc-cron crate creates one schedule table. A test writes a row without constructing SqliteWriter. The crate does not migrate the consumer's other tables.",
        "quote": "The sc-cron crate creates one schedule table. A test writes a row without constructing SqliteWriter. The crate does not migrate the consumer's other tables.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "requirements register",
        "anchor_version": 2,
        "deterministic_check": "A test writes a schedule row without constructing SqliteWriter.",
        "kind": "directive",
        "leaning": "not_addressed",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "near_threshold": true,
        "unstable": true,
        "answers_second": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.66,
            "probabilities": {
              "yes": 0.77,
              "no": 0.22,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "yes": 0.02,
              "no": 0.92,
              "unclear": 0.06
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.03,
              "no": 0.96,
              "unclear": 0.01
            }
          }
        },
        "verdict_first": "underspecified",
        "verdict_second": "not_addressed",
        "verdict": "underspecified",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.53,
            "probabilities": {
              "yes": 0.69,
              "no": 0.3,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.85,
            "probabilities": {
              "yes": 0.03,
              "no": 0.9,
              "unclear": 0.07
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.04,
              "no": 0.95,
              "unclear": 0.01
            }
          }
        },
        "min_confidence": 0.53,
        "explanation": "Jev was not confident (min confidence 0.53); the anchor or the bead may be underspecified.",
        "usage": {
          "input_tokens": 6677,
          "output_tokens": 117
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "yes",
            "confidence": 0.53
          }
        ],
        "attempts": 2,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23724,
        "to_fix": {
          "where": "`SqliteScheduleStore::open_with_logger` delegates to the existing store setup while adding the logger handle.",
          "change": "State that the observability change preserves the single schedule table, permits writing its row without constructing SqliteWriter, and does not migrate consumer tables. Authority: REQ-CRON-0004."
        }
      },
      {
        "anchor_id": "REQ-RUN-0318",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0318",
        "statement": "The library crate named sc-runtime does not generate adaptor code.",
        "quote": "The library crate named sc-runtime does not generate adaptor code.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "crates/sc-runtime contains no generator.",
        "kind": "prohibition",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "near_threshold": true,
        "unstable": true,
        "answers_second": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.55,
            "probabilities": {
              "yes": 0.29,
              "no": 0.7,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.86,
            "probabilities": {
              "yes": 0.05,
              "no": 0.91,
              "unclear": 0.04
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.89,
            "probabilities": {
              "yes": 0.06,
              "no": 0.93,
              "unclear": 0.01
            }
          }
        },
        "verdict_first": "not_applicable",
        "verdict_second": "underspecified",
        "verdict": "underspecified",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.67,
            "probabilities": {
              "yes": 0.22,
              "no": 0.78,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "yes": 0.05,
              "no": 0.92,
              "unclear": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "yes": 0.05,
              "no": 0.94,
              "unclear": 0.01
            }
          }
        },
        "min_confidence": 0.55,
        "explanation": "Jev was not confident (min confidence 0.55); the anchor or the bead may be underspecified.",
        "usage": {
          "input_tokens": 6657,
          "output_tokens": 117
        },
        "low_questions": [
          {
            "ask": "second",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.55
          }
        ],
        "attempts": 2,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23640,
        "to_fix": {
          "where": null,
          "change": "exclude --id REQ-RUN-0318 --item b-13 --reason \"This item changes library observability and release metadata; it does not generate adaptor code.\""
        }
      },
      {
        "anchor_id": "REQ-RUN-0323",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0323",
        "statement": "Store synchronization is scheduled by the consuming application. The adaptor starts no timer.",
        "quote": "Store synchronization is scheduled by the consuming application. The adaptor starts no timer.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "The adaptor crate starts no timer. A schedule is registered by application code.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "near_threshold": true,
        "unstable": true,
        "answers_second": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.53,
            "probabilities": {
              "yes": 0.3,
              "no": 0.69,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.0,
              "no": 0.98,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "yes": 0.05,
              "no": 0.94,
              "unclear": 0.01
            }
          }
        },
        "verdict_first": "not_applicable",
        "verdict_second": "underspecified",
        "verdict": "underspecified",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.6,
            "probabilities": {
              "yes": 0.26,
              "no": 0.73,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.0,
              "no": 0.99,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.83,
            "probabilities": {
              "yes": 0.09,
              "no": 0.89,
              "unclear": 0.02
            }
          }
        },
        "min_confidence": 0.53,
        "explanation": "Jev was not confident (min confidence 0.53); the anchor or the bead may be underspecified.",
        "usage": {
          "input_tokens": 6660,
          "output_tokens": 117
        },
        "low_questions": [
          {
            "ask": "second",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.53
          }
        ],
        "attempts": 2,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23667,
        "to_fix": {
          "where": "sc-cron is a general-purpose optional SQLite cron library for application-defined Rust, Python, and optional Monty jobs.",
          "change": "State that consumers own store-synchronization scheduling and the library/adaptor does not start a store-sync timer. Authority: REQ-RUN-0323."
        }
      },
      {
        "anchor_id": "ADR-RUN-0002",
        "source_type": "ADR",
        "source_ref": "ADR-RUN-0002",
        "statement": "sc-runtime is a cargo-generate template plus published library crates.",
        "quote": "sc-runtime is a cargo-generate template plus published library crates.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "requirements register",
        "anchor_version": 2,
        "deterministic_check": "Generated projects depend on the library crates by version, and template code is rendered into the project.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.95,
              "no": 0.05,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.99,
              "no": 0.01,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.02,
              "no": 0.98,
              "unclear": 0.0
            }
          }
        },
        "min_confidence": 0.92,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6658,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23643
      },
      {
        "anchor_id": "ADR-RUN-0013",
        "source_type": "ADR",
        "source_ref": "ADR-RUN-0013",
        "statement": "sc-cron is an optional general-purpose SQLite cron library with Rust/Python/Monty hooks, application-owned host registration, and no MVP script signing or separate approval mechanism.",
        "quote": "sc-cron is an optional SQLite cron crate. A normal schedule string is five fields, minute first. The hook target is a Rust function or a Python module run as python3 <module> cron.tick or cron.stop with one JSON object on stdin.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "Historical register quote retained as immutable provenance. Current statement follows the amended ADR-RUN-0013 authority and owner-approved Phase B continuation ANC-027 through ANC-042 (2026-10-29); the historical quote is not the current normative contract.",
        "anchor_version": 5,
        "deterministic_check": "The optional library provides application-defined job and Monty registration tests, and no MVP signing configuration.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.97,
              "no": 0.03,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.04,
              "no": 0.96,
              "unclear": 0.0
            }
          }
        },
        "min_confidence": 0.94,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6679,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23742
      },
      {
        "anchor_id": "ANC-027",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "sc-cron is a general-purpose cron library supporting application-defined jobs.",
        "quote": "sc-cron is a general-purpose cron library.",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "A consumer can schedule an application-defined job without a tool-specific payload.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The anchor does not apply to this item.",
              "unclear": "The item does not identify enough work to decide applicability.",
              "yes": "The anchor applies to this item."
            },
            "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item is silent, merely topical, or includes only the opposite behavior.",
              "unclear": "The text might include the requirement but is too indefinite to tell.",
              "yes": "The item explicitly plans or preserves the required behavior or boundary."
            },
            "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "The item can coexist with the anchor, including when silent.",
              "unclear": "The item leaves a potentially decisive choice unspecified.",
              "yes": "A stated plan would violate the anchor."
            },
            "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
            "type": "choice"
          }
        },
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.02,
              "unclear": 0.0,
              "yes": 0.98
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.91,
            "probabilities": {
              "no": 0.06,
              "unclear": 0.0,
              "yes": 0.94
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.82,
            "probabilities": {
              "no": 0.88,
              "unclear": 0.01,
              "yes": 0.11
            }
          }
        },
        "min_confidence": 0.82,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6354,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 22276
      },
      {
        "anchor_id": "ANC-031",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Every production release crate excludes sc-compose and ATM crate dependencies and Rust imports, enforced by boundary lint; test and benchmark references are permitted.",
        "quote": "sc-compose and atm crates should be blocked from any production release crate.  sc-compose and atm can be referenced for tests i.e. benchmark tests",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 3,
        "deterministic_check": "Boundary lint rejects production imports/dependencies while permitting test-only references.",
        "kind": "prohibition",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The anchor does not apply to this item.",
              "unclear": "The item does not identify enough work to decide applicability.",
              "yes": "The anchor applies to this item."
            },
            "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item is silent, merely topical, or includes only the opposite behavior.",
              "unclear": "The text might include the requirement but is too indefinite to tell.",
              "yes": "The item explicitly plans or preserves the required behavior or boundary."
            },
            "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "The item can coexist with the anchor, including when silent.",
              "unclear": "The item leaves a potentially decisive choice unspecified.",
              "yes": "A stated plan would violate the anchor."
            },
            "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
            "type": "choice"
          }
        },
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "no": 0.92,
              "unclear": 0.01,
              "yes": 0.07
            }
          }
        },
        "min_confidence": 0.88,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6371,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 22394
      },
      {
        "anchor_id": "REQ-CRON-0001",
        "source_type": "REQ",
        "source_ref": "REQ-CRON-0001",
        "statement": "sc-cron must remain an optional workspace crate; the generated daemon may enable it through cron/monty features while sc-runtime remains independent of sc-cron.",
        "quote": "crates/sc-cron is a workspace member. It depends on no other workspace crate. The template does not name it. The sc-runtime library crate does not name it.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "Historical register quote retained as immutable provenance. Current statement follows the amended REQ-CRON-0001 authority and owner-approved Phase B continuation ANC-027 through ANC-042 (2026-10-29); the historical quote is not the current normative contract.",
        "anchor_version": 5,
        "deterministic_check": "Cargo manifests keep sc-cron optional in generated daemons and absent from sc-runtime dependencies.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.98,
              "no": 0.01,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.85,
            "probabilities": {
              "yes": 0.1,
              "no": 0.9,
              "unclear": 0.0
            }
          }
        },
        "min_confidence": 0.85,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6678,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23726
      },
      {
        "anchor_id": "REQ-CRON-0003",
        "source_type": "REQ",
        "source_ref": "REQ-CRON-0003",
        "statement": "sc-cron must run application-defined Rust, Python, and optional Monty jobs; applications can extend Monty host calls, including sc_compose_run and atm_run CLI adapters, without changing sc-cron.",
        "quote": "A schedule row names either an in-process Rust job or a Python module. For Python, the crate runs python3 <module> cron.tick or python3 <module> cron.stop and writes one JSON object to stdin. The crate exposes no HTTP route, MCP tool, or binary.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "Historical register quote retained as immutable provenance. Current statement follows the amended REQ-CRON-0003 authority and owner-approved Phase B continuation ANC-027 through ANC-042 (2026-10-29); the historical quote is not the current normative contract.",
        "anchor_version": 5,
        "deterministic_check": "Host registry integration tests invoke custom, sc-compose, and ATM functions through one extension interface.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.96,
              "no": 0.04,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.73,
            "probabilities": {
              "yes": 0.82,
              "no": 0.15,
              "unclear": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.79,
            "probabilities": {
              "yes": 0.14,
              "no": 0.86,
              "unclear": 0.0
            }
          }
        },
        "min_confidence": 0.73,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6686,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23754
      },
      {
        "anchor_id": "REQ-CRON-0005",
        "source_type": "REQ",
        "source_ref": "REQ-CRON-0005",
        "statement": "Fallible public functions in sc-cron return CronError.",
        "quote": "Fallible public functions in sc-cron return CronError.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "requirements register",
        "anchor_version": 2,
        "deterministic_check": "The public error type in crates/sc-cron is CronError.",
        "kind": "directive",
        "leaning": "satisfied",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "satisfied",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        },
        "min_confidence": 0.98,
        "explanation": "The directive is carried forward.",
        "usage": {
          "input_tokens": 6657,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23614
      },
      {
        "anchor_id": "ADR-RUN-0305",
        "source_type": "ADR",
        "source_ref": "ADR-RUN-0305",
        "statement": "SQLite and Postgres meet in an adaptor crate generated into the consumer repository.",
        "quote": "SQLite and Postgres meet in an adaptor crate generated into the consumer repository.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "docs/architecture.md contains ADR-RUN-0305.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.79,
            "probabilities": {
              "yes": 0.14,
              "no": 0.86,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.02,
              "no": 0.95,
              "unclear": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.89,
            "probabilities": {
              "yes": 0.06,
              "no": 0.93,
              "unclear": 0.01
            }
          }
        },
        "min_confidence": 0.79,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6660,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23658
      },
      {
        "anchor_id": "ANC-029",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "The sc_compose_run integration supports any sc-compose command/subcommand supplied by an application script.",
        "quote": "sc_compose_run (any subcommand) would be a useful working example for showing how to use sc-cron",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "Argument-forwarding tests cover render and non-render subcommands.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The anchor does not apply to this item.",
              "unclear": "The item does not identify enough work to decide applicability.",
              "yes": "The anchor applies to this item."
            },
            "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item is silent, merely topical, or includes only the opposite behavior.",
              "unclear": "The text might include the requirement but is too indefinite to tell.",
              "yes": "The item explicitly plans or preserves the required behavior or boundary."
            },
            "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "The item can coexist with the anchor, including when silent.",
              "unclear": "The item leaves a potentially decisive choice unspecified.",
              "yes": "A stated plan would violate the anchor."
            },
            "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
            "type": "choice"
          }
        },
        "near_threshold": true,
        "confirmed": true,
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.86,
            "probabilities": {
              "no": 0.91,
              "unclear": 0.01,
              "yes": 0.08
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.85,
            "probabilities": {
              "no": 0.9,
              "unclear": 0.02,
              "yes": 0.08
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.64,
            "probabilities": {
              "no": 0.76,
              "unclear": 0.13,
              "yes": 0.11
            }
          }
        },
        "min_confidence": 0.64,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6361,
          "output_tokens": 117
        },
        "attempts": 2,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 22300
      },
      {
        "anchor_id": "ANC-030",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Phase B provides an atm_run host integration supporting any ATM CLI command/subcommand through the same extension interface used by sc_compose_run.",
        "quote": "i am in agreement.",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Owner approved the preceding proposal: \"Phase B provides an atm_run host integration supporting any ATM CLI command/subcommand through the same extension interface used by sc_compose_run.\" The immutable quote \"i am in agreement.\" is the owner's response approving that exact statement.",
        "anchor_version": 3,
        "deterministic_check": "An ATM executable fixture is invoked through the same registry as sc_compose_run.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The anchor does not apply to this item.",
              "unclear": "The item does not identify enough work to decide applicability.",
              "yes": "The anchor applies to this item."
            },
            "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item is silent, merely topical, or includes only the opposite behavior.",
              "unclear": "The text might include the requirement but is too indefinite to tell.",
              "yes": "The item explicitly plans or preserves the required behavior or boundary."
            },
            "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "The item can coexist with the anchor, including when silent.",
              "unclear": "The item leaves a potentially decisive choice unspecified.",
              "yes": "A stated plan would violate the anchor."
            },
            "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
            "type": "choice"
          }
        },
        "near_threshold": true,
        "confirmed": true,
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "no": 0.95,
              "unclear": 0.0,
              "yes": 0.05
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "no": 0.92,
              "unclear": 0.01,
              "yes": 0.07
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.7,
            "probabilities": {
              "no": 0.8,
              "unclear": 0.03,
              "yes": 0.17
            }
          }
        },
        "min_confidence": 0.7,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6368,
          "output_tokens": 117
        },
        "attempts": 2,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 22340
      },
      {
        "anchor_id": "ANC-034",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Python and Monty hooks use the same schedule-environment configuration and resolution rules.",
        "quote": "python/monty having consistent settings would be least confusing",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "The same environment cases produce equivalent Python and Monty results.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The anchor does not apply to this item.",
              "unclear": "The item does not identify enough work to decide applicability.",
              "yes": "The anchor applies to this item."
            },
            "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item is silent, merely topical, or includes only the opposite behavior.",
              "unclear": "The text might include the requirement but is too indefinite to tell.",
              "yes": "The item explicitly plans or preserves the required behavior or boundary."
            },
            "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "The item can coexist with the anchor, including when silent.",
              "unclear": "The item leaves a potentially decisive choice unspecified.",
              "yes": "A stated plan would violate the anchor."
            },
            "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
            "type": "choice"
          }
        },
        "near_threshold": true,
        "confirmed": true,
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.6,
            "probabilities": {
              "no": 0.73,
              "unclear": 0.02,
              "yes": 0.25
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.79,
            "probabilities": {
              "no": 0.86,
              "unclear": 0.06,
              "yes": 0.08
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.67,
            "probabilities": {
              "no": 0.78,
              "unclear": 0.2,
              "yes": 0.02
            }
          }
        },
        "min_confidence": 0.6,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6357,
          "output_tokens": 117
        },
        "attempts": 2,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 22290
      },
      {
        "anchor_id": "ANC-036",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Each schedule can explicitly set or clear its own environment variables.",
        "quote": "having each entry having the ability to set or clear specific environment variables",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "Two schedules set distinct identities and clearing removes a prior value.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The anchor does not apply to this item.",
              "unclear": "The item does not identify enough work to decide applicability.",
              "yes": "The anchor applies to this item."
            },
            "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item is silent, merely topical, or includes only the opposite behavior.",
              "unclear": "The text might include the requirement but is too indefinite to tell.",
              "yes": "The item explicitly plans or preserves the required behavior or boundary."
            },
            "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "The item can coexist with the anchor, including when silent.",
              "unclear": "The item leaves a potentially decisive choice unspecified.",
              "yes": "A stated plan would violate the anchor."
            },
            "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
            "type": "choice"
          }
        },
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "no": 0.96,
              "unclear": 0.0,
              "yes": 0.04
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.82,
            "probabilities": {
              "no": 0.88,
              "unclear": 0.03,
              "yes": 0.09
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.82,
            "probabilities": {
              "no": 0.88,
              "unclear": 0.06,
              "yes": 0.06
            }
          }
        },
        "min_confidence": 0.82,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6350,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 22280
      },
      {
        "anchor_id": "ANC-038",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "The schedule registry permits deliberately supplied environment values as plaintext configuration.",
        "quote": "why can we never add values?  all environment variables are not api keys?",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "An explicit set value round-trips through the registry.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "e9965576f4baeafd046cab1602c342cfba185667897278270cdc80eb069acb36",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The item is about a different part of the system or a different activity, and completing it would neither follow nor break the anchor.",
              "unclear": "The item text is too vague to tell what part of the system it touches.",
              "yes": "The item plans, changes, or depends on the thing the anchor statement is about, directly or as a clear prerequisite."
            },
            "instructions": "The state holds one planning item (`item.title`, `item.text`) and one anchor: a directive the user stated verbatim in `anchor.statement`, with the area it governs in `anchor.scope`. Does the work described in `item.text` touch the subject that `anchor.statement` talks about? Judge overlap of subject matter only. Do not judge whether the item obeys the anchor.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The plan is silent or denies any permitted class, even if it mentions plaintext.",
              "unclear": "The plan names plaintext values but leaves the allowed class unresolved.",
              "yes": "The plan explicitly preserves the full permitted class of deliberate plaintext set values."
            },
            "instructions": "Does item.text expressly preserve the schedule registry permission to accept every deliberately supplied plaintext environment value, including secret and nonsecret values? Merely mentioning plaintext while banning a value class does not carry the permission forward.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "No incompatible restriction is planned.",
              "unclear": "The planned restriction or its applicability to deliberate set values is unresolved.",
              "yes": "The plan denies or narrows the anchor-permitted plaintext set-value capability."
            },
            "instructions": "Does item.text prohibit or narrow a class of deliberately supplied plaintext environment values that anchor.statement permits in the schedule registry? Treat an explicit secret-only ban as a conflict; silence and permitted handling are not conflicts.",
            "type": "choice"
          }
        },
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.74,
            "probabilities": {
              "no": 0.83,
              "unclear": 0.0,
              "yes": 0.17
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.83,
            "probabilities": {
              "no": 0.89,
              "unclear": 0.04,
              "yes": 0.07
            }
          }
        },
        "min_confidence": 0.74,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6492,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23028
      },
      {
        "anchor_id": "ANC-039",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Schedules can resolve environment values through an application-provided resolver for opaque references.",
        "quote": "I also like allowing this:   \"OTHER_API_KEY\": { \"reference\": \"keychain://agents/planner-7/api-key\" }",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "A consumer resolver supplies a referenced value without persisting the result.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f757ba41a54ab1c5b169ce1c4bc3b6479d9df3d9d5d5e711725f709fe90bed70",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The anchor does not apply to this item.",
              "unclear": "The item does not identify enough work to decide applicability.",
              "yes": "The anchor applies to this item."
            },
            "instructions": "Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item is silent, merely topical, or includes only the opposite behavior.",
              "unclear": "The text might include the requirement but is too indefinite to tell.",
              "yes": "The item explicitly plans or preserves the required behavior or boundary."
            },
            "instructions": "Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "The item can coexist with the anchor, including when silent.",
              "unclear": "The item leaves a potentially decisive choice unspecified.",
              "yes": "A stated plan would violate the anchor."
            },
            "instructions": "Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.",
            "type": "choice"
          }
        },
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "no": 0.95,
              "unclear": 0.0,
              "yes": 0.05
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.89,
            "probabilities": {
              "no": 0.93,
              "unclear": 0.02,
              "yes": 0.05
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.8,
            "probabilities": {
              "no": 0.87,
              "unclear": 0.08,
              "yes": 0.05
            }
          }
        },
        "min_confidence": 0.8,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6353,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 22298
      },
      {
        "anchor_id": "ANC-040",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "Schedules can load environment variables from full-path .env files.",
        "quote": "Another useful way to specify would be loading from a full-path .env file.",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "An authorized absolute dotenv file supplies hook values.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f826ddd4cc1178bb42b5729fb97e85e6b3b2ab65498cde66ea0ee1dfa98a0a26",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The work is independent of the governed subject.",
              "unclear": "The work area is too vague to determine applicability.",
              "yes": "The work touches the governed subject directly or as a clear prerequisite."
            },
            "instructions": "Does item.text plan work on the governed activity, component, or artifact named by anchor.statement and anchor.scope? Judge applicability only, including dependencies.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item omits the obligation or describes only a conflicting action.",
              "unclear": "The item gestures at the obligation but does not settle whether it is included.",
              "yes": "The required action or constraint is explicitly included."
            },
            "instructions": "Does item.text expressly include the specific obligation in anchor.statement as a planned step or constraint? A subject mention, silence, or opposing action does not satisfy the obligation.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "No incompatible behavior is proposed.",
              "unclear": "A possible conflict depends on an unresolved detail.",
              "yes": "The item commits to an incompatible behavior or boundary."
            },
            "instructions": "Does item.text commit to behavior that cannot coexist with anchor.statement? Silence, topical mention, and an expressly permitted exception are not conflicts.",
            "type": "choice"
          }
        },
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "no": 0.92,
              "unclear": 0.0,
              "yes": 0.08
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.99,
              "unclear": 0.01,
              "yes": 0.0
            }
          }
        },
        "min_confidence": 0.88,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6377,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 22394
      },
      {
        "anchor_id": "ANC-042",
        "source_type": "ANC",
        "source_ref": null,
        "statement": "The first released schedule schema establishes one baseline without requiring migrations among unreleased development schemas.",
        "quote": "i don't know why we are on schema v4 when we haven't even released binaries yet.",
        "stated_by": "randlee",
        "stated_at": "2026-10-29",
        "context": "Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected.",
        "anchor_version": 2,
        "deterministic_check": "First-release schema validation does not require a v1-v4 development migration ladder.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": true
        },
        "questions_sha256": "f826ddd4cc1178bb42b5729fb97e85e6b3b2ab65498cde66ea0ee1dfa98a0a26",
        "questions": {
          "relevant": {
            "criteria": {
              "no": "The work is independent of the governed subject.",
              "unclear": "The work area is too vague to determine applicability.",
              "yes": "The work touches the governed subject directly or as a clear prerequisite."
            },
            "instructions": "Does item.text plan work on the governed activity, component, or artifact named by anchor.statement and anchor.scope? Judge applicability only, including dependencies.",
            "type": "choice"
          },
          "addressed": {
            "criteria": {
              "no": "The item omits the obligation or describes only a conflicting action.",
              "unclear": "The item gestures at the obligation but does not settle whether it is included.",
              "yes": "The required action or constraint is explicitly included."
            },
            "instructions": "Does item.text expressly include the specific obligation in anchor.statement as a planned step or constraint? A subject mention, silence, or opposing action does not satisfy the obligation.",
            "type": "choice"
          },
          "contradicted": {
            "criteria": {
              "no": "No incompatible behavior is proposed.",
              "unclear": "A possible conflict depends on an unresolved detail.",
              "yes": "The item commits to an incompatible behavior or boundary."
            },
            "instructions": "Does item.text commit to behavior that cannot coexist with anchor.statement? Silence, topical mention, and an expressly permitted exception are not conflicts.",
            "type": "choice"
          }
        },
        "near_threshold": true,
        "confirmed": true,
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.66,
            "probabilities": {
              "no": 0.77,
              "unclear": 0.01,
              "yes": 0.22
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.89,
            "probabilities": {
              "no": 0.93,
              "unclear": 0.02,
              "yes": 0.05
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "no": 0.95,
              "unclear": 0.01,
              "yes": 0.04
            }
          }
        },
        "min_confidence": 0.66,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6383,
          "output_tokens": 117
        },
        "attempts": 2,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 22449
      },
      {
        "anchor_id": "REQ-RUN-0313",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0313",
        "statement": "The relationship between the local SQLite store and the remote Postgres or SQL store is defined in an adaptor crate on the consumer repository.",
        "quote": "The relationship between the local SQLite store and the remote Postgres or SQL store is defined in an adaptor crate on the consumer repository.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "A generated repository contains an adaptor crate that names both stores.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.8,
            "probabilities": {
              "yes": 0.12,
              "no": 0.87,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.01,
              "no": 0.96,
              "unclear": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.03,
              "no": 0.96,
              "unclear": 0.01
            }
          }
        },
        "min_confidence": 0.8,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6671,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23717
      },
      {
        "anchor_id": "REQ-RUN-0314",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0314",
        "statement": "The copy adaptor is a local SQLite database with the remote schema, for faster or offline access.",
        "quote": "The copy adaptor is a local SQLite database with the remote schema, for faster or offline access.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "A generated copy adaptor creates the shared remote tables in SQLite.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "near_threshold": true,
        "confirmed": true,
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.7,
            "probabilities": {
              "yes": 0.19,
              "no": 0.8,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.01,
              "no": 0.97,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.02,
              "no": 0.97,
              "unclear": 0.01
            }
          }
        },
        "min_confidence": 0.7,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6664,
          "output_tokens": 117
        },
        "attempts": 2,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23671
      },
      {
        "anchor_id": "REQ-RUN-0315",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0315",
        "statement": "The host-aggregate adaptor is one SQLite database for this host and a Postgres database that aggregates many hosts.",
        "quote": "The host-aggregate adaptor is one SQLite database for this host and a Postgres database that aggregates many hosts.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "A generated host-aggregate adaptor documents one SQLite database per host and one Postgres aggregate.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "yes": 0.06,
              "no": 0.94,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.01,
              "no": 0.97,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.04,
              "no": 0.95,
              "unclear": 0.01
            }
          }
        },
        "min_confidence": 0.91,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6669,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23689
      },
      {
        "anchor_id": "REQ-RUN-0316",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0316",
        "statement": "The consumer repository defines the rollup from host rows into the Postgres aggregate.",
        "quote": "The consumer repository defines the rollup from host rows into the Postgres aggregate.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "The host-aggregate adaptor has a consumer-owned function that maps host rows into the Postgres aggregate.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.04,
              "no": 0.96,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.04,
              "no": 0.95,
              "unclear": 0.01
            }
          }
        },
        "min_confidence": 0.92,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6661,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23660
      },
      {
        "anchor_id": "REQ-RUN-0317",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0317",
        "statement": "Adaptor Rust code and models in a new repository are generated by the command just new (scripts/new_project.py).",
        "quote": "Adaptor Rust code and models in a new repository are generated by the command just new (scripts/new_project.py).",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "just new writes the adaptor crate and its models into the new repository.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.03,
              "no": 0.97,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.01,
              "no": 0.97,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        },
        "min_confidence": 0.96,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6669,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23686
      },
      {
        "anchor_id": "REQ-RUN-0319",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0319",
        "statement": "Generation flags name tables and columns that exist on only one of the two stores. A skipped table may be the SQLite table or the SQL-server table.",
        "quote": "Generation flags name tables and columns that exist on only one of the two stores.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 3,
        "deterministic_check": "Generation input can name a SQLite-only table, a SQL-server-only table, and a column that exists on only one side.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.85,
            "probabilities": {
              "yes": 0.1,
              "no": 0.9,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.01,
              "no": 0.98,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        },
        "min_confidence": 0.85,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6675,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23721
      },
      {
        "anchor_id": "REQ-RUN-0320",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0320",
        "statement": "Every consumer repository uses the same generated implementation of the copy pattern and the same generated implementation of the host-aggregate pattern.",
        "quote": "Every consumer repository uses the same generated implementation of the copy pattern and the same generated implementation of the host-aggregate pattern.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "Two generated repositories that select the same pattern contain the same adaptor implementation.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.05,
              "no": 0.95,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.02,
              "no": 0.97,
              "unclear": 0.01
            }
          }
        },
        "min_confidence": 0.92,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6671,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23727
      },
      {
        "anchor_id": "REQ-RUN-0321",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0321",
        "statement": "Each database engine's SQL is in that engine's store crate.",
        "quote": "Generated SQLite code and generated Postgres code are separate files.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 3,
        "deterministic_check": "store-sqlite contains no Postgres SQL, and store-postgres contains no SQLite SQL.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.77,
            "probabilities": {
              "yes": 0.15,
              "no": 0.85,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.01,
              "no": 0.97,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "yes": 0.05,
              "no": 0.94,
              "unclear": 0.01
            }
          }
        },
        "min_confidence": 0.77,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6658,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23633
      },
      {
        "anchor_id": "REQ-RUN-0322",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0322",
        "statement": "An adaptor that is neither the copy pattern nor the host-aggregate pattern is written by the consumer from the store building blocks.",
        "quote": "An adaptor that is neither the copy pattern nor the host-aggregate pattern is written by the consumer from the store building blocks.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 3,
        "deterministic_check": "A third adaptor is a file the consumer wrote.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.89,
            "probabilities": {
              "yes": 0.07,
              "no": 0.93,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.01,
              "no": 0.98,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.04,
              "no": 0.95,
              "unclear": 0.01
            }
          }
        },
        "min_confidence": 0.89,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6672,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23707
      },
      {
        "anchor_id": "REQ-RUN-0324",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0324",
        "statement": "The consumer adaptor moves rows between the local store and the remote store.",
        "quote": "The consumer adaptor moves rows between the local store and the remote store.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "The adaptor crate contains the copy from one store to the other.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.04,
              "no": 0.96,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.02,
              "no": 0.98,
              "unclear": 0.0
            }
          }
        },
        "min_confidence": 0.94,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6659,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23651
      },
      {
        "anchor_id": "REQ-RUN-0325",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0325",
        "statement": "The sc-runtime crates do not move rows between stores.",
        "quote": "The sc-runtime crates do not move rows between stores.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "crates/ contains no store-to-store copy.",
        "kind": "prohibition",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "near_threshold": true,
        "confirmed": true,
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.67,
            "probabilities": {
              "yes": 0.21,
              "no": 0.78,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.01,
              "no": 0.98,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.02,
              "no": 0.98,
              "unclear": 0.0
            }
          }
        },
        "min_confidence": 0.67,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6656,
          "output_tokens": 117
        },
        "attempts": 2,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23628
      },
      {
        "anchor_id": "REQ-RUN-0326",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0326",
        "statement": "A new application is created with no database, with SQLite only, with one sqlx SQL engine only, or with SQLite plus one sqlx SQL engine.",
        "quote": "A new application is created with no database, with SQLite only, with one sqlx SQL engine only, or with SQLite plus one sqlx SQL engine.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 3,
        "deterministic_check": "wizard/answers.schema.json accepts no database, SQLite only, one sqlx SQL engine, and SQLite plus one sqlx SQL engine.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.86,
            "probabilities": {
              "yes": 0.09,
              "no": 0.91,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.03,
              "no": 0.96,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.03,
              "no": 0.97,
              "unclear": 0.0
            }
          }
        },
        "min_confidence": 0.86,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6684,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23749
      },
      {
        "anchor_id": "REQ-RUN-0327",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0327",
        "statement": "Two stores in one application use the same schema or a similar schema.",
        "quote": "Two stores in one application use the same schema or a similar schema.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "The copy pattern uses the same schema on both stores. The host-aggregate pattern uses a similar schema.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.79,
            "probabilities": {
              "yes": 0.14,
              "no": 0.86,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.02,
              "no": 0.97,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.02,
              "no": 0.97,
              "unclear": 0.01
            }
          }
        },
        "min_confidence": 0.79,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6659,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23644
      },
      {
        "anchor_id": "REQ-RUN-0328",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0328",
        "statement": "Two stores in one application use one shared trait or a different trait per store.",
        "quote": "Two stores in one application use one shared trait or a different trait per store.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "A generated pair names one trait that both stores implement, or a trait for each store.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "near_threshold": true,
        "confirmed": true,
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.7,
            "probabilities": {
              "yes": 0.19,
              "no": 0.8,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.72,
            "probabilities": {
              "yes": 0.17,
              "no": 0.81,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.85,
            "probabilities": {
              "yes": 0.05,
              "no": 0.9,
              "unclear": 0.05
            }
          }
        },
        "min_confidence": 0.7,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6661,
          "output_tokens": 117
        },
        "attempts": 2,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23656
      },
      {
        "anchor_id": "REQ-RUN-0329",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0329",
        "statement": "A generated crate's package name is the project name, a hyphen, and its role.",
        "quote": "A generated crate's package name is the project name, a hyphen, and its role. The adaptor depends on <project>-types and <project>-schema.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 4,
        "deterministic_check": "Two projects with different names produce no package name in common.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "near_threshold": true,
        "confirmed": true,
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.67,
            "probabilities": {
              "yes": 0.21,
              "no": 0.78,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.83,
            "probabilities": {
              "yes": 0.05,
              "no": 0.89,
              "unclear": 0.06
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "yes": 0.05,
              "no": 0.94,
              "unclear": 0.01
            }
          }
        },
        "min_confidence": 0.67,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6664,
          "output_tokens": 117
        },
        "attempts": 2,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23669
      },
      {
        "anchor_id": "REQ-RUN-0330",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0330",
        "statement": "Row type structs are in the schema crate. The types crate is for non-database types.",
        "quote": "Row type structs are in the schema crate. The types crate is for non-database types.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "ADR-RUN-0305",
        "anchor_version": 2,
        "deterministic_check": "The schema crate contains the row structs. The types crate contains no database row struct. The adaptor depends on the schema crate.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.83,
            "probabilities": {
              "yes": 0.1,
              "no": 0.89,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.01,
              "no": 0.98,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.03,
              "no": 0.96,
              "unclear": 0.01
            }
          }
        },
        "min_confidence": 0.83,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6666,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23668
      },
      {
        "anchor_id": "REQ-RUN-0331",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0331",
        "statement": "The template ships general database commands on the CLI, MCP, and HTTP, including delete row <table> <id>. The consumer can disable that surface.",
        "quote": "The template ships general database commands on the CLI, MCP, and HTTP, including delete row <table> <id>. The consumer can disable that surface.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "requirements register",
        "anchor_version": 2,
        "deterministic_check": "A generated project with a store registers delete row <table> <id> on the CLI, MCP, and HTTP, and a flag removes those commands.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.02,
              "no": 0.98,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.01,
              "no": 0.98,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.02,
              "no": 0.98,
              "unclear": 0.0
            }
          }
        },
        "min_confidence": 0.97,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6676,
          "output_tokens": 117
        },
        "attempts": 1,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23717
      },
      {
        "anchor_id": "REQ-RUN-0503",
        "source_type": "REQ",
        "source_ref": "REQ-RUN-0503",
        "statement": "A project generated by just new passes lint, test, and both builds with no file edited.",
        "quote": "A project generated by just new passes lint, test, and both builds with no file edited.",
        "stated_by": "randlee",
        "stated_at": "2026-10-25",
        "context": "requirements register",
        "anchor_version": 2,
        "deterministic_check": "just new on the sqlite fixture exits 0, and just lint, just test, just build-cli, and just build-daemon exit 0 with no file edited.",
        "kind": "directive",
        "leaning": "not_applicable",
        "question_set": {
          "gate": "plan",
          "version": 1,
          "overridden": false
        },
        "questions_sha256": "45c142d4b4a63bd5c580d2407d06af54171ebec6302dd62d0ba982450416f8cd",
        "near_threshold": true,
        "confirmed": true,
        "verdict": "not_applicable",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.7,
            "probabilities": {
              "yes": 0.2,
              "no": 0.8,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.38,
            "probabilities": {
              "yes": 0.36,
              "no": 0.59,
              "unclear": 0.05
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.56,
            "probabilities": {
              "yes": 0.26,
              "no": 0.71,
              "unclear": 0.03
            }
          }
        },
        "min_confidence": 0.38,
        "explanation": "The anchor does not govern this bead.",
        "usage": {
          "input_tokens": 6663,
          "output_tokens": 117
        },
        "attempts": 2,
        "item_chars_sent": 20271,
        "item_shortened": false,
        "request_bytes": 23662
      }
    ],
    "overrides_applied": [
      "ANC-028",
      "ANC-032",
      "ANC-033",
      "ANC-035",
      "ANC-037",
      "ANC-041",
      "ANC-027",
      "ANC-031",
      "ANC-029",
      "ANC-030",
      "ANC-034",
      "ANC-036",
      "ANC-038",
      "ANC-039",
      "ANC-040",
      "ANC-042"
    ],
    "item_truncated": false,
    "shortened": [],
    "report_markdown": "## Anchor gate: plan · b-13 - Sprint b-13 — observability injection contract and adoption\n\nRun `plan-20261030T050531Z-b-13`, model `jev-1.14.0`, threshold 0.6. Counts: underspecified 10, satisfied 7, not_applicable 27.\n\n> **b-13 · ANC-028 · underspecified** Anchor: Embedding applications can register additional Monty host functions without modifying sc-cron. You said (Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected., Oct 29): \"the primary requirement of being able to be extensible w/ other apps/calls is supported.\" Jev was not confident (min confidence 0.26); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.26.\n>   Low: compliance `addressed` answered no at 0.56.\n>   Low: conflict `contradicted` answered no at 0.52.\n\n> **b-13 · ANC-032 · underspecified** Anchor: render_template is not required by the sc-cron product contract. You said (Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected., Oct 29): \"render_template is not a product requirement.\" Jev was not confident (min confidence 0.50); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.50.\n\n> **b-13 · ANC-033 · underspecified** Anchor: MVP executes application-supplied Monty scripts without script signing or a separate approval mechanism. You said (Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected., Oct 29): \"for mvp this is not something available for consumers to do.\" Jev was not confident (min confidence 0.34); the anchor or the bead may be underspecified. (leaning: satisfied)\n>   Low: conflict `contradicted` answered no at 0.34.\n\n> **b-13 · ANC-035 · underspecified** Anchor: Hooks inherit daemon-process environment values only through variable names explicitly allowed by daemon configuration. You said (Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected., Oct 29): \"whitelisting api keys globally (by name) in config file (this is really a daemon scope decision).\" Jev was not confident (min confidence 0.43); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.43.\n\n> **b-13 · ANC-037 · underspecified** Anchor: Schedule creation and updates never implicitly capture environment values from the caller or daemon process. You said (Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected., Oct 29): \"Never capture or persist inherited host values accidentally.\" Jev was not confident (min confidence 0.28); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.28.\n\n> **b-13 · ANC-041 · underspecified** Anchor: Monty scripts can read their configured environment during source initialization, before hook functions run. You said (Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected., Oct 29): \"there should also be the ability to set environment variables in a monty script before it runs.\" Jev was not confident (min confidence 0.52); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.52.\n>   Unstable: two identical requests gave underspecified then not_applicable.\n\n> **b-13 · REQ-CRON-0002 · underspecified** Anchor: A sc-cron schedule is a normal crontab string of five fields: minute, hour, day of month, month, and day of week. REQ-CRON-0002 (requirements register) says: \"CronExpr::parse of */5 * * * * succeeds and means every fifth minute. CronExpr::parse of 0 */5 * * * * succeeds and means second 0 of every fifth minute. CronExpr::parse of @hourly succeeds.\" Jev was not confident (min confidence 0.25); the anchor or the bead may be underspecified. (leaning: not_addressed)\n>   Low: relevance `relevant` answered yes at 0.25.\n\n> **b-13 · REQ-CRON-0004 · underspecified** Anchor: The sc-cron crate creates one schedule table. A test writes a row without constructing SqliteWriter. The crate does not migrate the consumer's other tables. Jev was not confident (min confidence 0.53); the anchor or the bead may be underspecified. (leaning: not_addressed)\n>   Low: relevance `relevant` answered yes at 0.53.\n>   Unstable: two identical requests gave underspecified then not_addressed.\n\n> **b-13 · REQ-RUN-0318 · underspecified** Anchor: The library crate named sc-runtime does not generate adaptor code. Jev was not confident (min confidence 0.55); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.55 (second ask).\n>   Unstable: two identical requests gave not_applicable then underspecified.\n\n> **b-13 · REQ-RUN-0323 · underspecified** Anchor: Store synchronization is scheduled by the consuming application. The adaptor starts no timer. Jev was not confident (min confidence 0.53); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.53 (second ask).\n>   Unstable: two identical requests gave not_applicable then underspecified."
  },
  "error": null,
  "metadata": {
    "duration_ms": 65874,
    "tool_calls": 8,
    "retry_count": 15,
    "correlation_id": "phase-b-approval-b13-planfix-20261030"
  }
}
```
