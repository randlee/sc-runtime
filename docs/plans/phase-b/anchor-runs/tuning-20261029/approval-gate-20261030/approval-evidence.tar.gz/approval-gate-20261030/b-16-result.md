```json
{
  "schema_version": "1.0.0",
  "success": true,
  "canceled": false,
  "aborted_by": null,
  "data": {
    "gate": "plan",
    "item_id": "b-16",
    "run_id": "plan-20261030T051942Z-b-16",
    "run_path": "/Volumes/Extreme Pro/github/sc-runtime-worktrees/plan/spinoff-monty-observability/doc/plan/phase-current/anchor-runs/tuning-20261029/approval-gate-20261030/plan-20261030T051942Z-b-16.json",
    "dry_run": false,
    "reused_run": false,
    "pass": true,
    "failing": [],
    "errors": [],
    "excluded": [
      {
        "anchor_id": "ADR-RUN-0305",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "ANC-034",
        "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
      },
      {
        "anchor_id": "ANC-036",
        "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
      },
      {
        "anchor_id": "ANC-037",
        "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
      },
      {
        "anchor_id": "ANC-038",
        "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
      },
      {
        "anchor_id": "ANC-039",
        "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
      },
      {
        "anchor_id": "ANC-040",
        "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
      },
      {
        "anchor_id": "ANC-041",
        "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
      },
      {
        "anchor_id": "ANC-042",
        "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
      },
      {
        "anchor_id": "REQ-CRON-0002",
        "reason": "This sprint does not change the cron expression parser or five-field schedule semantics."
      },
      {
        "anchor_id": "REQ-CRON-0004",
        "reason": "This sprint does not add the schedule table or change table creation, consumer-table migrations, or SqliteWriter-independent row writes."
      },
      {
        "anchor_id": "REQ-RUN-0313",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0314",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0315",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0316",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0317",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0318",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0319",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0320",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0321",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0322",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0323",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0324",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0325",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0326",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0327",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0328",
        "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
      },
      {
        "anchor_id": "REQ-RUN-0330",
        "reason": "This sprint does not add or generate database schema/types crates or relocate row structs."
      },
      {
        "anchor_id": "REQ-RUN-0331",
        "reason": "This sprint does not change the generated CLI/MCP/HTTP database command surface."
      }
    ],
    "results": [
      {
        "anchor_id": "ADR-RUN-0002",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.88,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.99,
              "no": 0.01,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.88,
            "probabilities": {
              "yes": 0.92,
              "no": 0.06,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.02,
              "no": 0.98,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ADR-RUN-0013",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.97,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.98,
              "no": 0.02,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.02,
              "no": 0.98,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ANC-027",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.83,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.91,
            "probabilities": {
              "no": 0.06,
              "unclear": 0.0,
              "yes": 0.94
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.83,
            "probabilities": {
              "no": 0.89,
              "unclear": 0.01,
              "yes": 0.1
            }
          }
        }
      },
      {
        "anchor_id": "ANC-028",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.8,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.8,
            "probabilities": {
              "no": 0.87,
              "unclear": 0.01,
              "yes": 0.12
            }
          }
        }
      },
      {
        "anchor_id": "ANC-029",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.89,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.89,
            "probabilities": {
              "no": 0.93,
              "unclear": 0.01,
              "yes": 0.06
            }
          }
        }
      },
      {
        "anchor_id": "ANC-030",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.88,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "no": 0.92,
              "unclear": 0.01,
              "yes": 0.07
            }
          }
        }
      },
      {
        "anchor_id": "ANC-031",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.89,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.89,
            "probabilities": {
              "no": 0.93,
              "unclear": 0.01,
              "yes": 0.06
            }
          }
        }
      },
      {
        "anchor_id": "ANC-032",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.88,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.88,
            "probabilities": {
              "no": 0.08,
              "unclear": 0.0,
              "yes": 0.92
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.89,
            "probabilities": {
              "no": 0.07,
              "unclear": 0.0,
              "yes": 0.93
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ANC-033",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.61,
        "attempts": 2,
        "confirmed": true,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.61,
            "probabilities": {
              "no": 0.74,
              "unclear": 0.01,
              "yes": 0.25
            }
          }
        }
      },
      {
        "anchor_id": "ANC-035",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.96,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "no": 0.97,
              "unclear": 0.0,
              "yes": 0.03
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0001",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0003",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.94,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.96,
              "no": 0.03,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.04,
              "no": 0.96,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0005",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.94,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.96,
              "no": 0.03,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0329",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0503",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.88,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.99,
              "no": 0.01,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "yes": 0.08,
              "no": 0.92,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ADR-RUN-0305",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "ANC-034",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
        }
      },
      {
        "anchor_id": "ANC-036",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
        }
      },
      {
        "anchor_id": "ANC-037",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
        }
      },
      {
        "anchor_id": "ANC-038",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
        }
      },
      {
        "anchor_id": "ANC-039",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
        }
      },
      {
        "anchor_id": "ANC-040",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
        }
      },
      {
        "anchor_id": "ANC-041",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
        }
      },
      {
        "anchor_id": "ANC-042",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads."
        }
      },
      {
        "anchor_id": "REQ-CRON-0002",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not change the cron expression parser or five-field schedule semantics.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not change the cron expression parser or five-field schedule semantics."
        }
      },
      {
        "anchor_id": "REQ-CRON-0004",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add the schedule table or change table creation, consumer-table migrations, or SqliteWriter-independent row writes.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add the schedule table or change table creation, consumer-table migrations, or SqliteWriter-independent row writes."
        }
      },
      {
        "anchor_id": "REQ-RUN-0313",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0314",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0315",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0316",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0317",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0318",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0319",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0320",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0321",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0322",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0323",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0324",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0325",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0326",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0327",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0328",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores."
        }
      },
      {
        "anchor_id": "REQ-RUN-0330",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not add or generate database schema/types crates or relocate row structs.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not add or generate database schema/types crates or relocate row structs."
        }
      },
      {
        "anchor_id": "REQ-RUN-0331",
        "verdict": "excluded",
        "leaning": null,
        "min_confidence": null,
        "attempts": 0,
        "explanation": "Excluded from this bead by the anchor's exclude list: This sprint does not change the generated CLI/MCP/HTTP database command surface.",
        "answers": null,
        "exclusion": {
          "item": "b-16",
          "reason": "This sprint does not change the generated CLI/MCP/HTTP database command surface."
        }
      }
    ],
    "overrides_applied": [
      "ANC-027",
      "ANC-028",
      "ANC-029",
      "ANC-030",
      "ANC-031",
      "ANC-032",
      "ANC-033",
      "ANC-035"
    ],
    "item_truncated": false,
    "shortened": [],
    "report_markdown": "## Anchor gate: plan · b-16 - Sprint b-16 — extensible Monty hosts and generated example\n\nRun `plan-20261030T051942Z-b-16`, model `jev-1.14.0`, threshold 0.6. Counts: satisfied 15, excluded 29.\n\n> **b-16 · ADR-RUN-0305 · excluded** Anchor: SQLite and Postgres meet in an adaptor crate generated into the consumer repository. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · ANC-034 · excluded** Anchor: Python and Monty hooks use the same schedule-environment configuration and resolution rules. Not judged: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.\n\n> **b-16 · ANC-036 · excluded** Anchor: Each schedule can explicitly set or clear its own environment variables. Not judged: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.\n\n> **b-16 · ANC-037 · excluded** Anchor: Schedule creation and updates never implicitly capture environment values from the caller or daemon process. Not judged: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.\n\n> **b-16 · ANC-038 · excluded** Anchor: The schedule registry permits deliberately supplied environment values as plaintext configuration. Not judged: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.\n\n> **b-16 · ANC-039 · excluded** Anchor: Schedules can resolve environment values through an application-provided resolver for opaque references. Not judged: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.\n\n> **b-16 · ANC-040 · excluded** Anchor: Schedules can load environment variables from full-path .env files. Not judged: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.\n\n> **b-16 · ANC-041 · excluded** Anchor: Monty scripts can read their configured environment during source initialization, before hook functions run. Not judged: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.\n\n> **b-16 · ANC-042 · excluded** Anchor: The first released schedule schema establishes one baseline without requiring migrations among unreleased development schemas. Not judged: b-16 implements host registration and CLI argv dispatch; b-17 separately owns environment configuration, resolution, persistence safeguards, and source-initialization environment reads.\n\n> **b-16 · REQ-CRON-0002 · excluded** Anchor: A sc-cron schedule is a normal crontab string of five fields: minute, hour, day of month, month, and day of week. Not judged: This sprint does not change the cron expression parser or five-field schedule semantics.\n\n> **b-16 · REQ-CRON-0004 · excluded** Anchor: The sc-cron crate creates one schedule table. A test writes a row without constructing SqliteWriter. The crate does not migrate the consumer's other tables. Not judged: This sprint does not add the schedule table or change table creation, consumer-table migrations, or SqliteWriter-independent row writes.\n\n> **b-16 · REQ-RUN-0313 · excluded** Anchor: The relationship between the local SQLite store and the remote Postgres or SQL store is defined in an adaptor crate on the consumer repository. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0314 · excluded** Anchor: The copy adaptor is a local SQLite database with the remote schema, for faster or offline access. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0315 · excluded** Anchor: The host-aggregate adaptor is one SQLite database for this host and a Postgres database that aggregates many hosts. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0316 · excluded** Anchor: The consumer repository defines the rollup from host rows into the Postgres aggregate. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0317 · excluded** Anchor: Adaptor Rust code and models in a new repository are generated by the command just new (scripts/new_project.py). Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0318 · excluded** Anchor: The library crate named sc-runtime does not generate adaptor code. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0319 · excluded** Anchor: Generation flags name tables and columns that exist on only one of the two stores. A skipped table may be the SQLite table or the SQL-server table. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0320 · excluded** Anchor: Every consumer repository uses the same generated implementation of the copy pattern and the same generated implementation of the host-aggregate pattern. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0321 · excluded** Anchor: Each database engine's SQL is in that engine's store crate. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0322 · excluded** Anchor: An adaptor that is neither the copy pattern nor the host-aggregate pattern is written by the consumer from the store building blocks. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0323 · excluded** Anchor: Store synchronization is scheduled by the consuming application. The adaptor starts no timer. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0324 · excluded** Anchor: The consumer adaptor moves rows between the local store and the remote store. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0325 · excluded** Anchor: The sc-runtime crates do not move rows between stores. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0326 · excluded** Anchor: A new application is created with no database, with SQLite only, with one sqlx SQL engine only, or with SQLite plus one sqlx SQL engine. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0327 · excluded** Anchor: Two stores in one application use the same schema or a similar schema. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0328 · excluded** Anchor: Two stores in one application use one shared trait or a different trait per store. Not judged: This sprint does not add, remove, or generate store adaptors, change store schemas/traits or database choices, or move rows between stores.\n\n> **b-16 · REQ-RUN-0330 · excluded** Anchor: Row type structs are in the schema crate. The types crate is for non-database types. Not judged: This sprint does not add or generate database schema/types crates or relocate row structs.\n\n> **b-16 · REQ-RUN-0331 · excluded** Anchor: The template ships general database commands on the CLI, MCP, and HTTP, including delete row <table> <id>. The consumer can disable that surface. Not judged: This sprint does not change the generated CLI/MCP/HTTP database command surface.\n\nAll judged anchors are satisfied or not applicable.\n\n"
  },
  "error": null,
  "metadata": {
    "duration_ms": 30000,
    "tool_calls": 36,
    "retry_count": 1,
    "correlation_id": "phase-b-approval-b16-reviewed-20261030"
  }
}
```
