```json
{
  "schema_version": "1.0.0",
  "success": false,
  "canceled": false,
  "aborted_by": null,
  "data": null,
  "error": {
    "code": "VALIDATION.PATH",
    "message": "evidence file could not be resolved: [Errno 2] No such file or directory: '/Volumes/Extreme Pro/github/sc-runtime-worktrees/plan/spinoff-monty-observability/docs/plans/phase-b/b-14-sc-runtime-observability.md'",
    "recoverable": false,
    "suggested_action": "Pass a readable evidence file inside /Volumes/Extreme Pro/github/sc-runtime-worktrees/plan/spinoff-monty-observability."
  },
  "metadata": {
    "duration_ms": 11000,
    "tool_calls": 4,
    "retry_count": 0,
    "correlation_id": "phase-b-approval-b14-20261030"
  }
}
```
