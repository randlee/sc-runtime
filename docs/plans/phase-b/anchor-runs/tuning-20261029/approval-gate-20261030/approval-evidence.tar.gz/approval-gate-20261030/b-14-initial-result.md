```json
{
  "schema_version": "1.0.0",
  "success": true,
  "canceled": false,
  "aborted_by": null,
  "data": {
    "gate": "plan",
    "item_id": "b-14",
    "run_id": "plan-20261030T050055Z-b-14",
    "run_path": "/Volumes/Extreme Pro/github/sc-runtime-worktrees/plan/spinoff-monty-observability/doc/plan/phase-current/anchor-runs/tuning-20261029/approval-gate-20261030/plan-20261030T050055Z-b-14.json",
    "dry_run": false,
    "reused_run": false,
    "pass": false,
    "failing": [
      "ADR-RUN-0002",
      "ANC-031"
    ],
    "errors": [],
    "excluded": [],
    "results": [
      {
        "anchor_id": "ADR-RUN-0002",
        "verdict": "not_addressed",
        "leaning": "not_addressed",
        "min_confidence": 0.74,
        "attempts": 1,
        "explanation": "This bead does not carry the directive forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.74,
            "probabilities": {
              "yes": 0.83,
              "no": 0.17,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.76,
            "probabilities": {
              "yes": 0.11,
              "no": 0.84,
              "unclear": 0.05
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.02,
              "no": 0.98,
              "unclear": 0.0
            }
          }
        },
        "to_fix": {
          "where": null,
          "change": "exclude --id ADR-RUN-0002 --item b-14 --reason \"This sprint changes sc-runtime HTTP event handling and does not change the cargo-generate template or the published-library/template relationship.\""
        }
      },
      {
        "anchor_id": "ANC-031",
        "verdict": "underspecified",
        "leaning": "not_applicable",
        "min_confidence": 0.24,
        "attempts": 2,
        "confirmed": true,
        "explanation": "Jev was not confident (min confidence 0.24); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.24,
            "probabilities": {
              "no": 0.49,
              "unclear": 0.04,
              "yes": 0.47
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.28,
            "probabilities": {
              "no": 0.52,
              "unclear": 0.1,
              "yes": 0.38
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.7,
            "probabilities": {
              "no": 0.8,
              "unclear": 0.1,
              "yes": 0.1
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.24
          }
        ],
        "to_fix": {
          "where": "The required boundary lint and `cargo check --workspace` pass with tests using the types test double, not another workspace crate or a full runtime sink.",
          "change": "State that b-14 adds no sc-compose or ATM production dependency or Rust import, permits test and benchmark references, and retains boundary-lint enforcement."
        }
      },
      {
        "anchor_id": "ADR-RUN-0013",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.96,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.0,
              "no": 0.97,
              "unclear": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ADR-RUN-0305",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 1.0,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ANC-027",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.66,
        "attempts": 2,
        "confirmed": true,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.98,
              "unclear": 0.0,
              "yes": 0.02
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.66,
            "probabilities": {
              "no": 0.77,
              "unclear": 0.02,
              "yes": 0.21
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "no": 0.97,
              "unclear": 0.01,
              "yes": 0.02
            }
          }
        }
      },
      {
        "anchor_id": "ANC-028",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.91,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.99,
              "unclear": 0.0,
              "yes": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "no": 0.94,
              "unclear": 0.01,
              "yes": 0.05
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "no": 0.97,
              "unclear": 0.02,
              "yes": 0.01
            }
          }
        }
      },
      {
        "anchor_id": "ANC-029",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.89,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.89,
            "probabilities": {
              "no": 0.93,
              "unclear": 0.01,
              "yes": 0.06
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "no": 0.97,
              "unclear": 0.02,
              "yes": 0.01
            }
          }
        }
      },
      {
        "anchor_id": "ANC-030",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.94,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.99,
              "unclear": 0.0,
              "yes": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.98,
              "unclear": 0.0,
              "yes": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "no": 0.96,
              "unclear": 0.02,
              "yes": 0.02
            }
          }
        }
      },
      {
        "anchor_id": "ANC-032",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.99,
              "unclear": 0.0,
              "yes": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ANC-033",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.99,
              "unclear": 0.0,
              "yes": 0.01
            }
          }
        }
      },
      {
        "anchor_id": "ANC-034",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.91,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.99,
              "unclear": 0.0,
              "yes": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "no": 0.96,
              "unclear": 0.01,
              "yes": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "no": 0.94,
              "unclear": 0.05,
              "yes": 0.01
            }
          }
        }
      },
      {
        "anchor_id": "ANC-035",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.89,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.89,
            "probabilities": {
              "no": 0.93,
              "unclear": 0.0,
              "yes": 0.07
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.99,
              "unclear": 0.01,
              "yes": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ANC-036",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.92,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.99,
              "unclear": 0.0,
              "yes": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "no": 0.95,
              "unclear": 0.01,
              "yes": 0.04
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "no": 0.95,
              "unclear": 0.04,
              "yes": 0.01
            }
          }
        }
      },
      {
        "anchor_id": "ANC-037",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.94,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.98,
              "unclear": 0.0,
              "yes": 0.02
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "no": 0.96,
              "unclear": 0.01,
              "yes": 0.03
            }
          }
        }
      },
      {
        "anchor_id": "ANC-038",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.82,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.99,
              "unclear": 0.0,
              "yes": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.82,
            "probabilities": {
              "no": 0.88,
              "unclear": 0.02,
              "yes": 0.1
            }
          }
        }
      },
      {
        "anchor_id": "ANC-039",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.89,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.98,
              "unclear": 0.0,
              "yes": 0.02
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.89,
            "probabilities": {
              "no": 0.93,
              "unclear": 0.02,
              "yes": 0.05
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "no": 0.96,
              "unclear": 0.03,
              "yes": 0.01
            }
          }
        }
      },
      {
        "anchor_id": "ANC-040",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 1.0,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ANC-041",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 1.0,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ANC-042",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.94,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "no": 0.96,
              "unclear": 0.01,
              "yes": 0.03
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0001",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.97,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.01,
              "no": 0.98,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0002",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.79,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.79,
            "probabilities": {
              "yes": 0.0,
              "no": 0.86,
              "unclear": 0.14
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0003",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.0,
              "no": 0.99,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0004",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.0,
              "no": 0.99,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0005",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0313",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 1.0,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0314",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0315",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0316",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.96,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.02,
              "no": 0.98,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.02,
              "no": 0.97,
              "unclear": 0.01
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0317",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.96,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.01,
              "no": 0.98,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.03,
              "no": 0.97,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0318",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.8,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.8,
            "probabilities": {
              "yes": 0.13,
              "no": 0.87,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.86,
            "probabilities": {
              "yes": 0.07,
              "no": 0.91,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.02,
              "no": 0.98,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0319",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0320",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0321",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0322",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.97,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.02,
              "no": 0.98,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.0,
              "no": 0.99,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.02,
              "no": 0.98,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0323",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0324",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0325",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.89,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.89,
            "probabilities": {
              "yes": 0.06,
              "no": 0.93,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.01,
              "no": 0.98,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0326",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 1.0,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0327",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0328",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.89,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.89,
            "probabilities": {
              "yes": 0.06,
              "no": 0.93,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.02,
              "no": 0.96,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.01,
              "no": 0.97,
              "unclear": 0.02
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0329",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.96,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.03,
              "no": 0.97,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.0,
              "no": 0.99,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0330",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.85,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.85,
            "probabilities": {
              "yes": 0.09,
              "no": 0.9,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.89,
            "probabilities": {
              "yes": 0.04,
              "no": 0.93,
              "unclear": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.02,
              "no": 0.97,
              "unclear": 0.01
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0331",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.91,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "yes": 0.06,
              "no": 0.94,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "yes": 0.0,
              "no": 1.0,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0503",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.94,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.02,
              "no": 0.98,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.01,
              "no": 0.98,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.03,
              "no": 0.96,
              "unclear": 0.01
            }
          }
        }
      }
    ],
    "overrides_applied": [
      "ANC-031",
      "ANC-027",
      "ANC-028",
      "ANC-029",
      "ANC-030",
      "ANC-032",
      "ANC-033",
      "ANC-034",
      "ANC-035",
      "ANC-036",
      "ANC-037",
      "ANC-038",
      "ANC-039",
      "ANC-040",
      "ANC-041",
      "ANC-042"
    ],
    "item_truncated": false,
    "shortened": [],
    "report_markdown": "## Anchor gate: plan · b-14 - Sprint b-14 — sc-runtime canonical HTTP events\n\nRun `plan-20261030T050055Z-b-14`, model `jev-1.14.0`, threshold 0.6. Counts: not_addressed 1, underspecified 1, not_applicable 42.\n\n> **b-14 · ADR-RUN-0002 · not addressed** Anchor: sc-runtime is a cargo-generate template plus published library crates. This bead does not carry the directive forward.\n\n> **b-14 · ANC-031 · underspecified** Anchor: Every production release crate excludes sc-compose and ATM crate dependencies and Rust imports, enforced by boundary lint; test and benchmark references are permitted. You said (Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected., Oct 29): \"sc-compose and atm crates should be blocked from any production release crate.  sc-compose and atm can be referenced for tests i.e. benchmark tests.\" Jev was not confident (min confidence 0.24); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.24.\n\n"
  },
  "error": null,
  "metadata": {
    "duration_ms": 81000,
    "tool_calls": 36,
    "retry_count": 2,
    "correlation_id": "phase-b-approval-b14-20261030"
  }
}
```
