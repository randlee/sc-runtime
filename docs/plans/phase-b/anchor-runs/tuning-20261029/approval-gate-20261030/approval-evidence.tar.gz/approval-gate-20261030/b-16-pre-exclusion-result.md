```json
{
  "schema_version": "1.0.0",
  "success": true,
  "canceled": false,
  "aborted_by": null,
  "data": {
    "gate": "plan",
    "item_id": "b-16",
    "run_id": "plan-20261030T051008Z-b-16",
    "run_path": "/Volumes/Extreme Pro/github/sc-runtime-worktrees/plan/spinoff-monty-observability/doc/plan/phase-current/anchor-runs/tuning-20261029/approval-gate-20261030/plan-20261030T051008Z-b-16.json",
    "dry_run": false,
    "reused_run": false,
    "pass": false,
    "failing": [
      "ANC-038",
      "ANC-034",
      "ANC-036",
      "ANC-037",
      "ANC-039",
      "ANC-040",
      "ANC-041",
      "REQ-CRON-0002",
      "REQ-CRON-0004",
      "REQ-RUN-0315",
      "REQ-RUN-0317",
      "REQ-RUN-0318",
      "REQ-RUN-0320",
      "REQ-RUN-0322",
      "REQ-RUN-0324",
      "REQ-RUN-0325",
      "REQ-RUN-0326",
      "REQ-RUN-0327",
      "REQ-RUN-0328"
    ],
    "errors": [],
    "excluded": [],
    "results": [
      {
        "anchor_id": "ANC-038",
        "verdict": "not_addressed",
        "leaning": "not_addressed",
        "min_confidence": 0.37,
        "attempts": 1,
        "explanation": "This bead does not carry the directive forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.88,
            "probabilities": {
              "no": 0.08,
              "unclear": 0.0,
              "yes": 0.92
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.98,
              "unclear": 0.02,
              "yes": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.37,
            "probabilities": {
              "no": 0.58,
              "unclear": 0.05,
              "yes": 0.37
            }
          }
        },
        "to_fix": {
          "where": "Both CLI children start with an explicitly empty environment after executable resolution; they never inherit the full daemon environment. b-17 replaces the empty map with its resolved snapshot: inherited daemon values enter only through names explicitly allowed by daemon configuration.",
          "change": "Carry forward the supported schedule environment values in this item: explicitly supplied plaintext values are allowed, while inherited daemon values enter only through the b-17 allowlisted snapshot."
        }
      },
      {
        "anchor_id": "ANC-034",
        "verdict": "underspecified",
        "leaning": "not_addressed",
        "min_confidence": 0.31,
        "attempts": 2,
        "confirmed": true,
        "explanation": "Jev was not confident (min confidence 0.31); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.31,
            "probabilities": {
              "no": 0.43,
              "unclear": 0.03,
              "yes": 0.54
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.55,
            "probabilities": {
              "no": 0.7,
              "unclear": 0.11,
              "yes": 0.19
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.38,
            "probabilities": {
              "no": 0.59,
              "unclear": 0.34,
              "yes": 0.07
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "yes",
            "confidence": 0.31
          },
          {
            "ask": "first",
            "role": "compliance",
            "question_id": "addressed",
            "choice": "no",
            "confidence": 0.55
          },
          {
            "ask": "first",
            "role": "conflict",
            "question_id": "contradicted",
            "choice": "no",
            "confidence": 0.38
          }
        ],
        "to_fix": {
          "where": "b-17 adds read-only access to that run's resolved environment snapshot without changing handler registration or allowing process-global reads.",
          "change": "State that Python and Monty hooks use the same schedule-environment configuration and resolver, and that b-17 passes the same resolved snapshot to Monty host calls."
        }
      },
      {
        "anchor_id": "ANC-036",
        "verdict": "underspecified",
        "leaning": "not_applicable",
        "min_confidence": 0.31,
        "attempts": 2,
        "confirmed": true,
        "explanation": "Jev was not confident (min confidence 0.31); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.31,
            "probabilities": {
              "no": 0.54,
              "unclear": 0.01,
              "yes": 0.45
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.52,
            "probabilities": {
              "no": 0.68,
              "unclear": 0.06,
              "yes": 0.26
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.38,
            "probabilities": {
              "no": 0.59,
              "unclear": 0.21,
              "yes": 0.2
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.31
          },
          {
            "ask": "first",
            "role": "compliance",
            "question_id": "addressed",
            "choice": "no",
            "confidence": 0.52
          },
          {
            "ask": "first",
            "role": "conflict",
            "question_id": "contradicted",
            "choice": "no",
            "confidence": 0.38
          }
        ],
        "to_fix": {
          "where": null,
          "change": "exclude --id ANC-036 --item b-16 --reason \"Per-schedule Set/Clear environment configuration is owned by b-17; this sprint only establishes the CLI child environment boundary.\""
        }
      },
      {
        "anchor_id": "ANC-037",
        "verdict": "underspecified",
        "leaning": "satisfied",
        "min_confidence": 0.26,
        "attempts": 2,
        "confirmed": true,
        "explanation": "Jev was not confident (min confidence 0.26); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.26,
            "probabilities": {
              "no": 0.47,
              "unclear": 0.02,
              "yes": 0.51
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "no": 0.92,
              "unclear": 0.02,
              "yes": 0.06
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.58,
            "probabilities": {
              "no": 0.72,
              "unclear": 0.02,
              "yes": 0.26
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "yes",
            "confidence": 0.26
          },
          {
            "ask": "first",
            "role": "conflict",
            "question_id": "contradicted",
            "choice": "no",
            "confidence": 0.58
          }
        ],
        "to_fix": {
          "where": "Both CLI children start with an explicitly empty environment after executable resolution; they never inherit the full daemon environment. b-17 replaces the empty map with its resolved snapshot: inherited daemon values enter only through names explicitly allowed by daemon configuration.",
          "change": "State that schedule creation and updates never capture caller or daemon environment values; only explicitly configured values or b-17’s filtered snapshot reach a CLI child."
        }
      },
      {
        "anchor_id": "ANC-039",
        "verdict": "underspecified",
        "leaning": "not_addressed",
        "min_confidence": 0.28,
        "attempts": 2,
        "confirmed": true,
        "explanation": "Jev was not confident (min confidence 0.28); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.37,
            "probabilities": {
              "no": 0.4,
              "unclear": 0.02,
              "yes": 0.58
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.28,
            "probabilities": {
              "no": 0.52,
              "unclear": 0.07,
              "yes": 0.41
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.67,
            "probabilities": {
              "no": 0.78,
              "unclear": 0.16,
              "yes": 0.06
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "yes",
            "confidence": 0.37
          },
          {
            "ask": "first",
            "role": "compliance",
            "question_id": "addressed",
            "choice": "no",
            "confidence": 0.28
          }
        ],
        "to_fix": {
          "where": "b-17 adds read-only access to that run's resolved environment snapshot without changing handler registration or allowing process-global reads.",
          "change": "Specify that b-17 resolves opaque environment references through the application-provided resolver before placing resolved values in the shared Python/Monty snapshot."
        }
      },
      {
        "anchor_id": "ANC-040",
        "verdict": "underspecified",
        "leaning": "not_addressed",
        "min_confidence": 0.25,
        "attempts": 1,
        "explanation": "Jev was not confident (min confidence 0.25); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.25,
            "probabilities": {
              "no": 0.48,
              "unclear": 0.02,
              "yes": 0.5
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.98,
              "unclear": 0.01,
              "yes": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.77,
            "probabilities": {
              "no": 0.85,
              "unclear": 0.04,
              "yes": 0.11
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "yes",
            "confidence": 0.25
          }
        ],
        "to_fix": {
          "where": "b-17 adds read-only access to that run's resolved environment snapshot without changing handler registration or allowing process-global reads.",
          "change": "Specify whether b-17 loads values from an absolute-path .env file into the shared Python/Monty environment snapshot."
        }
      },
      {
        "anchor_id": "ANC-041",
        "verdict": "underspecified",
        "leaning": "not_addressed",
        "min_confidence": 0.5,
        "attempts": 2,
        "unstable": true,
        "explanation": "Jev was not confident (min confidence 0.50); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.5,
            "probabilities": {
              "no": 0.31,
              "unclear": 0.02,
              "yes": 0.67
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "no": 0.95,
              "unclear": 0.04,
              "yes": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.58,
            "probabilities": {
              "no": 0.72,
              "unclear": 0.05,
              "yes": 0.23
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "yes",
            "confidence": 0.5
          },
          {
            "ask": "first",
            "role": "conflict",
            "question_id": "contradicted",
            "choice": "no",
            "confidence": 0.58
          },
          {
            "ask": "second",
            "role": "conflict",
            "question_id": "contradicted",
            "choice": "no",
            "confidence": 0.56
          }
        ],
        "answers_second": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.62,
            "probabilities": {
              "no": 0.23,
              "unclear": 0.02,
              "yes": 0.75
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "no": 0.92,
              "unclear": 0.05,
              "yes": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.56,
            "probabilities": {
              "no": 0.71,
              "unclear": 0.04,
              "yes": 0.25
            }
          }
        },
        "to_fix": {
          "where": "b-17 adds read-only access to that run's resolved environment snapshot without changing handler registration or allowing process-global reads.",
          "change": "State that Monty source initialization may read configured environment values before hook functions run, through top-level getenv backed by the b-17 snapshot."
        }
      },
      {
        "anchor_id": "REQ-CRON-0002",
        "verdict": "underspecified",
        "leaning": "not_applicable",
        "min_confidence": 0.43,
        "attempts": 1,
        "explanation": "Jev was not confident (min confidence 0.43); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.43,
            "probabilities": {
              "yes": 0.37,
              "no": 0.62,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.83,
            "probabilities": {
              "yes": 0.02,
              "no": 0.89,
              "unclear": 0.09
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.43
          }
        ],
        "to_fix": {
          "where": null,
          "change": "exclude --id REQ-CRON-0002 --item b-16 --reason \"Cron expression parsing and five-field schedule semantics are not changed by this Monty host and template-example sprint.\""
        }
      },
      {
        "anchor_id": "REQ-CRON-0004",
        "verdict": "underspecified",
        "leaning": "not_addressed",
        "min_confidence": 0.3,
        "attempts": 1,
        "explanation": "Jev was not confident (min confidence 0.30); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.3,
            "probabilities": {
              "yes": 0.53,
              "no": 0.46,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.01,
              "no": 0.96,
              "unclear": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.04,
              "no": 0.95,
              "unclear": 0.01
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "yes",
            "confidence": 0.3
          }
        ],
        "to_fix": {
          "where": null,
          "change": "exclude --id REQ-CRON-0004 --item b-16 --reason \"This sprint adds the optional sc-cron template feature edge but does not create schedule tables or change migrations and schedule-row writes.\""
        }
      },
      {
        "anchor_id": "REQ-RUN-0315",
        "verdict": "underspecified",
        "leaning": "not_applicable",
        "min_confidence": 0.58,
        "attempts": 2,
        "confirmed": true,
        "explanation": "Jev was not confident (min confidence 0.58); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.58,
            "probabilities": {
              "yes": 0.26,
              "no": 0.72,
              "unclear": 0.02
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.01,
              "no": 0.97,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "yes": 0.07,
              "no": 0.92,
              "unclear": 0.01
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.58
          }
        ],
        "to_fix": {
          "where": null,
          "change": "exclude --id REQ-RUN-0315 --item b-16 --reason \"Host-aggregate storage adaptor topology is outside this sprint’s Monty host API and generated-example deliverables.\""
        }
      },
      {
        "anchor_id": "REQ-RUN-0317",
        "verdict": "underspecified",
        "leaning": "not_applicable",
        "min_confidence": 0.26,
        "attempts": 1,
        "explanation": "Jev was not confident (min confidence 0.26); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.31,
            "probabilities": {
              "yes": 0.45,
              "no": 0.54,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.26,
            "probabilities": {
              "yes": 0.51,
              "no": 0.43,
              "unclear": 0.06
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "yes": 0.06,
              "no": 0.92,
              "unclear": 0.02
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.31
          },
          {
            "ask": "first",
            "role": "compliance",
            "question_id": "addressed",
            "choice": "yes",
            "confidence": 0.26
          }
        ],
        "to_fix": {
          "where": null,
          "change": "exclude --id REQ-RUN-0317 --item b-16 --reason \"The generated Monty daemon example does not generate adaptor Rust code or models; that generator behavior is outside this sprint.\""
        }
      },
      {
        "anchor_id": "REQ-RUN-0318",
        "verdict": "underspecified",
        "leaning": "satisfied",
        "min_confidence": 0.26,
        "attempts": 2,
        "confirmed": true,
        "explanation": "Jev was not confident (min confidence 0.26); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.26,
            "probabilities": {
              "yes": 0.51,
              "no": 0.48,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.77,
            "probabilities": {
              "yes": 0.1,
              "no": 0.85,
              "unclear": 0.05
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.53,
            "probabilities": {
              "yes": 0.29,
              "no": 0.69,
              "unclear": 0.02
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "yes",
            "confidence": 0.26
          },
          {
            "ask": "first",
            "role": "conflict",
            "question_id": "contradicted",
            "choice": "no",
            "confidence": 0.53
          }
        ],
        "to_fix": {
          "where": null,
          "change": "exclude --id REQ-RUN-0318 --item b-16 --reason \"This sprint does not change the sc-runtime library crate or the generator boundary for adaptor code.\""
        }
      },
      {
        "anchor_id": "REQ-RUN-0320",
        "verdict": "underspecified",
        "leaning": "not_applicable",
        "min_confidence": 0.52,
        "attempts": 2,
        "unstable": true,
        "explanation": "Jev was not confident (min confidence 0.52); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.52,
            "probabilities": {
              "yes": 0.29,
              "no": 0.68,
              "unclear": 0.03
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.02,
              "no": 0.95,
              "unclear": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.85,
            "probabilities": {
              "yes": 0.05,
              "no": 0.9,
              "unclear": 0.05
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.52
          }
        ],
        "answers_second": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.6,
            "probabilities": {
              "yes": 0.24,
              "no": 0.73,
              "unclear": 0.03
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.02,
              "no": 0.96,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.83,
            "probabilities": {
              "yes": 0.07,
              "no": 0.89,
              "unclear": 0.04
            }
          }
        },
        "to_fix": {
          "where": null,
          "change": "exclude --id REQ-RUN-0320 --item b-16 --reason \"This sprint does not implement the copy or host-aggregate storage adaptor patterns across consumer repositories.\""
        }
      },
      {
        "anchor_id": "REQ-RUN-0322",
        "verdict": "underspecified",
        "leaning": "not_addressed",
        "min_confidence": 0.37,
        "attempts": 1,
        "explanation": "Jev was not confident (min confidence 0.37); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.72,
            "probabilities": {
              "yes": 0.81,
              "no": 0.18,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.37,
            "probabilities": {
              "yes": 0.37,
              "no": 0.58,
              "unclear": 0.05
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.38,
            "probabilities": {
              "yes": 0.39,
              "no": 0.59,
              "unclear": 0.02
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "compliance",
            "question_id": "addressed",
            "choice": "no",
            "confidence": 0.37
          },
          {
            "ask": "first",
            "role": "conflict",
            "question_id": "contradicted",
            "choice": "no",
            "confidence": 0.38
          }
        ],
        "to_fix": {
          "where": "Applications can register their own Monty host calls;",
          "change": "Clarify that Monty host-call handlers are distinct from storage adaptors: nonstandard adaptors remain consumer-written from store building blocks."
        }
      },
      {
        "anchor_id": "REQ-RUN-0324",
        "verdict": "underspecified",
        "leaning": "not_applicable",
        "min_confidence": 0.55,
        "attempts": 2,
        "unstable": true,
        "explanation": "Jev was not confident (min confidence 0.55); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.55,
            "probabilities": {
              "yes": 0.28,
              "no": 0.7,
              "unclear": 0.02
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "yes": 0.03,
              "no": 0.94,
              "unclear": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.7,
            "probabilities": {
              "yes": 0.18,
              "no": 0.8,
              "unclear": 0.02
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.55
          }
        ],
        "answers_second": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.61,
            "probabilities": {
              "yes": 0.25,
              "no": 0.74,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.02,
              "no": 0.95,
              "unclear": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.72,
            "probabilities": {
              "yes": 0.17,
              "no": 0.81,
              "unclear": 0.02
            }
          }
        },
        "to_fix": {
          "where": null,
          "change": "exclude --id REQ-RUN-0324 --item b-16 --reason \"This sprint does not implement a consumer adaptor that copies rows between local and remote stores.\""
        }
      },
      {
        "anchor_id": "REQ-RUN-0325",
        "verdict": "underspecified",
        "leaning": "not_applicable",
        "min_confidence": 0.44,
        "attempts": 1,
        "explanation": "Jev was not confident (min confidence 0.44); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.44,
            "probabilities": {
              "yes": 0.36,
              "no": 0.63,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.85,
            "probabilities": {
              "yes": 0.07,
              "no": 0.9,
              "unclear": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.04,
              "no": 0.95,
              "unclear": 0.01
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.44
          }
        ],
        "to_fix": {
          "where": null,
          "change": "exclude --id REQ-RUN-0325 --item b-16 --reason \"The generated example and Monty host registry do not move rows between stores.\""
        }
      },
      {
        "anchor_id": "REQ-RUN-0326",
        "verdict": "underspecified",
        "leaning": "not_applicable",
        "min_confidence": 0.52,
        "attempts": 2,
        "confirmed": true,
        "explanation": "Jev was not confident (min confidence 0.52); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.52,
            "probabilities": {
              "yes": 0.31,
              "no": 0.68,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.73,
            "probabilities": {
              "yes": 0.15,
              "no": 0.82,
              "unclear": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "yes": 0.06,
              "no": 0.92,
              "unclear": 0.02
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.52
          }
        ],
        "to_fix": {
          "where": null,
          "change": "exclude --id REQ-RUN-0326 --item b-16 --reason \"This sprint does not define the supported database-store combinations for a newly generated application.\""
        }
      },
      {
        "anchor_id": "REQ-RUN-0327",
        "verdict": "underspecified",
        "leaning": "not_applicable",
        "min_confidence": 0.42,
        "attempts": 1,
        "explanation": "Jev was not confident (min confidence 0.42); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.42,
            "probabilities": {
              "yes": 0.38,
              "no": 0.61,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.83,
            "probabilities": {
              "yes": 0.08,
              "no": 0.89,
              "unclear": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.89,
            "probabilities": {
              "yes": 0.05,
              "no": 0.93,
              "unclear": 0.02
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "relevance",
            "question_id": "relevant",
            "choice": "no",
            "confidence": 0.42
          }
        ],
        "to_fix": {
          "where": null,
          "change": "exclude --id REQ-RUN-0327 --item b-16 --reason \"This sprint does not define whether two application stores share a schema.\""
        }
      },
      {
        "anchor_id": "REQ-RUN-0328",
        "verdict": "underspecified",
        "leaning": "not_addressed",
        "min_confidence": 0.31,
        "attempts": 2,
        "confirmed": true,
        "explanation": "Jev was not confident (min confidence 0.31); the anchor or the bead may be underspecified.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.7,
            "probabilities": {
              "yes": 0.8,
              "no": 0.19,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.31,
            "probabilities": {
              "yes": 0.39,
              "no": 0.54,
              "unclear": 0.07
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.64,
            "probabilities": {
              "yes": 0.14,
              "no": 0.76,
              "unclear": 0.1
            }
          }
        },
        "low_questions": [
          {
            "ask": "first",
            "role": "compliance",
            "question_id": "addressed",
            "choice": "no",
            "confidence": 0.31
          }
        ],
        "to_fix": {
          "where": "Applications can register their own Monty host calls;",
          "change": "State that Monty host extensibility does not constrain whether a consumer uses one shared trait or distinct traits for its stores."
        }
      },
      {
        "anchor_id": "ADR-RUN-0002",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.86,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.97,
              "no": 0.03,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.86,
            "probabilities": {
              "yes": 0.91,
              "no": 0.07,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ADR-RUN-0013",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.92,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.95,
              "no": 0.04,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.03,
              "no": 0.97,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ANC-027",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.86,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.88,
            "probabilities": {
              "no": 0.07,
              "unclear": 0.01,
              "yes": 0.92
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.86,
            "probabilities": {
              "no": 0.91,
              "unclear": 0.01,
              "yes": 0.08
            }
          }
        }
      },
      {
        "anchor_id": "ANC-028",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.8,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.8,
            "probabilities": {
              "no": 0.87,
              "unclear": 0.01,
              "yes": 0.12
            }
          }
        }
      },
      {
        "anchor_id": "ANC-029",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.88,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.02,
              "unclear": 0.0,
              "yes": 0.98
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "no": 0.92,
              "unclear": 0.01,
              "yes": 0.07
            }
          }
        }
      },
      {
        "anchor_id": "ANC-030",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.91,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "no": 0.94,
              "unclear": 0.01,
              "yes": 0.05
            }
          }
        }
      },
      {
        "anchor_id": "ANC-031",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.94,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "no": 0.96,
              "unclear": 0.0,
              "yes": 0.04
            }
          }
        }
      },
      {
        "anchor_id": "ANC-032",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.89,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.89,
            "probabilities": {
              "no": 0.07,
              "unclear": 0.0,
              "yes": 0.93
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.89,
            "probabilities": {
              "no": 0.07,
              "unclear": 0.0,
              "yes": 0.93
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 1.0,
            "probabilities": {
              "no": 1.0,
              "unclear": 0.0,
              "yes": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ANC-033",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.64,
        "attempts": 2,
        "confirmed": true,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "no": 0.0,
              "unclear": 0.0,
              "yes": 1.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.64,
            "probabilities": {
              "no": 0.76,
              "unclear": 0.01,
              "yes": 0.23
            }
          }
        }
      },
      {
        "anchor_id": "ANC-035",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.97,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "no": 0.01,
              "unclear": 0.0,
              "yes": 0.99
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.02,
              "unclear": 0.0,
              "yes": 0.98
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "no": 0.98,
              "unclear": 0.0,
              "yes": 0.02
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0001",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0003",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.96,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.99,
              "no": 0.01,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.03,
              "no": 0.97,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-CRON-0005",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.92,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.99,
              "no": 0.01,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.95,
              "no": 0.04,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.02,
              "no": 0.98,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0329",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.98,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.01,
              "no": 0.99,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0503",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.88,
        "attempts": 1,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "yes",
            "confidence": 1.0,
            "probabilities": {
              "yes": 1.0,
              "no": 0.0,
              "unclear": 0.0
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "yes",
            "confidence": 0.98,
            "probabilities": {
              "yes": 0.99,
              "no": 0.01,
              "unclear": 0.0
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.88,
            "probabilities": {
              "yes": 0.08,
              "no": 0.92,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "ADR-RUN-0305",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.62,
        "attempts": 2,
        "confirmed": true,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.62,
            "probabilities": {
              "yes": 0.23,
              "no": 0.75,
              "unclear": 0.02
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "yes": 0.04,
              "no": 0.94,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.72,
            "probabilities": {
              "yes": 0.14,
              "no": 0.81,
              "unclear": 0.05
            }
          }
        }
      },
      {
        "anchor_id": "ANC-042",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.68,
        "attempts": 2,
        "confirmed": true,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.68,
            "probabilities": {
              "no": 0.79,
              "unclear": 0.01,
              "yes": 0.2
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "no": 0.94,
              "unclear": 0.01,
              "yes": 0.05
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.91,
            "probabilities": {
              "no": 0.94,
              "unclear": 0.01,
              "yes": 0.05
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0313",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.76,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.8,
            "probabilities": {
              "yes": 0.12,
              "no": 0.87,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.03,
              "no": 0.95,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.76,
            "probabilities": {
              "yes": 0.14,
              "no": 0.84,
              "unclear": 0.02
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0314",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.72,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.72,
            "probabilities": {
              "yes": 0.18,
              "no": 0.81,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.01,
              "no": 0.98,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.04,
              "no": 0.96,
              "unclear": 0.0
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0316",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.82,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.82,
            "probabilities": {
              "yes": 0.11,
              "no": 0.88,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.01,
              "no": 0.98,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.85,
            "probabilities": {
              "yes": 0.07,
              "no": 0.9,
              "unclear": 0.03
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0319",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.85,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.85,
            "probabilities": {
              "yes": 0.09,
              "no": 0.9,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.97,
            "probabilities": {
              "yes": 0.01,
              "no": 0.98,
              "unclear": 0.01
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.02,
              "no": 0.97,
              "unclear": 0.01
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0321",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.79,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.85,
            "probabilities": {
              "yes": 0.09,
              "no": 0.9,
              "unclear": 0.01
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.92,
            "probabilities": {
              "yes": 0.01,
              "no": 0.95,
              "unclear": 0.04
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.79,
            "probabilities": {
              "yes": 0.1,
              "no": 0.86,
              "unclear": 0.04
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0323",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.83,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.83,
            "probabilities": {
              "yes": 0.09,
              "no": 0.89,
              "unclear": 0.02
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.96,
            "probabilities": {
              "yes": 0.01,
              "no": 0.97,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.86,
            "probabilities": {
              "yes": 0.07,
              "no": 0.91,
              "unclear": 0.02
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0330",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.72,
        "attempts": 1,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.72,
            "probabilities": {
              "yes": 0.17,
              "no": 0.81,
              "unclear": 0.02
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.02,
              "no": 0.96,
              "unclear": 0.02
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.02,
              "no": 0.96,
              "unclear": 0.02
            }
          }
        }
      },
      {
        "anchor_id": "REQ-RUN-0331",
        "verdict": "not_applicable",
        "leaning": "not_applicable",
        "min_confidence": 0.61,
        "attempts": 2,
        "confirmed": true,
        "explanation": "The anchor does not govern this bead.",
        "answers": {
          "relevant": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.61,
            "probabilities": {
              "yes": 0.24,
              "no": 0.74,
              "unclear": 0.02
            }
          },
          "addressed": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.94,
            "probabilities": {
              "yes": 0.01,
              "no": 0.96,
              "unclear": 0.03
            }
          },
          "contradicted": {
            "type": "choice",
            "choice": "no",
            "confidence": 0.76,
            "probabilities": {
              "yes": 0.14,
              "no": 0.84,
              "unclear": 0.02
            }
          }
        }
      }
    ],
    "overrides_applied": [
      "ANC-038",
      "ANC-034",
      "ANC-036",
      "ANC-037",
      "ANC-039",
      "ANC-040",
      "ANC-041",
      "ANC-027",
      "ANC-028",
      "ANC-029",
      "ANC-030",
      "ANC-031",
      "ANC-032",
      "ANC-033",
      "ANC-035",
      "ANC-042"
    ],
    "item_truncated": false,
    "shortened": [],
    "report_markdown": "## Anchor gate: plan · b-16 - Sprint b-16 — extensible Monty hosts and generated example\n\nRun `plan-20261030T051008Z-b-16`, model `jev-1.14.0`, threshold 0.6. Counts: not_addressed 1, underspecified 18, satisfied 15, not_applicable 10.\n\n> **b-16 · ANC-038 · not addressed** Anchor: The schedule registry permits deliberately supplied environment values as plaintext configuration. You said (Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected., Oct 29): \"why can we never add values?  all environment variables are not api keys?\" This bead does not carry the directive forward.\n\n> **b-16 · ANC-034 · underspecified** Anchor: Python and Monty hooks use the same schedule-environment configuration and resolution rules. You said (Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected., Oct 29): \"python/monty having consistent settings would be least confusing.\" Jev was not confident (min confidence 0.31); the anchor or the bead may be underspecified. (leaning: not_addressed)\n>   Low: relevance `relevant` answered yes at 0.31.\n>   Low: compliance `addressed` answered no at 0.55.\n>   Low: conflict `contradicted` answered no at 0.38.\n\n> **b-16 · ANC-036 · underspecified** Anchor: Each schedule can explicitly set or clear its own environment variables. You said (Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected., Oct 29): \"having each entry having the ability to set or clear specific environment variables.\" Jev was not confident (min confidence 0.31); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.31.\n>   Low: compliance `addressed` answered no at 0.52.\n>   Low: conflict `contradicted` answered no at 0.38.\n\n> **b-16 · ANC-037 · underspecified** Anchor: Schedule creation and updates never implicitly capture environment values from the caller or daemon process. You said (Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected., Oct 29): \"Never capture or persist inherited host values accidentally.\" Jev was not confident (min confidence 0.26); the anchor or the bead may be underspecified. (leaning: satisfied)\n>   Low: relevance `relevant` answered yes at 0.26.\n>   Low: conflict `contradicted` answered no at 0.58.\n\n> **b-16 · ANC-039 · underspecified** Anchor: Schedules can resolve environment values through an application-provided resolver for opaque references. You said (Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected., Oct 29): \"I also like allowing this:   \"OTHER_API_KEY\": { \"reference\": \"keychain://agents/planner-7/api-key\" }.\" Jev was not confident (min confidence 0.28); the anchor or the bead may be underspecified. (leaning: not_addressed)\n>   Low: relevance `relevant` answered yes at 0.37.\n>   Low: compliance `addressed` answered no at 0.28.\n\n> **b-16 · ANC-040 · underspecified** Anchor: Schedules can load environment variables from full-path .env files. You said (Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected., Oct 29): \"Another useful way to specify would be loading from a full-path .env file.\" Jev was not confident (min confidence 0.25); the anchor or the bead may be underspecified. (leaning: not_addressed)\n>   Low: relevance `relevant` answered yes at 0.25.\n\n> **b-16 · ANC-041 · underspecified** Anchor: Monty scripts can read their configured environment during source initialization, before hook functions run. You said (Phase B continuation discussion; all 16 statements approved, with atm_run mandatory and production dependency scope corrected., Oct 29): \"there should also be the ability to set environment variables in a monty script before it runs.\" Jev was not confident (min confidence 0.50); the anchor or the bead may be underspecified. (leaning: not_addressed)\n>   Low: relevance `relevant` answered yes at 0.50.\n>   Low: conflict `contradicted` answered no at 0.58.\n>   Low: conflict `contradicted` answered no at 0.56 (second ask).\n>   Unstable: two identical requests gave underspecified then not_addressed.\n\n> **b-16 · REQ-CRON-0002 · underspecified** Anchor: A sc-cron schedule is a normal crontab string of five fields: minute, hour, day of month, month, and day of week. REQ-CRON-0002 (requirements register) says: \"CronExpr::parse of */5 * * * * succeeds and means every fifth minute. CronExpr::parse of 0 */5 * * * * succeeds and means second 0 of every fifth minute. CronExpr::parse of @hourly succeeds.\" Jev was not confident (min confidence 0.43); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.43.\n\n> **b-16 · REQ-CRON-0004 · underspecified** Anchor: The sc-cron crate creates one schedule table. A test writes a row without constructing SqliteWriter. The crate does not migrate the consumer's other tables. Jev was not confident (min confidence 0.30); the anchor or the bead may be underspecified. (leaning: not_addressed)\n>   Low: relevance `relevant` answered yes at 0.30.\n\n> **b-16 · REQ-RUN-0315 · underspecified** Anchor: The host-aggregate adaptor is one SQLite database for this host and a Postgres database that aggregates many hosts. Jev was not confident (min confidence 0.58); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.58.\n\n> **b-16 · REQ-RUN-0317 · underspecified** Anchor: Adaptor Rust code and models in a new repository are generated by the command just new (scripts/new_project.py). Jev was not confident (min confidence 0.26); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.31.\n>   Low: compliance `addressed` answered yes at 0.26.\n\n> **b-16 · REQ-RUN-0318 · underspecified** Anchor: The library crate named sc-runtime does not generate adaptor code. Jev was not confident (min confidence 0.26); the anchor or the bead may be underspecified. (leaning: satisfied)\n>   Low: relevance `relevant` answered yes at 0.26.\n>   Low: conflict `contradicted` answered no at 0.53.\n\n> **b-16 · REQ-RUN-0320 · underspecified** Anchor: Every consumer repository uses the same generated implementation of the copy pattern and the same generated implementation of the host-aggregate pattern. Jev was not confident (min confidence 0.52); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.52.\n>   Unstable: two identical requests gave underspecified then not_applicable.\n\n> **b-16 · REQ-RUN-0322 · underspecified** Anchor: An adaptor that is neither the copy pattern nor the host-aggregate pattern is written by the consumer from the store building blocks. Jev was not confident (min confidence 0.37); the anchor or the bead may be underspecified. (leaning: not_addressed)\n>   Low: compliance `addressed` answered no at 0.37.\n>   Low: conflict `contradicted` answered no at 0.38.\n\n> **b-16 · REQ-RUN-0324 · underspecified** Anchor: The consumer adaptor moves rows between the local store and the remote store. Jev was not confident (min confidence 0.55); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.55.\n>   Unstable: two identical requests gave underspecified then not_applicable.\n\n> **b-16 · REQ-RUN-0325 · underspecified** Anchor: The sc-runtime crates do not move rows between stores. Jev was not confident (min confidence 0.44); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.44.\n\n> **b-16 · REQ-RUN-0326 · underspecified** Anchor: A new application is created with no database, with SQLite only, with one sqlx SQL engine only, or with SQLite plus one sqlx SQL engine. Jev was not confident (min confidence 0.52); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.52.\n\n> **b-16 · REQ-RUN-0327 · underspecified** Anchor: Two stores in one application use the same schema or a similar schema. Jev was not confident (min confidence 0.42); the anchor or the bead may be underspecified. (leaning: not_applicable)\n>   Low: relevance `relevant` answered no at 0.42.\n\n> **b-16 · REQ-RUN-0328 · underspecified** Anchor: Two stores in one application use one shared trait or a different trait per store. Jev was not confident (min confidence 0.31); the anchor or the bead may be underspecified. (leaning: not_addressed)\n>   Low: compliance `addressed` answered no at 0.31.\n\n"
  },
  "error": null,
  "metadata": {
    "duration_ms": 55000,
    "tool_calls": 36,
    "retry_count": 15,
    "correlation_id": "phase-b-approval-b16-planfix-20261030"
  }
}
```
