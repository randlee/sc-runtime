import concurrent.futures
import hashlib
import json
from pathlib import Path
import ssl
import sys
import urllib.error
import urllib.request
import certifi

HERE=Path(__file__).resolve().parent
gate=sys.argv[1];assert gate in ('planning','development')
V2='--v2' in sys.argv
V3='--v3' in sys.argv
FIXTURES='--fixtures' in sys.argv
FIXTURES_V5='--fixtures-v5' in sys.argv
v2_ids={'planning':{27,29,32,33,37,38,40},'development':{28,29,30,31,32,33,34,35,36,37,38,40,41,42}}
v3_ids={'planning':{27,32,33,37,38},'development':{29,30,31,32,33,34,35,36,37,38,40,41,42}}
only=sys.argv[2] if len(sys.argv)>2 and sys.argv[2].startswith('ANC-') else None
sys.path.insert(0,'/Volumes/Extreme Pro/github/sc-runtime-worktrees/codex/install-plan-anchoring/.codex/skills/plan-anchoring/scripts')
import jev_judge as jev
from result import Err
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(x):return hashlib.sha256(canonical(x)).hexdigest()

jobs=[]
for i in range(27,43):
    if FIXTURES_V5 and not (gate=='development' and i in (31,32)):continue
    if V2 and i not in v2_ids[gate]:continue
    if V3 and i not in v3_ids[gate]:continue
    aid=f'ANC-{i:03d}'
    if only and aid!=only:continue
    req=json.loads((HERE/(f'{aid}-{gate}-fixtures-v5-20261029-request.json' if FIXTURES_V5 else f'{aid}-{gate}-fixtures-v4-20261029-request.json' if FIXTURES else f'{aid}-{gate}-v3-20261029-request.json' if V3 else f'{aid}-{gate}-v2-20261029-request.json' if V2 else f'{aid}-{gate}-20261029-request.json')).read_text())
    oracle=json.loads((HERE/(f'{aid}-{gate}-fixtures-v5-oracle.json' if FIXTURES_V5 else f'{aid}-{gate}-fixtures-v4-oracle.json' if FIXTURES else f'{aid}-{gate}-oracle-v3-final.json' if V3 and aid=='ANC-038' and gate=='planning' else f'{aid}-{gate}-oracle-v3.json' if V3 else f'{aid}-{gate}-oracle-v2.json' if V2 else f'{aid}-{gate}-oracle.json')).read_text())
    candidate_path=HERE/(f'{aid}-{gate}-fixtures-v4-candidates.json' if FIXTURES_V5 or FIXTURES else f'{aid}-{gate}-candidates-v3.json' if V3 and (HERE/f'{aid}-{gate}-candidates-v3.json').exists() else f'{aid}-{gate}-candidates-v2.json' if (V2 or V3) and (HERE/f'{aid}-{gate}-candidates-v2.json').exists() else f'{aid}-{gate}-candidates.json')
    candidates=json.loads(candidate_path.read_text())
    assert oracle['authority']['anchor_id']==aid and oracle['authority']['anchor_record_sha256']==sha(req['authority']['anchors']['records'][0])
    assert oracle['authority']['intent_sha256']==req['authority']['intent']['sha256']
    assert req['repeat_count']==2 and req['candidate_minimum']==3
    manifest_path=HERE/(f'{aid}-{gate}-fixtures-v5-jev-requests.json' if FIXTURES_V5 else f'{aid}-{gate}-fixtures-v4-jev-requests.json' if FIXTURES else f'{aid}-{gate}-jev-requests-v3.json' if V3 else f'{aid}-{gate}-jev-requests-v2.json' if V2 else f'{aid}-{gate}-jev-requests.json')
    if not manifest_path.exists():
        manifest=[]
        anchor=req['authority']['anchors']['records'][0]
        for bundle in range(len(next(iter(candidates.values())))):
            questions={role:candidates[role][bundle]['question'] for role in candidates}
            for case in oracle['cases']:
                body={'model':jev.DEFAULT_MODEL,'questions':questions,'state':{'anchor':{'id':anchor['id'],'statement':anchor['statement'],'scope':anchor['scope']},'item':{'id':case['case_id'],'title':case['kind'],'text':case['item_text']}}}
                manifest.append({'correlation_id':req['correlation_id']+f'-b{bundle}-'+case['case_id'],'anchor_id':aid,'gate':gate,'bundle':bundle,'case_id':case['case_id'],'body':body,'body_sha256':sha(body)})
        manifest_path.write_text(json.dumps(manifest,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    else:manifest=json.loads(manifest_path.read_text())
    jobs.extend(manifest)

class Args:repository_root=json.loads((HERE/'ANC-027-planning-20261029-request.json').read_text())['runtime']['workspace']
preflight=jev.remote_preflight(Args(),'Frozen anchor question-tournament probes')
if isinstance(preflight,Err):print(json.dumps({'error':preflight.error.to_json()['error']}));sys.exit(2)
key=preflight.value
run_dir=HERE/(f'{gate}-tune-fixtures-v5-jev-runs' if FIXTURES_V5 else f'{gate}-tune-fixtures-v4-jev-runs' if FIXTURES else f'{gate}-tune-v3-jev-runs' if V3 else f'{gate}-tune-v2-jev-runs' if V2 else f'{gate}-tune-jev-runs');run_dir.mkdir(exist_ok=True)

def call(job):
    path=run_dir/(job['correlation_id']+f"-r{job['repeat']}.json")
    if path.exists():return json.loads(path.read_text())
    payload=canonical(job['body']);assert hashlib.sha256(payload).hexdigest()==job['body_sha256']
    record={'correlation_id':job['correlation_id'],'repeat':job['repeat'],'request_sha256':job['body_sha256'],'request':job['body'],'attempts':[]}
    for attempt in (1,2):
        request=urllib.request.Request(jev.JEV_URL,data=payload,method='POST',headers={'Authorization':f'Bearer {key}','Content-Type':'application/json','User-Agent':'plan-anchoring/jev_judge'})
        try:
            with urllib.request.urlopen(request,timeout=45,context=ssl.create_default_context(cafile=certifi.where())) as response:raw=response.read(jev.MAX_RESPONSE_BYTES+1)
            if len(raw)>jev.MAX_RESPONSE_BYTES:raise ValueError('response exceeds limit')
            parsed=json.loads(raw)
            checked=jev.validate_response(parsed,job['body']['questions'])
            if isinstance(checked,Err):raise ValueError(checked.error.code+': '+checked.error.message)
            record['attempts'].append({'attempt':attempt,'raw_response_utf8':raw.decode(),'raw_response_sha256':hashlib.sha256(raw).hexdigest(),'response':parsed,'run_id':parsed.get('id') or parsed.get('run_id') or job['correlation_id']+f"-r{job['repeat']}-a{attempt}"})
            record['success']=True;break
        except urllib.error.HTTPError as exc:record['attempts'].append({'attempt':attempt,'error':{'code':'EXECUTION.JEV','message':f'Jev HTTP {exc.code}; body withheld'}})
        except (urllib.error.URLError,OSError,ValueError,UnicodeError) as exc:record['attempts'].append({'attempt':attempt,'error':{'code':'EXECUTION.JEV','message':type(exc).__name__+': '+str(exc)}})
        if attempt==2:record['success']=False
    path.write_text(json.dumps(record,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    return record

if '--third' in sys.argv:
    third=[]
    for job in jobs:
        a=json.loads((run_dir/(job['correlation_id']+'-r1.json')).read_text())
        b=json.loads((run_dir/(job['correlation_id']+'-r2.json')).read_text())
        if not a['success'] or not b['success']:continue
        aa=a['attempts'][-1]['response']['answers'];bb=b['attempts'][-1]['response']['answers']
        if any(aa[k]['choice']!=bb[k]['choice'] for k in aa):third.append({**job,'repeat':3})
    jobs=third
else:
    if FIXTURES_V5:jobs=json.loads((HERE/f'{gate}-fixtures-v5-fresh-jobs.json').read_text())
    elif FIXTURES:jobs=json.loads((HERE/f'{gate}-fixtures-v4-fresh-jobs.json').read_text())
    jobs=[{**job,'repeat':r} for job in jobs for r in (1,2)]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(call,jobs))
print(json.dumps({'gate':gate,'requests':len(results),'successes':sum(r['success'] for r in results),'failures':[r['correlation_id'] for r in results if not r['success']]}))
