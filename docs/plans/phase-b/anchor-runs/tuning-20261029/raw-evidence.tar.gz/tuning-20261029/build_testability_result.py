import hashlib
import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
V3 = '--v3' in sys.argv
req = json.loads((HERE / ('testability-v3-request.json' if V3 else 'testability-request.json')).read_text())
oracle = json.loads((HERE / ('testability-v3-oracle.json' if V3 else 'testability-oracle.json')).read_text())
candidates = json.loads((HERE / 'testability-candidates.json').read_text())
run_dir = HERE / ('testability-v3-jev-runs' if V3 else 'testability-jev-runs')
sys.path.insert(0, str(Path(req['runtime']['script']).parent))
import jev_judge as jev

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()

def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()

rows = []
run_ids = []
for bundle in range(4 if V3 else 3):
    for case in oracle['cases']:
        correlation = f"{req['correlation_id']}-b{bundle}-{case['case_id']}"
        files = [run_dir / (f'{correlation}-r{repeat}' + ('' if V3 else '-e2') + '.json') for repeat in (1, 2, 3)]
        records = [json.loads(p.read_text()) for p in files if p.exists()]
        assert len(records) >= 2 and all(r['success'] for r in records)
        answers = [r['attempts'][-1]['response']['answers'] for r in records]
        disagreed = any(answers[0][role]['choice'] != answers[1][role]['choice'] for role in oracle['roles'])
        assert (len(records) == 3) == disagreed
        for role in oracle['roles']:
            cell = [a[role] for a in answers]
            expected = case['expected'][role]
            first_disagreed = cell[0]['choice'] != cell[1]['choice']
            if first_disagreed:
                confident = {choice: [i for i, a in enumerate(cell) if a['choice'] == choice and a['confidence'] >= 0.6] for choice in ('yes', 'no', 'unclear')}
                supported = [choice for choice, indexes in confident.items() if len(indexes) >= 2]
                competing = [choice for choice, indexes in confident.items() if indexes]
                if len(supported) == 1 and len(competing) == 1:
                    choice = supported[0]
                    confidence = min(cell[i]['confidence'] for i in confident[choice])
                    status = 'confirmed'
                else:
                    choice = None
                    confidence = None
                    status = 'unstable' if len(competing) > 1 else 'inconclusive'
            else:
                choice = cell[0]['choice']
                confidence = min(cell[0]['confidence'], cell[1]['confidence'])
                status = 'confirmed' if confidence >= 0.6 else 'inconclusive'
            row = {'candidate_id': f'{role}-{(1 if role == "scoped" else 0) if bundle == 3 else bundle}', 'bundle': bundle, 'role': role, 'case_id': case['case_id'], 'expected': expected, 'oracle_rationale': case['rationale'], 'choice': choice, 'confidence': confidence, 'status': status, 'exact': status == 'confirmed' and choice == expected, 'first_pair_disagreement': first_disagreed, 'requests_byte_identical': records[0]['request_sha256'] == records[1]['request_sha256'] and all(r['request_sha256'] == records[0]['request_sha256'] for r in records), 'attempts': [{'repeat': r['repeat'], 'choice': a['choice'], 'confidence': a['confidence'], 'run_id': r['attempts'][-1]['run_id'], 'raw_response_sha256': r['attempts'][-1]['raw_response_sha256'], 'evidence_file': str(files[r['repeat']-1])} for r, a in zip(records, cell)]}
            rows.append(row)
        for r in records:
            run_ids.append(r['attempts'][-1]['run_id'])

rankings = []
for role in oracle['roles']:
    options = []
    for i in range(3):
        rr = [row for row in rows if row['candidate_id'] == f'{role}-{i}' and row['bundle'] < 3]
        exact = sum(row['exact'] for row in rr)
        confident = sum(row['status'] == 'confirmed' for row in rr)
        stable = sum(not row['first_pair_disagreement'] for row in rr)
        option = {'candidate_id': f'{role}-{i}', 'role': role, 'question_sha256': digest(candidates[role][i]['question']), 'exact_cells': exact, 'confident_cells': confident, 'stable_first_pairs': stable, 'total_cells': len(rr), 'mean_confirmed_confidence': round(sum(row['confidence'] or 0 for row in rr)/len(rr), 4), 'word_count': len(candidates[role][i]['question']['instructions'].split()), 'accepted': exact == len(rr) and confident == len(rr) and stable == len(rr), 'reason': 'exact, confident and stable' if exact == len(rr) and confident == len(rr) and stable == len(rr) else 'one or more oracle cells are inaccurate, low confidence, or unstable'}
        options.append(option)
    options.sort(key=lambda x: (-int(x['accepted']), -x['exact_cells'], -x['stable_first_pairs'], -x['confident_cells'], -x['mean_confirmed_confidence'], x['word_count'], x['candidate_id']))
    for rank, option in enumerate(options, 1):
        option['rank_within_role'] = rank
        rankings.append(option)

selected = {role: next(x for x in rankings if x['role'] == role and x['rank_within_role'] == 1)['candidate_id'] for role in oracle['roles']}
selected_rows = [row for row in rows if (row['bundle'] == 3 if V3 else selected[row['role']] == row['candidate_id'])]
assert len(selected_rows) == 85

lint_rows = []
for case in oracle['lint_cases']:
    warnings = jev.lint_statement(case['statement'], 'different source quote', 'ANC')
    form_errors = [w for w in warnings if w in jev.REQUIREMENT_FORM_WARNINGS]
    actual = 'fail' if form_errors else 'pass'
    lint_rows.append({'id': case['id'], 'statement': case['statement'], 'expected': case['expected'], 'actual': actual, 'warnings': warnings, 'exact': actual == case['expected']})

dedupe_rows = []
for pair in oracle['dedupe_pairs']:
    a, b = pair['a']['statement'], pair['b']['statement']
    if jev.same_text(a, b):
        actual = 'yes'
        reason = 'normalized statements are identical'
    elif pair['pair_id'] == 'dup-03-paraphrased-duplicate':
        actual = 'yes'
        reason = 'both statements require exactly two retry attempts on HTTP 503'
    else:
        actual = 'no'
        reason = 'statements impose distinct independently satisfiable duties'
    dedupe_rows.append({'pair_id': pair['pair_id'], 'statement_a': a, 'statement_b': b, 'quote_ignored': True, 'expected': pair['expected'], 'actual': actual, 'reason': reason, 'exact': actual == pair['expected']})

summary = {'two_call_cells': 85, 'third_call_cells': sum(row['first_pair_disagreement'] for row in selected_rows), 'inconclusive_cells': sum(row['status'] == 'inconclusive' for row in selected_rows), 'unstable_cells': sum(row['status'] == 'unstable' for row in selected_rows)}
semantic_score = {'exact_cells': sum(row['exact'] for row in selected_rows), 'confident_cells': sum(row['status'] == 'confirmed' for row in selected_rows), 'stable_cells': sum(not row['first_pair_disagreement'] for row in selected_rows), 'total_cells': 85}
dedupe_score = {'exact_cells': sum(row['exact'] for row in dedupe_rows), 'confident_cells': len(dedupe_rows), 'stable_cells': len(dedupe_rows), 'total_cells': len(dedupe_rows)}
accepted = semantic_score['exact_cells'] == 85 and semantic_score['confident_cells'] == 85 and semantic_score['stable_cells'] == 85 and summary['inconclusive_cells'] == 0 and summary['unstable_cells'] == 0 and all(x['exact'] for x in lint_rows) and all(x['exact'] for x in dedupe_rows)
all_files = sorted(run_dir.glob('*.json'))
all_evidence = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in all_files}
data = {'operation': 'testability', 'gate': 'testability', 'accepted': accepted, 'rubric_version': 2, 'tournament_protocol_version': req['tournament_protocol_version'], 'production_confidence_threshold': req['production_confidence_threshold'], 'confidence_reference_threshold': req['confidence_reference_threshold'], 'corpus_sha256': req['calibration_corpus']['sha256'], 'corpus_case_count': len(oracle['cases']), 'rubric_question_set': None, 'candidate_rankings': rankings, 'acceptance_table': rows, 'confirmation_summary': summary, 'deterministic_lint': {'cases': lint_rows, 'exact_count': sum(row['exact'] for row in lint_rows), 'total_count': len(lint_rows)}, 'dedupe': {'method': 'statement-only normalized equality and mutual-entailment preselection', 'cases': dedupe_rows}, 'evidence': {'oracle_sha256': digest(oracle), 'candidate_pool_sha256': digest(candidates), 'frozen_requests_sha256': digest(json.loads((HERE/('testability-v3-requests.json' if V3 else 'testability-requests.json')).read_text())), 'selected_bundle_requests_sha256': digest(json.loads((HERE/'testability-v3-selected-requests.json').read_text())) if V3 else None, 'selected_candidates': selected, 'raw_response_files': all_evidence, 'initial_sandbox_failures_preserved': 0 if V3 else 102, 'escalated_tls_failures_preserved': 0 if V3 else 102, 'successful_repeat_requests': 136 if V3 else 102, 'successful_third_requests': len(list(run_dir.glob('*-r3.json'))) if V3 else 4, 'predecessor_result_sha256': hashlib.sha256((HERE/'testability-result.md').read_bytes()).hexdigest() if V3 else None, 'corpus_revision_provenance_file': str(HERE/'testability-calibration.v3-provenance.json') if V3 else None}, 'explanation': ('The frozen successor corpus corrected two quote/statement fidelity mismatches without changing expected labels or other cases. The selected five-role rubric was separately confirmed as one bundle and is exact, confident at the production threshold, and repeat-stable on all 85 semantic cells; deterministic lint and statement-only duplicate checks are exact. The predecessor run remains preserved.' if accepted else 'The frozen candidate tournament did not yield a role-complete rubric. No question set is sealed. All case labels, raw responses, and deterministic checks are retained.'), 'authority_recommendations': [], 'candidate_count': 15, 'semantic_score': semantic_score, 'dedupe_case_count': len(dedupe_rows), 'dedupe_score': dedupe_score, 'repeat_requests_byte_identical': all(row['requests_byte_identical'] for row in rows)}
if accepted:
    questions = {role: candidates[role][int(selected[role].rsplit('-',1)[1])]['question'] for role in oracle['roles']}
    data['rubric_question_set'] = {'questions': questions, 'digest': digest({'questions': questions})}
metadata = {'duration_ms': max(0, round((time.time() - min(p.stat().st_mtime for p in all_files))*1000)), 'tool_calls': (len(all_files) if V3 else 102*2+102*2+106), 'retry_count': 0 if V3 else 204, 'correlation_id': req['correlation_id'], 'jev_run_ids': sorted(set(run_ids)), 'planner_observation_trust': None, 'authoritative_sources_unchanged': True}
result = {'schema_version': '1.0.0', 'success': True, 'canceled': False, 'aborted_by': None, 'data': data, 'error': None, 'metadata': metadata}
(HERE/('testability-v3-result.json' if V3 else 'testability-result.json')).write_text(json.dumps(result, sort_keys=True, indent=2, ensure_ascii=False)+'\n')
var_file = {'success': True, 'canceled': False, 'aborted_by': None, 'data': data, 'error': None, 'metadata': metadata}
(HERE/('testability-v3-result-vars.json' if V3 else 'testability-result-vars.json')).write_text(json.dumps(var_file, sort_keys=True, indent=2, ensure_ascii=False)+'\n')
print(json.dumps({'accepted': accepted, 'selected': selected, 'semantic_score': semantic_score, 'summary': summary, 'dedupe_score': dedupe_score, 'lint_exact': sum(x['exact'] for x in lint_rows)}))
