import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
request = json.loads((HERE / 'testability-request.json').read_text())
corpus = json.loads(Path(request['calibration_corpus']['path']).read_text())

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()

assert digest(corpus) == request['calibration_corpus']['sha256']
assert digest(request['authority']['intent']['content']) == request['authority']['intent']['sha256'] or hashlib.sha256(request['authority']['intent']['content'].encode()).hexdigest() == request['authority']['intent']['sha256']

variants = {
 'single_constraint': [
  ('Does anchor.statement impose exactly one independently enforceable duty? A subject, condition, and several output surfaces can describe one duty.', 'One invariant is stated; all details are evaluated as one obligation.', 'Two duties can be satisfied or violated independently.', 'It is unclear whether the described duties are independent.'),
  ('Could the stated requirement be split into two separately enforceable requirements without losing meaning? Answer yes only when it cannot.', 'The statement has one enforceable constraint, even if it names multiple artifacts or surfaces.', 'It joins two or more separately enforceable constraints.', 'The independence of its constraints cannot be determined.'),
 ],
 'observable': [
  ('Can a reviewer inspect behavior or an artifact and determine whether anchor.statement holds? Judge observability only.', 'A named outcome or artifact permits a determinate check.', 'Only an undefined quality, private shorthand, or approval without a record is offered.', 'Some evidence is named but the necessary observation is ambiguous.'),
  ('Does anchor.statement identify an outcome whose presence or absence can be checked?', 'An observable behavior or artifact settles the stated outcome.', 'There is no observable outcome because the statement relies on subjective quality, undefined shorthand, or unrecorded approval.', 'The outcome might be observable, but the statement does not identify enough to check it.'),
 ],
 'faithful': [
  ('Does anchor.statement preserve one requirement supported by anchor.quote without adding substantive policy? Allow ordinary formalization and selection of one directive from a compound quote.', 'The quote supports the same obligation after ordinary normalization.', 'The statement adds a policy, strength, trigger, algorithm, or outcome absent from the quote.', 'It is uncertain whether ordinary normalization preserves the obligation.'),
  ('Compare anchor.statement with anchor.quote for substantive equivalence of the selected directive. Ignore vagueness and wording changes.', 'The statement formalizes a supported directive and adds no new substantive constraint.', 'It invents a substantive requirement beyond the selected directive.', 'The quote leaves it unclear whether the added detail is merely normalization.'),
 ],
 'scoped': [
  ('Can a reviewer identify the component, activity, artifact, or explicit all-items set governed by anchor.statement and anchor.scope? Ignore other defects.', 'The applicable work area or explicit global set is identifiable.', 'No governed work area or applicability set is identifiable.', 'An area is named, but its applicability is unresolved.'),
  ('Taken together, do anchor.statement and anchor.scope tell where this requirement applies?', 'They identify the governed work, including an explicit global boundary.', 'They identify no applicable work.', 'They name a possible work area without settling its boundary.'),
 ],
 'self_contained': [
  ('Can anchor.statement be understood and applied without private definitions or an unrecorded human decision? Ignore grammar, bundling, fidelity, and scope.', 'Ordinary technical terms and concrete conditions suffice; no decisive outside context is needed.', 'A decisive term is subjective or private shorthand, or approval has no identified record.', 'A possible outside dependency is present but its decisiveness is uncertain.'),
  ('Does anchor.statement give enough meaning on its own to apply the stated duty, allowing ordinary technical vocabulary?', 'No undefined quality, private label, or unrecorded approval is needed.', 'Applying it requires an undefined quality, private label, or approval with no record.', 'The statement leaves an outside-context dependency uncertain.'),
 ],
}

candidates = {}
for role, base in request['current_questions'].items():
    candidates[role] = [{'id': f'{role}-0', 'question': base, 'origin': 'current'}]
    for idx, (instructions, yes, no, unclear) in enumerate(variants[role], 1):
        candidates[role].append({'id': f'{role}-{idx}', 'question': {'type': 'choice', 'instructions': instructions, 'criteria': {'yes': yes, 'no': no, 'unclear': unclear}}, 'origin': 'candidate'})

oracle = {'schema': 'plan-anchor/testability-oracle/2', 'corpus_sha256': digest(corpus), 'roles': ['single_constraint', 'observable', 'faithful', 'scoped', 'self_contained'], 'cases': [{'case_id': c['case_id'], 'state': c['state'], 'expected': {'single_constraint': c['expected']['atomicity'], **{k:v for k,v in c['expected'].items() if k != 'atomicity'}}, 'rationale': c['rationale']} for c in corpus['semantic_cases']], 'lint_cases': corpus['requirement_form_lint_cases'], 'dedupe_pairs': corpus['dedupe_pairs']}
for name, value in [('testability-candidates.json', candidates), ('testability-oracle.json', oracle)]:
    target = HERE / name
    assert not target.exists(), target
    target.write_text(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False) + '\n')
    print(name, digest(value))
