import hashlib,json
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,'/Volumes/Extreme Pro/github/sc-runtime-worktrees/codex/install-plan-anchoring/.codex/skills/plan-anchoring/scripts')
import jev_judge as jev
from result import Err
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(x):return hashlib.sha256(canonical(x)).hexdigest()
entries=[];overrides={}
for gate in ('planning','development'):
    gate_overrides={}
    base=jev.load_question_set('plan' if gate=='planning' else 'dev')
    assert not isinstance(base,Err)
    for i in range(27,43):
        aid=f'ANC-{i:03d}'
        suffix='fixtures-v5' if gate=='development' and i in (31,32) else 'fixtures-v4'
        result_path=HERE/f'{aid}-{gate}-{suffix}-20261029-result.json'
        markdown_path=HERE/f'{aid}-{gate}-{suffix}-20261029-result.md'
        request_path=HERE/f'{aid}-{gate}-{suffix}-20261029-request.json'
        result=json.loads(result_path.read_text());request=json.loads(request_path.read_text());data=result['data']
        assert data['accepted'] and result['success'] and data['sealed_question_set']
        anchor=request['authority']['anchors']['records'][0]
        event=data['tuning_history_after']['events'][-1]
        assert event['authority']['anchor_record_sha256']==sha(anchor)
        assert event['authority']['anchor_version']==anchor['version']
        assert event['oracle']['sha256']==data['oracle_sha256']
        assert event['decision']['question_set_sha256']==data['sealed_question_set']['digest']
        assert data['sealed_question_set']['digest']==sha({'questions':data['sealed_question_set']['questions']})
        override={'questions':data['sealed_question_set']['questions']}
        merged=jev.merge_overrides(base.value,override)
        assert not isinstance(merged,Err)
        gate_overrides[aid]=override
        entries.append({'anchor_id':aid,'gate':gate,'authority_version':anchor['version'],'authority_record_sha256':sha(anchor),'result_path':str(result_path),'result_sha256':sha(result),'rendered_result_path':str(markdown_path),'request_path':str(request_path),'sealed_question_set_digest':data['sealed_question_set']['digest'],'oracle_sha256':data['oracle_sha256'],'tuning_history_after_sha256':data['tuning_history_after_sha256'],'selected_bundle':data['evidence']['selected_bundle'],'semantic_score':data['semantic_score'],'confidence_diagnostics':data['confidence_diagnostics'],'fixture_pass_count':len(anchor['fixtures']['pass']),'fixture_fail_count':len(anchor['fixtures']['fail'])})
    target=HERE/f'{gate}-final-question-overrides.json'
    target.write_text(json.dumps(gate_overrides,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    overrides[gate]={'path':str(target),'sha256':sha(gate_overrides),'anchor_count':len(gate_overrides)}
inventory={'schema':'plan-anchor/final-tuning-inventory/1','authority':'approved Phase B intent v2 and locked ANC-027 through ANC-042 with record fixtures','accepted_count':len(entries),'entries':entries,'overrides':overrides,'scope':'Question calibration only; no active plan was used as oracle and no authority or plan text was edited by anchor-tuning.'}
assert len(entries)==32
target=HERE/'final-tuning-inventory.json';target.write_text(json.dumps(inventory,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'inventory_path':str(target),'inventory_sha256':sha(inventory),'accepted_count':len(entries),'overrides':overrides},sort_keys=True))
