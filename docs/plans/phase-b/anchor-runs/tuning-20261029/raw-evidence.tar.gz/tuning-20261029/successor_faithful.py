import concurrent.futures
import hashlib
import json
from pathlib import Path
import ssl
import sys
import urllib.error
import urllib.request
import certifi

HERE = Path(__file__).resolve().parent
REQUEST = json.loads((HERE/'testability-request.json').read_text())
ORACLE = json.loads((HERE/'testability-oracle.json').read_text())
sys.path.insert(0,str(Path(REQUEST['runtime']['script']).parent))
import jev_judge as jev
from result import Err

def canonical(x):
    return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(x):
    return hashlib.sha256(canonical(x)).hexdigest()

variants = [
 {'id':'faithful-s1-boundaries','question':{'type':'choice','instructions':'Does anchor.statement preserve the selected obligation in anchor.quote, including its governed output surfaces and permitted value types? Ordinary formalization is allowed, but narrowing or broadening an output surface or a value type changes meaning. A compound quote may yield one supported directive.','criteria':{'yes':'The selected quoted directive supports the same obligation and boundaries after ordinary formalization.','no':'The statement changes an output surface, value type, trigger, strength, algorithm, or outcome beyond the selected directive.','unclear':'The quote leaves a material boundary uncertain, so the change cannot be classified as ordinary formalization.'}}},
 {'id':'faithful-s2-mutual-entailment','question':{'type':'choice','instructions':'Compare anchor.quote and anchor.statement for the selected directive. Could an implementation satisfy one while violating the other because the statement adds, removes, narrows, or widens a material condition? Ignore grammar and testability.','criteria':{'yes':'No material counterexample exists after ordinary normalization and selecting one directive from a compound quote.','no':'A concrete implementation could satisfy one while violating the other because their substantive constraints differ.','unclear':'The quote is too ambiguous to decide whether such a counterexample is substantive.'}}},
 {'id':'faithful-s3-supported-specificity','question':{'type':'choice','instructions':'Is every substantive specification in anchor.statement licensed by anchor.quote for the selected requirement? Treat colloquial must/should, print/emit, and equivalent technical terms as ordinary normalization; preserve data shapes, channels, and applicability boundaries.','criteria':{'yes':'Every substantive detail follows from the quote or ordinary normalization.','no':'At least one data shape, channel, boundary, trigger, strength, or outcome is invented or replaced.','unclear':'The quote does not determine whether the disputed detail is substantive.'}}},
]

if '--freeze' in sys.argv:
    path=HERE/'testability-successor-faithful-candidates.json'
    assert not path.exists()
    path.write_text(json.dumps(variants,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    manifest=[]
    for variant in variants:
        for case in ORACLE['cases']:
            body={'model':jev.DEFAULT_MODEL,'questions':{'faithful':variant['question']},'state':case['state']}
            manifest.append({'correlation_id':REQUEST['correlation_id']+'-'+variant['id']+'-'+case['case_id'],'candidate_id':variant['id'],'case_id':case['case_id'],'body':body,'body_sha256':sha(body)})
    target=HERE/'testability-successor-faithful-requests.json'
    assert not target.exists()
    target.write_text(json.dumps(manifest,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'candidates_sha256':sha(variants),'requests_sha256':sha(manifest),'candidate_count':len(variants),'cases':len(ORACLE['cases'])}))
    sys.exit(0)

variants=json.loads((HERE/'testability-successor-faithful-candidates.json').read_text())
manifest=json.loads((HERE/'testability-successor-faithful-requests.json').read_text())
class Args:
    repository_root=REQUEST['runtime']['workspace']
preflight=jev.remote_preflight(Args(),'Frozen successor fidelity candidate requests')
if isinstance(preflight,Err):
    print(json.dumps({'error':preflight.error.to_json()['error']}));sys.exit(2)
key=preflight.value
run_dir=HERE/'testability-successor-faithful-runs';run_dir.mkdir(exist_ok=True)

def call(job):
    path=run_dir/(job['correlation_id']+f"-r{job['repeat']}.json")
    if path.exists():return json.loads(path.read_text())
    payload=canonical(job['body']);assert hashlib.sha256(payload).hexdigest()==job['body_sha256']
    record={'correlation_id':job['correlation_id'],'repeat':job['repeat'],'request_sha256':job['body_sha256'],'request':job['body'],'attempts':[]}
    for attempt in (1,2):
        req=urllib.request.Request(jev.JEV_URL,data=payload,method='POST',headers={'Authorization':f'Bearer {key}','Content-Type':'application/json','User-Agent':'plan-anchoring/jev_judge'})
        try:
            with urllib.request.urlopen(req,timeout=45,context=ssl.create_default_context(cafile=certifi.where())) as response:
                raw=response.read(jev.MAX_RESPONSE_BYTES+1)
            if len(raw)>jev.MAX_RESPONSE_BYTES:raise ValueError('response exceeds limit')
            obj=json.loads(raw)
            checked=jev.validate_response(obj,job['body']['questions'])
            if isinstance(checked,Err):raise ValueError(checked.error.code+': '+checked.error.message)
            record['attempts'].append({'attempt':attempt,'raw_response_utf8':raw.decode(),'raw_response_sha256':hashlib.sha256(raw).hexdigest(),'response':obj,'run_id':obj.get('id') or obj.get('run_id') or job['correlation_id']+f"-r{job['repeat']}-a{attempt}"})
            record['success']=True;break
        except urllib.error.HTTPError as exc:
            record['attempts'].append({'attempt':attempt,'error':{'code':'EXECUTION.JEV','message':f'Jev HTTP {exc.code}; body withheld'}})
        except (urllib.error.URLError,OSError,ValueError,UnicodeError) as exc:
            record['attempts'].append({'attempt':attempt,'error':{'code':'EXECUTION.JEV','message':type(exc).__name__+': '+str(exc)}})
        if attempt==2:record['success']=False
    path.write_text(json.dumps(record,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    return record

jobs=[{**item,'repeat':repeat} for item in manifest for repeat in (1,2)]
if '--third' in sys.argv:
    jobs=[]
    for item in manifest:
        a=json.loads((run_dir/(item['correlation_id']+'-r1.json')).read_text())['attempts'][-1]['response']['answers']['faithful']['choice']
        b=json.loads((run_dir/(item['correlation_id']+'-r2.json')).read_text())['attempts'][-1]['response']['answers']['faithful']['choice']
        if a!=b:jobs.append({**item,'repeat':3})
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(call,jobs))
print(json.dumps({'requests':len(results),'successes':sum(r['success'] for r in results),'failures':[r['correlation_id'] for r in results if not r['success']]}))
