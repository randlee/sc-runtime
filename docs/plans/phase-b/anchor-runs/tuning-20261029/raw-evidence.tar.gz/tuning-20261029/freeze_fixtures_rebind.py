import hashlib,json
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,'/Volumes/Extreme Pro/github/sc-runtime-worktrees/codex/install-plan-anchoring/.codex/skills/plan-anchoring/scripts')
import jev_judge as jev
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(x):return hashlib.sha256(canonical(x)).hexdigest()
six={('ANC-033','planning'),('ANC-030','development'),('ANC-031','development'),('ANC-032','development'),('ANC-035','development'),('ANC-038','development')}
for gate in ('planning','development'):
 roles={'relevance':'relevant','compliance':'addressed' if gate=='planning' else 'implemented','conflict':'contradicted' if gate=='planning' else 'violated'}
 if gate=='development':roles['evidence']='evidenced'
 for i in range(27,43):
  aid=f'ANC-{i:03d}';req=json.loads((HERE/f'{aid}-{gate}-fixtures-v4-20261029-request.json').read_text());anchor=req['authority']['anchors']['records'][0]
  if (aid,gate) in six:
   source_oracle_path=HERE/f'{aid}-{gate}-oracle-v4.json'
   source_candidate_path=HERE/(f'{aid}-{gate}-candidates-v4.json' if (HERE/f'{aid}-{gate}-candidates-v4.json').exists() else f'{aid}-{gate}-candidates-v3.json' if (HERE/f'{aid}-{gate}-candidates-v3.json').exists() else f'{aid}-{gate}-candidates.json')
  else:
   selected=None
   for ver in ('v3-','v2-',''):
    p=HERE/f'{aid}-{gate}-{ver}20261029-result.json'
    if p.exists():
     r=json.loads(p.read_text())
     if r['data']['accepted']:selected=r;break
   assert selected is not None,(aid,gate)
   source_oracle_path=Path(selected['data']['evidence']['oracle_file'])
   source_candidate_path=Path(selected['data']['evidence']['candidate_file'])
  old=json.loads(source_oracle_path.read_text());candidates=json.loads(source_candidate_path.read_text())
  assert len(next(iter(candidates.values())))>=3
  new=json.loads(json.dumps(old));new['correlation_id']=req['correlation_id'];new['authority']={'intent_id':req['authority']['intent']['id'],'intent_version':req['authority']['intent']['version'],'intent_sha256':req['authority']['intent']['sha256'],'anchor_id':aid,'anchor_version':anchor['version'],'anchor_record_sha256':sha(anchor)}
  fixtures=anchor['fixtures'];assert len(fixtures['pass'])>=1 and len(fixtures['fail'])>=1
  added=[]
  for label in ('pass','fail'):
   for index,text in enumerate(fixtures[label],1):
    expected=({'relevant':'yes','addressed':'yes','contradicted':'no'} if label=='pass' else {'relevant':'yes','addressed':'no','contradicted':'yes'}) if gate=='planning' else ({'relevant':'yes','implemented':'yes','violated':'no','evidenced':'yes'} if label=='pass' else {'relevant':'yes','implemented':'no','violated':'yes','evidenced':'no'})
    answers={k:{'choice':v,'confidence':1.0,'probabilities':{'yes':1.0 if v=='yes' else 0.0,'no':1.0 if v=='no' else 0.0,'unclear':1.0 if v=='unclear' else 0.0}} for k,v in expected.items()}
    case={'case_id':aid+'-'+gate+'-fixture-'+label+'-'+str(index),'kind':'fixture_'+label,'item_text':text,'expected':expected,'authority_rationale':f'{aid} v{anchor["version"]} approved {label} fixture from locked anchor record','expected_verdict':jev.decide(answers,roles,0.0,anchor['kind'])[0]}
    new['cases'].append(case);added.append(case['case_id'])
  opath=HERE/f'{aid}-{gate}-fixtures-v4-oracle.json';cpath=HERE/f'{aid}-{gate}-fixtures-v4-candidates.json';mpath=HERE/f'{aid}-{gate}-fixtures-v4-jev-requests.json';prov=HERE/f'{aid}-{gate}-fixtures-v4-provenance.json'
  assert not any(p.exists() for p in (opath,cpath,mpath,prov))
  opath.write_text(json.dumps(new,sort_keys=True,indent=2,ensure_ascii=False)+'\n');cpath.write_text(json.dumps(candidates,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
  manifest=[]
  for b in range(len(next(iter(candidates.values())))):
   questions={role:candidates[role][b]['question'] for role in candidates}
   for case in new['cases']:
    body={'model':jev.DEFAULT_MODEL,'questions':questions,'state':{'anchor':{'id':anchor['id'],'statement':anchor['statement'],'scope':anchor['scope']},'item':{'id':case['case_id'],'title':case['kind'],'text':case['item_text']}}}
    manifest.append({'correlation_id':req['correlation_id']+f'-b{b}-'+case['case_id'],'anchor_id':aid,'gate':gate,'bundle':b,'case_id':case['case_id'],'body':body,'body_sha256':sha(body)})
  mpath.write_text(json.dumps(manifest,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
  provenance={'schema':'plan-anchor/fixtures-rebind-provenance/1','source_oracle_file':str(source_oracle_path),'source_oracle_sha256':sha(old),'source_candidate_file':str(source_candidate_path),'source_candidate_sha256':sha(candidates),'new_authority_record_sha256':sha(anchor),'new_oracle_sha256':sha(new),'new_manifest_sha256':sha(manifest),'added_fixture_cases':added,'existing_case_ids_and_expected_labels_unchanged':True}
  prov.write_text(json.dumps(provenance,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
  print(aid,gate,'cases',len(new['cases']),'bundles',len(next(iter(candidates.values()))),'oracle',sha(new))
