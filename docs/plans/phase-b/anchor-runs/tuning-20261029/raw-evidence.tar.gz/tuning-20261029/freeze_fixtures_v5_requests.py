import hashlib,json,shutil
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,'/Volumes/Extreme Pro/github/sc-runtime-worktrees/codex/install-plan-anchoring/.codex/skills/plan-anchoring/scripts')
import jev_judge as jev
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(x):return hashlib.sha256(canonical(x)).hexdigest()
src=HERE/'development-tune-fixtures-v4-jev-runs';dst=HERE/'development-tune-fixtures-v5-jev-runs';dst.mkdir(exist_ok=True)
index={}
for path in src.glob('*-r[12].json'):
    rec=json.loads(path.read_text());assert sha(rec['request'])==rec['request_sha256'];stem=path.stem.rsplit('-r',1)[0];index.setdefault(rec['request_sha256'],{}).setdefault(stem,{})[rec['repeat']]=(path,rec['request'])
fresh=[];bindings=[]
for i in (31,32):
    aid=f'ANC-{i:03d}';req=json.loads((HERE/f'{aid}-development-fixtures-v5-20261029-request.json').read_text());oracle=json.loads((HERE/f'{aid}-development-fixtures-v5-oracle.json').read_text());candidates=json.loads((HERE/f'{aid}-development-fixtures-v4-candidates.json').read_text());anchor=req['authority']['anchors']['records'][0]
    assert oracle['correlation_id']==req['correlation_id'] and oracle['authority']['anchor_record_sha256']==sha(anchor)
    manifest=[]
    for b in range(len(next(iter(candidates.values())))):
        questions={role:candidates[role][b]['question'] for role in candidates}
        for case in oracle['cases']:
            body={'model':jev.DEFAULT_MODEL,'questions':questions,'state':{'anchor':{'id':anchor['id'],'statement':anchor['statement'],'scope':anchor['scope']},'item':{'id':case['case_id'],'title':case['kind'],'text':case['item_text']}}}
            job={'correlation_id':req['correlation_id']+f'-b{b}-'+case['case_id'],'anchor_id':aid,'gate':'development','bundle':b,'case_id':case['case_id'],'body':body,'body_sha256':sha(body)};manifest.append(job)
            pair=None
            for stem,repeats in index.get(job['body_sha256'],{}).items():
                if 1 in repeats and 2 in repeats and repeats[1][1]==body and repeats[2][1]==body:pair=repeats;break
            if pair:
                for r in (1,2):
                    source=pair[r][0];target=dst/(job['correlation_id']+f'-r{r}.json');assert not target.exists();shutil.copyfile(source,target);assert target.read_bytes()==source.read_bytes();bindings.append({'new_correlation_id':job['correlation_id'],'repeat':r,'source_file':str(source),'bound_file':str(target),'request_sha256':job['body_sha256']})
            else:fresh.append(job)
    p=HERE/f'{aid}-development-fixtures-v5-jev-requests.json';assert not p.exists();p.write_text(json.dumps(manifest,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
(HERE/'development-fixtures-v5-reuse-bindings.json').write_text(json.dumps({'bindings':bindings,'exact_body_verified':True},sort_keys=True,indent=2,ensure_ascii=False)+'\n')
(HERE/'development-fixtures-v5-fresh-jobs.json').write_text(json.dumps(fresh,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
print('reused',len(bindings),'fresh_jobs',len(fresh),'fresh_repeat_calls',2*len(fresh))
