```json
{
  "success": true,
  "canceled": false,
  "aborted_by": null,
  "data": {
    "gate": "plan",
    "item_id": "b-13",
    "run_id": "plan-20261030T013109Z-b-13",
    "run_path": "doc/plan/phase-current/anchor-runs/tuning-20261029/final-plan-gates/plan-20261030T013109Z-b-13.json",
    "dry_run": false,
    "reused_run": false,
    "pass": true,
    "failing": [],
    "errors": [],
    "excluded": [],
    "results": [
      {
        "anchor_id": "ANC-031",
        "verdict": "satisfied",
        "leaning": "satisfied",
        "min_confidence": 0.86,
        "attempts": 1,
        "confirmed": false,
        "unstable": false,
        "explanation": "The directive is carried forward.",
        "answers": {
          "relevant": {"type": "choice", "choice": "yes", "confidence": 0.98, "probabilities": {"no": 0.01, "unclear": 0.0, "yes": 0.99}},
          "addressed": {"type": "choice", "choice": "yes", "confidence": 1.0, "probabilities": {"no": 0.0, "unclear": 0.0, "yes": 1.0}},
          "contradicted": {"type": "choice", "choice": "no", "confidence": 0.86, "probabilities": {"no": 0.91, "unclear": 0.01, "yes": 0.08}}
        }
      }
    ],
    "overrides_applied": ["ANC-031"],
    "item_truncated": false,
    "shortened": [],
    "report_markdown": "## Anchor gate: plan · b-13 - Sprint b-13 — observability injection contract and adoption\n\nRun `plan-20261030T013109Z-b-13`, model `jev-1.14.0`, threshold 0.6. Counts: satisfied 1.\n\nAll judged anchors are satisfied or not applicable."
  },
  "error": null,
  "metadata": {
    "duration_ms": 77000,
    "tool_calls": 12,
    "retry_count": 0,
    "correlation_id": "phase-b-final-b13-20261029"
  }
}
```
