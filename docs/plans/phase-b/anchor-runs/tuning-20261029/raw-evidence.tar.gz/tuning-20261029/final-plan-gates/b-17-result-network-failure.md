```json
{
  "schema_version": "1.0.0",
  "success": false,
  "canceled": false,
  "aborted_by": null,
  "data": null,
  "error": {
    "code": "JEV.NETWORK",
    "message": "10 of 10 judged cells got no answer from Jev: ANC-031: JEV.NETWORK (Could not reach Jev: [Errno 8] nodename nor servname provided, or not known); ANC-034: JEV.NETWORK (Could not reach Jev: [Errno 8] nodename nor servname provided, or not known); ANC-035: JEV.NETWORK (Could not reach Jev: [Errno 8] nodename nor servname provided, or not known); ANC-036: JEV.NETWORK (Could not reach Jev: [Errno 8] nodename nor servname provided, or not known); ANC-037: JEV.NETWORK (Could not reach Jev: [Errno 8] nodename nor servname provided, or not known); +5 more",
    "recoverable": true,
    "suggested_action": "Check network access and retry.",
    "data": {
      "run_path": "doc/plan/phase-current/anchor-runs/tuning-20261029/final-plan-gates/plan-20261030T013122Z-b-17.json",
      "failures": [
        {
          "id": "ANC-031",
          "code": "JEV.NETWORK",
          "message": "Could not reach Jev: [Errno 8] nodename nor servname provided, or not known"
        },
        {
          "id": "ANC-034",
          "code": "JEV.NETWORK",
          "message": "Could not reach Jev: [Errno 8] nodename nor servname provided, or not known"
        },
        {
          "id": "ANC-035",
          "code": "JEV.NETWORK",
          "message": "Could not reach Jev: [Errno 8] nodename nor servname provided, or not known"
        },
        {
          "id": "ANC-036",
          "code": "JEV.NETWORK",
          "message": "Could not reach Jev: [Errno 8] nodename nor servname provided, or not known"
        },
        {
          "id": "ANC-037",
          "code": "JEV.NETWORK",
          "message": "Could not reach Jev: [Errno 8] nodename nor servname provided, or not known"
        },
        {
          "id": "ANC-038",
          "code": "JEV.NETWORK",
          "message": "Could not reach Jev: [Errno 8] nodename nor servname provided, or not known"
        },
        {
          "id": "ANC-039",
          "code": "JEV.NETWORK",
          "message": "Could not reach Jev: [Errno 8] nodename nor servname provided, or not known"
        },
        {
          "id": "ANC-040",
          "code": "JEV.NETWORK",
          "message": "Could not reach Jev: [Errno 8] nodename nor servname provided, or not known"
        },
        {
          "id": "ANC-041",
          "code": "JEV.NETWORK",
          "message": "Could not reach Jev: [Errno 8] nodename nor servname provided, or not known"
        },
        {
          "id": "ANC-042",
          "code": "JEV.NETWORK",
          "message": "Could not reach Jev: [Errno 8] nodename nor servname provided, or not known"
        }
      ]
    }
  },
  "metadata": {
    "duration_ms": 21000,
    "tool_calls": 3,
    "retry_count": 20,
    "correlation_id": "phase-b-final-b17-20261029"
  }
}
```
