import hashlib,json,shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(x):return hashlib.sha256(canonical(x)).hexdigest()
for gate in ('planning','development'):
    sources=[HERE/f'{gate}-tune-v3-jev-runs',HERE/f'{gate}-tune-v2-jev-runs',HERE/f'{gate}-tune-jev-runs']
    index={}
    for source in sources:
        if not source.exists():continue
        for path in source.glob('*-r[123].json'):
            record=json.loads(path.read_text())
            if not record.get('success'):continue
            body=record['request'];body_sha=sha(body)
            assert body_sha==record['request_sha256']
            stem=path.stem.rsplit('-r',1)[0]
            index.setdefault(body_sha,{}).setdefault(stem,{})[record['repeat']]=(path,body)
    target=HERE/f'{gate}-tune-fixtures-v4-jev-runs';target.mkdir(exist_ok=True)
    bindings=[];fresh=[]
    for i in range(27,43):
        aid=f'ANC-{i:03d}'
        manifest=json.loads((HERE/f'{aid}-{gate}-fixtures-v4-jev-requests.json').read_text())
        for job in manifest:
            group=None
            for stem,repeats in index.get(job['body_sha256'],{}).items():
                if 1 in repeats and 2 in repeats and repeats[1][1]==job['body'] and repeats[2][1]==job['body']:
                    group=(stem,repeats);break
            if group is None:
                fresh.append(job)
                continue
            stem,repeats=group
            for repeat in (1,2):
                source_path=repeats[repeat][0];dest=target/(job['correlation_id']+f'-r{repeat}.json')
                assert not dest.exists()
                shutil.copyfile(source_path,dest)
                assert source_path.read_bytes()==dest.read_bytes()
                bindings.append({'new_correlation_id':job['correlation_id'],'repeat':repeat,'source_file':str(source_path),'bound_file':str(dest),'canonical_request_sha256':job['body_sha256'],'source_file_sha256':hashlib.sha256(source_path.read_bytes()).hexdigest(),'bound_file_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'run_id':json.loads(source_path.read_text())['attempts'][-1]['run_id']})
    binding_file=HERE/f'{gate}-fixtures-v4-reuse-bindings.json';fresh_file=HERE/f'{gate}-fixtures-v4-fresh-jobs.json';assert not binding_file.exists() and not fresh_file.exists()
    binding_file.write_text(json.dumps({'schema':'plan-anchor/reused-raw-binding/1','gate':gate,'bindings':bindings,'exact_body_verified':True},sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    fresh_file.write_text(json.dumps(fresh,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    print(gate,'reused_pair_requests',len(bindings),'fresh_jobs',len(fresh),'fresh_repeat_calls',2*len(fresh))
