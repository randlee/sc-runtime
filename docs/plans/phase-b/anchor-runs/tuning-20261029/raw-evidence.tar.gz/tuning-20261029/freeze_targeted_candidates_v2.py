import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
targets={
 ('ANC-038','planning'):('contradicted',{'type':'choice','instructions':'Does item.text prohibit or narrow a class of deliberately supplied plaintext environment values that anchor.statement permits in the schedule registry? Treat an explicit secret-only ban as a conflict; silence and permitted handling are not conflicts.','criteria':{'yes':'The plan denies or narrows the anchor-permitted plaintext set-value capability.','no':'No incompatible restriction is planned.','unclear':'The planned restriction or its applicability to deliberate set values is unresolved.'}}),
 ('ANC-038','development'):('violated',{'type':'choice','instructions':'Did the delivered registry reject a class of deliberately supplied plaintext environment values that anchor.statement permits? An explicit rejection of secret set values solely because they are plaintext crosses the permission boundary.','criteria':{'yes':'Delivered behavior denies the anchor-permitted deliberate plaintext value class.','no':'No such denial is described in the delivered work.','unclear':'The delivered restriction or its applicability is ambiguous.'}}),
 ('ANC-033','development'):('violated',{'type':'choice','instructions':'Did the delivered MVP Monty runner impose script signing or a separate approval gate even though anchor.statement requires execution without either mechanism? Judge delivered restrictions, not intentions or missing evidence.','criteria':{'yes':'The delivered MVP requires a signature or a separate approval before script execution.','no':'No signing or separate approval requirement is imposed.','unclear':'The delivered gate is too vaguely described to classify.'}}),
}
def sha(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
for (aid,gate),(target_role,q) in targets.items():
    base=json.loads((HERE/f'{aid}-{gate}-candidates.json').read_text())
    revised=json.loads(json.dumps(base))
    for role in revised:
        question=q if role==target_role else revised[role][0]['question']
        revised[role].append({'id':f'{role}-3','question':question,'origin':'targeted-successor' if role==target_role else 'frozen-current-control'})
    path=HERE/f'{aid}-{gate}-candidates-v2.json'
    assert not path.exists()
    path.write_text(json.dumps(revised,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    provenance={'schema':'plan-anchor/tuning-candidate-provenance/1','predecessor_sha256':sha(base),'successor_sha256':sha(revised),'new_target_role':target_role,'candidate_id':target_role+'-3','purpose':'Test the anchor-specific permission or prohibition boundary; all original candidates remain frozen and present.'}
    (HERE/f'{aid}-{gate}-candidates-v2-provenance.json').write_text(json.dumps(provenance,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    print(aid,gate,sha(revised))
