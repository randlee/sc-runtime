import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
def sha(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
updates={
 ('ANC-033','planning'):{'boundary':'The MVP plan permits unsigned Monty scripts but still requires a separate manual approval before every execution; only the signing gate is absent.'},
 ('ANC-030','development'):{'deferred':'Refactored the atm_run test harness. This report makes no implementation claim about the host integration and describes no incompatible command or extension-interface restriction.'},
 ('ANC-031','development'):{'silent':'Updated boundary lint output formatting only. No release crate manifest, feature, or Rust import was changed, and no forbidden tool crate was added.'},
 ('ANC-032','development'):{'topical_only':'Reviewed render_template example source only. This delivered change did not alter or claim any sc-cron product contract or release criterion.'},
 ('ANC-035','development'):{'silent':'Updated daemon environment configuration parser error strings only. No allowlist or hook inheritance behavior was changed or claimed.'},
 ('ANC-038','development'):{'compliant':'Delivered schedule registry persistence for every deliberately supplied plaintext Set value, secret and nonsecret alike. Evidence: tests/anc_038.rs::all_explicit_values asserts both classes round-trip and passed.','asserted':'Delivered schedule registry persistence for every deliberately supplied plaintext Set value, secret and nonsecret alike. We followed this anchor.','silent':'Refactored schedule environment registry error strings only. No support for, or restriction on, deliberate plaintext Set values was implemented or claimed.'},
}
for (aid,gate),changes in updates.items():
 oldp=HERE/f'{aid}-{gate}-oracle-v3.json';old=json.loads(oldp.read_text());new=json.loads(json.dumps(old));diff=[]
 for case in new['cases']:
  if case['kind'] not in changes:continue
  before=case['item_text'];after=changes[case['kind']];case['item_text']=after;diff.append({'case_id':case['case_id'],'old_text':before,'new_text':after,'expected_labels_unchanged':True,'reason':'State the exact full obligation or narrow report scope explicitly, preserving approved authority and oracle expectation.'})
 assert len(diff)==len(changes)
 assert all(x['expected']==y['expected'] and x['expected_verdict']==y['expected_verdict'] for x,y in zip(old['cases'],new['cases']))
 path=HERE/f'{aid}-{gate}-oracle-v4.json';prov=HERE/f'{aid}-{gate}-oracle-v4-provenance.json';assert not path.exists() and not prov.exists();path.write_text(json.dumps(new,sort_keys=True,indent=2,ensure_ascii=False)+'\n');prov.write_text(json.dumps({'schema':'plan-anchor/tuning-oracle-provenance/1','predecessor_file':str(oldp),'predecessor_sha256':sha(old),'successor_file':str(path),'successor_sha256':sha(new),'changes':diff,'expected_labels_unchanged':True,'authority_unchanged':True},sort_keys=True,indent=2,ensure_ascii=False)+'\n');print(aid,gate,sha(new))

aid,gate='ANC-033','planning';old=json.loads((HERE/f'{aid}-{gate}-candidates.json').read_text());new=json.loads(json.dumps(old));target='addressed';q={'type':'choice','instructions':'Does item.text explicitly preserve BOTH parts of the MVP execution rule in anchor.statement: no mandatory script signing and no separate approval mechanism? A plan that retains either gate does not carry the complete rule forward.','criteria':{'yes':'The item explicitly permits MVP execution without signatures and without separate approval.','no':'The item omits this complete rule or retains either gate.','unclear':'The item names the gates but leaves whether either is mandatory unresolved.'}}
for role in new:new[role].append({'id':role+'-3','question':q if role==target else new[role][0]['question'],'origin':'targeted-successor' if role==target else 'frozen-current-control'})
path=HERE/f'{aid}-{gate}-candidates-v4.json';prov=HERE/f'{aid}-{gate}-candidates-v4-provenance.json';assert not path.exists() and not prov.exists();path.write_text(json.dumps(new,sort_keys=True,indent=2,ensure_ascii=False)+'\n');prov.write_text(json.dumps({'schema':'plan-anchor/tuning-candidate-provenance/1','predecessor_sha256':sha(old),'successor_sha256':sha(new),'new_target_role':target,'candidate_id':target+'-3','purpose':'Test completeness of two-part MVP no-gate requirement without changing conflict judgment.'},sort_keys=True,indent=2,ensure_ascii=False)+'\n');print(aid,gate,'candidate',sha(new))
