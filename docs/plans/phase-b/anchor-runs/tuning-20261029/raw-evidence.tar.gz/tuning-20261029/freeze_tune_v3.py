import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
rejected={'planning':[27,32,33,37,38],'development':[29,30,31,32,33,34,35,36,37,38,40,41,42]}
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(x):return hashlib.sha256(canonical(x)).hexdigest()
planning={
 'ANC-027':{'silent':'The team will refactor sc-cron scheduler internals, but this plan makes no decision or implementation commitment about which application-defined job kinds the library accepts.'},
 'ANC-032':{'topical_only':'Review the sc-cron product requirements and render_template release checklist; this item makes no decision about whether render_template is required.'},
 'ANC-033':{'silent':'Inventory MVP Monty runner configuration and existing signing settings; this item proposes no execution rule, signature gate, or approval gate.'},
 'ANC-037':{'topical_only':'Review schedule creation and update code paths for ambient environment capture; this item records no decision about capture or persistence policy.'},
 'ANC-038':{'conflicting':'The plan will reject every deliberately supplied plaintext environment value, whether secret or nonsecret; no plaintext set value can enter the registry.','boundary':'The plan will store deliberately supplied nonsecret plaintext values but reject deliberately supplied secret plaintext values solely because they are plaintext.'},
}
dev_special={
 'ANC-030':{'deferred':'Only optional ATM documentation polish was deferred. This delivered change has no atm_run host integration and makes no incompatible host-interface decision.'},
 'ANC-033':{'exception':'The delivered MVP runner executes unsigned, unapproved application Monty scripts; provenance is logged after execution. Evidence: tests/anc_033.rs::unsigned_unapproved_execution asserts this and passed.'},
 'ANC-034':{'exception':'Delivered Python and Monty adapters with the same schedule environment configuration and resolution rules; only the internal adapter code differs. Evidence: tests/anc_034.rs::same_rules asserts equivalent outputs and passed.'},
 'ANC-038':{'boundary':'Delivered a registry that accepts deliberate plaintext nonsecret values but rejects every deliberate plaintext secret value solely because it is plaintext. This denies part of the required value class.','exception':'Delivered a registry that accepts every deliberately supplied plaintext environment value, secret or nonsecret; the nonsecret case is only one example. Evidence: tests/anc_038.rs::all_explicit_values asserts both classes round-trip and passed.'},
 'ANC-042':{'deferred':'No first binary has been released. This change touched schedule schema validation but did not implement a first-release baseline and did not require migrations through unreleased schemas.'},
}
for gate,ids in rejected.items():
 for i in ids:
    aid=f'ANC-{i:03d}';old_path=HERE/f'{aid}-{gate}-oracle-v2.json';old=json.loads(old_path.read_text());new=json.loads(json.dumps(old));req=json.loads((HERE/f'{aid}-{gate}-v2-20261029-request.json').read_text());summary=req['authority']['anchors']['records'][0]['summary'].lower();statement=req['authority']['anchors']['records'][0]['statement'];changes=[]
    for case in new['cases']:
        kind=case['kind'];before=case['item_text'];after=None
        if gate=='planning':after=planning.get(aid,{}).get(kind)
        else:
            if kind=='silent':after=f"Changed {summary} code. This change did not implement the specific anchor behavior: {statement} It introduced no incompatible behavior."
            elif kind=='topical_only':after=f"Reviewed {summary} code. No implementation of this anchor behavior was delivered: {statement} No incompatible behavior was introduced."
            after=dev_special.get(aid,{}).get(kind,after)
            if aid=='ANC-037' and kind=='silent':after='Changed schedule creation and update serialization formatting. No implementation of the ambient environment capture prohibition was delivered, and no ambient values were captured.'
            if aid=='ANC-038' and kind=='silent':after='Changed schedule registry environment validation code. No change to deliberate plaintext set-value acceptance was implemented, and no values were newly rejected.'
        if after and after!=before:
            case['item_text']=after;changes.append({'case_id':case['case_id'],'old_text':before,'new_text':after,'expected_labels_unchanged':True,'reason':'Clarify what the plan or delivered work did or omitted, without changing the anchor requirement or expected semantic answer.'})
    assert changes
    assert [x['case_id'] for x in old['cases']]==[x['case_id'] for x in new['cases']]
    assert all(a['expected']==b['expected'] and a['expected_verdict']==b['expected_verdict'] for a,b in zip(old['cases'],new['cases']))
    target=HERE/f'{aid}-{gate}-oracle-v3.json';prov=HERE/f'{aid}-{gate}-oracle-v3-provenance.json'
    assert not target.exists() and not prov.exists()
    target.write_text(json.dumps(new,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    p={'schema':'plan-anchor/tuning-oracle-provenance/1','predecessor_file':str(old_path),'predecessor_sha256':sha(old),'successor_file':str(target),'successor_sha256':sha(new),'changes':changes,'expected_labels_unchanged':True,'authority_unchanged':True}
    prov.write_text(json.dumps(p,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    print(aid,gate,sha(new),len(changes))
