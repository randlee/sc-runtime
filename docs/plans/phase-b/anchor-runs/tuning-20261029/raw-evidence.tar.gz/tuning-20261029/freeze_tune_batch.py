import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
gate=sys.argv[1]
assert gate in ('planning','development')
diagnostic=json.loads((HERE/'anchor-027-042-diagnostic-probes.json').read_text())
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(x):return hashlib.sha256(canonical(x)).hexdigest()

variants={
 'planning':{
  'relevant':[
   ('Does item.text plan work on the governed activity, component, or artifact named by anchor.statement and anchor.scope? Judge applicability only, including dependencies.','The work touches the governed subject directly or as a clear prerequisite.','The work is independent of the governed subject.','The work area is too vague to determine applicability.'),
   ('Would completing item.text exercise, change, or depend on the subject of anchor.statement? Do not use compliance as evidence of relevance.','The anchor applies to this item.','The anchor does not apply to this item.','The item does not identify enough work to decide applicability.'),
  ],
  'addressed':[
   ('Does item.text expressly include the specific obligation in anchor.statement as a planned step or constraint? A subject mention, silence, or opposing action does not satisfy the obligation.','The required action or constraint is explicitly included.','The item omits the obligation or describes only a conflicting action.','The item gestures at the obligation but does not settle whether it is included.'),
   ('Is the requirement itself carried into the plan item, using equivalent words if needed? Judge its presence independently of contradiction elsewhere.','The item explicitly plans or preserves the required behavior or boundary.','The item is silent, merely topical, or includes only the opposite behavior.','The text might include the requirement but is too indefinite to tell.'),
  ],
  'contradicted':[
   ('Does item.text commit to behavior that cannot coexist with anchor.statement? Silence, topical mention, and an expressly permitted exception are not conflicts.','The item commits to an incompatible behavior or boundary.','No incompatible behavior is proposed.','A possible conflict depends on an unresolved detail.'),
   ('Compare the proposed item with the anchor obligation for an explicit incompatible choice. Treat allowed exceptions as allowed.','A stated plan would violate the anchor.','The item can coexist with the anchor, including when silent.','The item leaves a potentially decisive choice unspecified.'),
  ],
 },
 'development':{
  'relevant':[
   ('Does the delivered work in item.text touch the governed component, behavior, or artifact of anchor.statement, directly or as a dependency? Judge applicability only.','The delivered work touches the governed subject.','The delivered work is unrelated.','The work description is too vague to determine overlap.'),
   ('Would the delivered work exercise, change, or depend on the subject named by the anchor?','The anchor applies to this delivered work.','The anchor does not apply to this delivered work.','The described work leaves applicability uncertain.'),
  ],
  'implemented':[
   ('Does item.text state that delivered work actually performed the specific action or kept the specific boundary required by anchor.statement? A future intention, silence, or topic mention is insufficient.','The delivered work explicitly did or preserved what the anchor requires.','The required work was omitted, deferred, or replaced with an opposing action.','The text mentions the topic without settling whether the requirement was implemented.'),
   ('Is the anchor obligation present in the account of completed work? Judge the implementation claim separately from its evidence.','The account says the required behavior or constraint is in the delivered work.','It says the requirement is absent, future, or only an opposing behavior was delivered.','It is unclear whether the requirement was delivered.'),
  ],
  'violated':[
   ('Does item.text describe delivered behavior that cannot coexist with anchor.statement? Silence is not a violation; allowed exceptions are not violations.','A delivered action or decision conflicts with the anchor.','No conflicting delivered behavior is described.','A potentially conflicting behavior is too unclear to classify.'),
   ('Did the completed work cross a boundary or choose an approach forbidden by the anchor?','The work explicitly violates the required boundary or behavior.','The work can coexist with the anchor.','The description leaves a decisive compatibility detail unresolved.'),
  ],
  'evidenced':[
   ('If item.text claims the anchor was followed, does it cite a checkable path, diff, command result, test, or comparison supporting that claim? A bare assertion is insufficient.','A concrete checkable artifact supports the implementation claim.','No implementation claim is made, or the claim has no checkable support.','Something resembling evidence is named but its support is uncertain.'),
   ('Can a reviewer locate or repeat specific evidence for the claimed compliance in item.text? Judge evidence only, not whether the claim is true.','The claim points to a specific inspectable artifact or executed check.','The claim is bare or absent.','The cited material may be evidence but its relevance is unclear.'),
  ],
 }
}

boundary={
 'ANC-027':'The scheduler stores a job type field but leaves custom application job execution for later.',
 'ANC-028':'The Monty host registry is extended only inside sc-cron; consumers cannot register functions.',
 'ANC-029':'sc_compose_run forwards render and lint but rejects another valid sc-compose subcommand.',
 'ANC-030':'atm_run forwards one ATM command through the shared host registry but rejects other ATM commands.',
 'ANC-031':'Boundary lint scans production manifests but does not inspect Rust imports in release crates.',
 'ANC-032':'The release checklist requires render_template implementation before sc-cron can ship.',
 'ANC-033':'The MVP runner accepts unsigned Monty scripts but still requires a separate manual approval.',
 'ANC-034':'Python and Monty accept the same environment fields, but Monty ignores clear directives.',
 'ANC-035':'Daemon inheritance uses an allow list for API keys but forwards all other ambient values.',
 'ANC-036':'A schedule can set environment values but cannot clear them.',
 'ANC-037':'Schedule updates avoid ambient capture, but creation persists the caller environment.',
 'ANC-038':'The registry allows explicit plaintext nonsecret values but refuses explicit plaintext API-key values.',
 'ANC-039':'A schedule stores opaque references, but no application resolver is called at execution.',
 'ANC-040':'The loader accepts only relative .env paths and rejects absolute paths.',
 'ANC-041':'Configured environment becomes available only when the first hook function starts.',
 'ANC-042':'First release uses one baseline but still mandates v1-v4 unreleased migration steps.',
}
exception={
 'ANC-027':'The scheduler accepts consumer-defined jobs in addition to built-in examples.',
 'ANC-028':'The consumer registers another Monty host function through the extension interface while sc-cron remains unchanged.',
 'ANC-029':'The script invokes an uncommon sc-compose subcommand through the same argument-forwarding host call.',
 'ANC-030':'The script invokes an uncommon ATM CLI subcommand through atm_run in the shared extension interface.',
 'ANC-031':'A benchmark references sc-compose as a dev-only dependency while production crates remain free of sc-compose and ATM imports/dependencies.',
 'ANC-032':'An optional render_template helper remains in an example, while no product or release criterion requires it.',
 'ANC-033':'The MVP may log script provenance, but execution does not require a signature or a separate approval step.',
 'ANC-034':'Python and Monty use different internal adapters but resolve the same explicit schedule environment to the same values.',
 'ANC-035':'A daemon value is inherited only after its variable name appears in the explicit allow list.',
 'ANC-036':'One schedule clears a variable while another schedule explicitly sets it.',
 'ANC-037':'An explicit set value is persisted, while ambient caller and daemon values are not captured.',
 'ANC-038':'The registry deliberately stores a plaintext nonsecret setting supplied by a schedule.',
 'ANC-039':'The application resolver turns an opaque reference into a runtime value without persisting the resolved value.',
 'ANC-040':'A schedule loads values from an authorized absolute-path .env file.',
 'ANC-041':'Monty source reads configured environment at top level before its cron hook is invoked.',
 'ANC-042':'The first release establishes one schema baseline; old unreleased dev schemas have no migration ladder.',
}

for aid in sorted(boundary):
    path=HERE/f'{aid}-{gate}-20261029-request.json'
    req=json.loads(path.read_text())
    a=req['authority']['anchors']['records'][0]
    assert a['id']==aid
    base={role:[{'id':role+'-0','question':q,'origin':'current'}] for role,q in req['current_questions'].items()}
    for role,pairs in variants[gate].items():
        for i,(instructions,yes,no,unclear) in enumerate(pairs,1):
            base[role].append({'id':f'{role}-{i}','question':{'type':'choice','instructions':instructions,'criteria':{'yes':yes,'no':no,'unclear':unclear}},'origin':'candidate'})
    diag={c['kind']:c for c in diagnostic['cases'] if c['anchor_id']==aid}
    p=diag['compliant']['item_text'];n=diag['conflicting']['item_text'];ir=diag['irrelevant']['item_text']
    cases=[]
    raw=[('compliant',p,'yes','yes','no'),('silent',f"Update {a['summary'].lower()} implementation and tests; details will be decided later.",'yes','no','no'),('topical_only',f"Review the {a['summary'].lower()} area and document current behavior.",'yes','no','no'),('conflicting',n,'yes','no','yes'),('irrelevant',ir,'no','no','no'),('boundary',boundary[aid],'yes','no' if a['kind']!='prohibition' else 'no','yes' if a['kind']!='prohibition' else 'yes'),('exception',exception[aid],'yes','yes','no')]
    if gate=='development':
        raw=[('compliant',p+f" Evidence: tests/{aid.lower().replace('-','_')}.rs::compliant passed.",'yes','yes','no'),('asserted',p+' We followed this anchor.','yes','yes','no'),('silent',f"Changed {a['summary'].lower()} implementation; no details of the anchor requirement were recorded.",'yes','no','no'),('topical_only',f"Reviewed {a['summary'].lower()} behavior without describing a change.",'yes','no','no'),('conflicting',n,'yes','no','yes'),('irrelevant',ir,'no','no','no'),('boundary',boundary[aid],'yes','no','yes'),('exception',exception[aid]+f" Evidence: tests/{aid.lower().replace('-','_')}.rs::exception passed.",'yes','yes','no'),('deferred',f"Work on {a['summary'].lower()} was deferred to the next release.",'yes','no','no')]
    for kind,text,rel,comp,conf in raw:
        if gate=='planning':
            expected={'relevant':rel,'addressed':comp,'contradicted':conf}
        else:
            expected={'relevant':rel,'implemented':comp,'violated':conf,'evidenced':'yes' if kind in ('compliant','exception') else 'no'}
        # Prohibitions gate on relevance/conflict; their compliance role is diagnostic only.
        if a['kind']=='prohibition' and kind in ('compliant','exception'):
            expected['addressed' if gate=='planning' else 'implemented']='yes'
        cases.append({'case_id':aid+'-'+gate+'-'+kind,'kind':kind,'item_text':text,'expected':expected,'authority_rationale':f"{a['id']} v{a['version']} {a['statement']}", 'expected_verdict':('not_applicable' if kind=='irrelevant' else 'contradicted' if kind in ('conflicting','boundary') else 'not_addressed' if kind in ('silent','topical_only','deferred') and a['kind']!='prohibition' else 'asserted_only' if kind=='asserted' and gate=='development' else 'satisfied')})
    oracle={'schema':'plan-anchor/tuning-oracle/2','gate':gate,'correlation_id':req['correlation_id'],'authority':{'intent_id':req['authority']['intent']['id'],'intent_version':req['authority']['intent']['version'],'intent_sha256':req['authority']['intent']['sha256'],'anchor_id':aid,'anchor_version':a['version'],'anchor_record_sha256':sha(a)},'cases':cases,'repeat_count':req['repeat_count'],'frozen_before_live':True}
    out=HERE/f'{aid}-{gate}-oracle.json'; cand=HERE/f'{aid}-{gate}-candidates.json'
    assert not out.exists() and not cand.exists()
    out.write_text(json.dumps(oracle,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    cand.write_text(json.dumps(base,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    print(aid,gate,sha(oracle),sha(base),len(cases))
