import concurrent.futures
import hashlib
import json
import os
import ssl
from pathlib import Path
import sys
import time
import urllib.error
import urllib.request
import certifi

HERE = Path(__file__).resolve().parent
V3 = '--v3' in sys.argv
request = json.loads((HERE / ('testability-v3-request.json' if V3 else 'testability-request.json')).read_text())
candidates = json.loads((HERE / 'testability-candidates.json').read_text())
if V3:
    corpus = json.loads(Path(request['calibration_corpus']['path']).read_text())
    assert hashlib.sha256(json.dumps(corpus,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest() == request['calibration_corpus']['sha256']
    oracle = {'schema': 'plan-anchor/testability-oracle/2', 'corpus_sha256': request['calibration_corpus']['sha256'], 'roles': ['single_constraint', 'observable', 'faithful', 'scoped', 'self_contained'], 'cases': [{'case_id': c['case_id'], 'state': c['state'], 'expected': {'single_constraint': c['expected']['atomicity'], **{k:v for k,v in c['expected'].items() if k != 'atomicity'}}, 'rationale': c['rationale']} for c in corpus['semantic_cases']], 'lint_cases': corpus['requirement_form_lint_cases'], 'dedupe_pairs': corpus['dedupe_pairs']}
    frozen_oracle_path=HERE/'testability-v3-oracle.json'
    if not frozen_oracle_path.exists():frozen_oracle_path.write_text(json.dumps(oracle,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    else:assert json.loads(frozen_oracle_path.read_text())==oracle
else:
    oracle = json.loads((HERE / 'testability-oracle.json').read_text())
sys.path.insert(0, str(Path(request['runtime']['script']).parent))
import jev_judge as jev
from result import Err

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()

def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()

assert digest(oracle['cases'])
assert hashlib.sha256(Path(request['runtime']['script']).read_bytes()).hexdigest() == request['runtime']['sha256']
assert hashlib.sha256(Path(request['runtime']['contract_script']).read_bytes()).hexdigest() == request['runtime']['contract_sha256']
assert digest(candidates) == '5bc529ac1b250611a91c8c4a2be4273cdddaef2484f98d6c0617e2972af16891'
if not V3: assert digest(oracle) == '237d8ed032402da1566e398732e0f98441988b913a41e6320da6189939a516e3'

class Args:
    repository_root = request['runtime']['workspace']

preflight = jev.remote_preflight(Args(), 'The frozen testability calibration cases')
if isinstance(preflight, Err):
    print(json.dumps({'preflight_error': preflight.error.to_json()['error']}))
    sys.exit(2)
key = preflight.value

run_dir = HERE / ('testability-v3-jev-runs' if V3 else 'testability-jev-runs')
run_dir.mkdir(exist_ok=True)
SELECTED = '--selected' in sys.argv
manifest_path = HERE / ('testability-v3-selected-requests.json' if SELECTED else ('testability-v3-requests.json' if V3 else 'testability-requests.json'))
if not manifest_path.exists():
    manifest = []
    for bundle_index in ((3,) if SELECTED else range(3)):
        questions = {role: candidates[role][(1 if role == 'scoped' else 0) if SELECTED else bundle_index]['question'] for role in oracle['roles']}
        for case in oracle['cases']:
            body = {'model': jev.DEFAULT_MODEL, 'questions': questions, 'state': case['state']}
            manifest.append({'correlation_id': f"{request['correlation_id']}-b{bundle_index}-{case['case_id']}", 'bundle': bundle_index, 'case_id': case['case_id'], 'body': body, 'body_sha256': digest(body)})
    manifest_path.write_text(json.dumps(manifest, sort_keys=True, indent=2, ensure_ascii=False) + '\n')
else:
    manifest = json.loads(manifest_path.read_text())

def call(job):
    body = job['body']
    raw_path = run_dir / (job['correlation_id'] + f"-r{job['repeat']}" + ('' if V3 else '-e2') + '.json')
    if raw_path.exists():
        return json.loads(raw_path.read_text())
    payload = canonical(body)
    assert hashlib.sha256(payload).hexdigest() == job['body_sha256']
    record = {'correlation_id': job['correlation_id'], 'repeat': job['repeat'], 'request_sha256': job['body_sha256'], 'request': body, 'attempts': []}
    for attempt in (1, 2):
        req = urllib.request.Request(jev.JEV_URL, data=payload, method='POST', headers={'Authorization': f'Bearer {key}', 'Content-Type': 'application/json', 'User-Agent': 'plan-anchoring/jev_judge'})
        started = time.monotonic()
        try:
            with urllib.request.urlopen(req, timeout=45, context=ssl.create_default_context(cafile=certifi.where())) as resp:
                response_bytes = resp.read(jev.MAX_RESPONSE_BYTES + 1)
            if len(response_bytes) > jev.MAX_RESPONSE_BYTES:
                raise ValueError('response exceeds limit')
            parsed = json.loads(response_bytes)
            checked = jev.validate_response(parsed, body['questions'])
            if isinstance(checked, Err):
                raise ValueError(checked.error.code + ': ' + checked.error.message)
            record['attempts'].append({'attempt': attempt, 'duration_ms': round((time.monotonic()-started)*1000), 'raw_response_utf8': response_bytes.decode('utf-8'), 'raw_response_sha256': hashlib.sha256(response_bytes).hexdigest(), 'response': parsed, 'run_id': parsed.get('id') or parsed.get('run_id') or job['correlation_id'] + f"-r{job['repeat']}-a{attempt}"})
            record['success'] = True
            break
        except urllib.error.HTTPError as exc:
            err = {'code': 'EXECUTION.JEV', 'http_status': exc.code, 'message': 'Jev HTTP error; body withheld'}
        except (urllib.error.URLError, OSError, ValueError, UnicodeError) as exc:
            err = {'code': 'EXECUTION.JEV', 'message': type(exc).__name__ + ': ' + str(exc)}
        record['attempts'].append({'attempt': attempt, 'duration_ms': round((time.monotonic()-started)*1000), 'error': err})
        if attempt == 2:
            record['success'] = False
    raw_path.write_text(json.dumps(record, sort_keys=True, indent=2, ensure_ascii=False) + '\n')
    return record

jobs = [{**item, 'repeat': rep} for item in manifest for rep in (1, 2)]
if '--third' in sys.argv:
    third_jobs = []
    for item in manifest:
        first = json.loads((run_dir / (item['correlation_id'] + '-r1' + ('' if V3 else '-e2') + '.json')).read_text())
        second = json.loads((run_dir / (item['correlation_id'] + '-r2' + ('' if V3 else '-e2') + '.json')).read_text())
        a = first['attempts'][-1]['response']['answers']
        b = second['attempts'][-1]['response']['answers']
        if any(a[role]['choice'] != b[role]['choice'] for role in oracle['roles']):
            third_jobs.append({**item, 'repeat': 3})
    jobs = third_jobs
if '--pilot' in sys.argv:
    jobs = jobs[:1]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    futures = [pool.submit(call, job) for job in jobs]
    results = [future.result() for future in concurrent.futures.as_completed(futures)]
print(json.dumps({'requests': len(results), 'successes': sum(r['success'] for r in results), 'failures': [r['correlation_id'] + '-r' + str(r['repeat']) for r in results if not r['success']], 'retries': sum(len(r['attempts'])-1 for r in results)}))
