import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
rejected={'planning':[27,29,32,33,37,38,40],'development':[28,29,30,31,32,33,34,35,36,37,38,40,41,42]}
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(x):return hashlib.sha256(canonical(x)).hexdigest()

planning_replacements={
 'ANC-027':{'boundary':'sc-cron will accept only sc-compose-specific job payloads and will reject every application-defined job type.'},
 'ANC-029':{'exception':'sc_compose_run will forward arbitrary sc-compose command and subcommand argv without an allowlist, including an uncommon subcommand.'},
 'ANC-032':{'exception':'The product contract explicitly states render_template is not required; an optional example may still include it.'},
 'ANC-033':{'exception':'The MVP execution contract explicitly requires neither script signatures nor a separate approval mechanism; provenance logging is optional.'},
 'ANC-037':{'silent':'The schedule-write implementation will be changed, but this plan makes no commitment about capturing ambient environment values.'},
 'ANC-038':{'silent':'Schedule environment storage will be changed, but this plan says nothing about accepting deliberately supplied plaintext values.','boundary':'The registry will accept deliberate plaintext nonsecret values but reject every deliberately supplied secret value solely because it is plaintext.'},
 'ANC-040':{'silent':'The environment-source loader will be changed, but the plan makes no commitment to accepting absolute .env paths.'},
}

for gate,ids in rejected.items():
 for i in ids:
    aid=f'ANC-{i:03d}'
    old_path=HERE/f'{aid}-{gate}-oracle.json'
    old=json.loads(old_path.read_text())
    old_req=json.loads((HERE/f'{aid}-{gate}-20261029-request.json').read_text())
    new=json.loads(json.dumps(old))
    changes=[]
    for case in new['cases']:
        kind=case['kind'];text=case['item_text'];replacement=None
        if gate=='planning':
            replacement=planning_replacements.get(aid,{}).get(kind)
            if kind=='topical_only':replacement=f"Inventory {old_req['authority']['anchors']['records'][0]['summary'].lower()} behavior; make no plan decision about the anchor's specific obligation."
        else:
            summary=old_req['authority']['anchors']['records'][0]['summary'].lower()
            if kind=='compliant':replacement=f"Delivered the required behavior: {text.split(' Evidence:')[0]} Evidence: tests/{aid.lower().replace('-','_')}.rs::compliant asserts the behavior and passed."
            elif kind=='asserted':replacement=f"Delivered the required behavior: {text.replace(' We followed this anchor.','')} We followed this anchor."
            elif kind=='silent':replacement=f"A code refactor touched {summary}; this delivery note makes no claim about whether the anchor's specific behavior or boundary was implemented."
            elif kind=='topical_only':replacement=f"Reviewed code related to {summary}; no behavior satisfying or conflicting with the anchor is claimed or described."
            elif kind=='conflicting':replacement=f"Delivered this incompatible behavior: {text}"
            elif kind=='boundary':replacement=f"Delivered this partial or incompatible behavior: {text}"
            elif kind=='exception':replacement=f"Delivered this allowed case: {text.split(' Evidence:')[0]} Evidence: tests/{aid.lower().replace('-','_')}.rs::exception asserts the behavior and passed."
            elif kind=='deferred':
                if aid=='ANC-030':replacement='Only optional ATM example documentation was deferred; the delivery note makes no claim about whether the required atm_run integration was implemented.'
                elif aid=='ANC-042':replacement='No first binary has been released; schedule-schema baseline work was deferred and no migration decision was implemented.'
                else:replacement=f"Work on {summary} was deferred; no compliant or incompatible behavior was delivered in this change."
            if aid=='ANC-038' and kind=='boundary':replacement='Delivered a registry that persists explicit plaintext nonsecret values but rejects every deliberately supplied secret value solely because it is plaintext.'
            if aid=='ANC-033' and kind=='conflicting':replacement='Delivered an MVP runner that requires a valid script signature and a separate human approval before executing every Monty script.'
            if aid=='ANC-033' and kind=='boundary':replacement='Delivered an MVP runner that accepts unsigned Monty scripts but still requires separate manual approval before execution.'
        if replacement and replacement!=text:
            case['item_text']=replacement
            changes.append({'case_id':case['case_id'],'old_text':text,'new_text':replacement,'expected_labels_unchanged':True,'reason':'Make the asserted completed/planned behavior and its anchor boundary explicit; preserve the approved requirement and oracle label.'})
    assert changes
    # The versioned successor preserves case identities and expected labels.
    assert [x['case_id'] for x in old['cases']]==[x['case_id'] for x in new['cases']]
    assert all(a['expected']==b['expected'] and a['expected_verdict']==b['expected_verdict'] for a,b in zip(old['cases'],new['cases']))
    target=HERE/f'{aid}-{gate}-oracle-v2.json';prov=HERE/f'{aid}-{gate}-oracle-v2-provenance.json'
    assert not target.exists() and not prov.exists()
    target.write_text(json.dumps(new,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    p={'schema':'plan-anchor/tuning-oracle-provenance/1','predecessor_file':str(old_path),'predecessor_sha256':sha(old),'successor_file':str(target),'successor_sha256':sha(new),'changes':changes,'expected_labels_unchanged':True,'authority_unchanged':True}
    prov.write_text(json.dumps(p,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    print(aid,gate,sha(new),len(changes))
