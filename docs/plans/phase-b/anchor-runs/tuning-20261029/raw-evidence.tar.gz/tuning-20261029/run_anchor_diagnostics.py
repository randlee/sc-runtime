import concurrent.futures
import hashlib
import json
from pathlib import Path
import ssl
import sys
import urllib.error
import urllib.request
import certifi

HERE=Path(__file__).resolve().parent
req=json.loads((HERE/'testability-v3-request.json').read_text())
sealed=json.loads((HERE/'testability-v3-result.json').read_text())['data']['rubric_question_set']
assert sealed and sealed['digest']
anchors=json.loads((HERE.parents[1]/'anchors.json').read_text())['anchors']
anchors=[a for a in anchors if a.get('id','').startswith('ANC-') and 27<=int(a['id'][4:])<=42]
assert len(anchors)==16
sys.path.insert(0,str(Path(req['runtime']['script']).parent))
import jev_judge as jev
from result import Err

def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(x):return hashlib.sha256(canonical(x)).hexdigest()
manifest_path=HERE/'anchor-027-042-testability-requests.json'
if not manifest_path.exists():
    manifest=[]
    for anchor in anchors:
        body={'model':jev.DEFAULT_MODEL,'questions':sealed['questions'],'state':{'anchor':{'statement':anchor['statement'],'quote':anchor['quote'],'scope':anchor['scope']}}}
        manifest.append({'correlation_id':'anc027-042-testability-'+anchor['id'],'anchor_id':anchor['id'],'anchor_version':anchor['version'],'body':body,'body_sha256':sha(body)})
    manifest_path.write_text(json.dumps(manifest,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
else:manifest=json.loads(manifest_path.read_text())
assert len(manifest)==16
class Args:repository_root=req['runtime']['workspace']
preflight=jev.remote_preflight(Args(),'Approved anchor testability diagnostic cases')
if isinstance(preflight,Err):print(json.dumps({'error':preflight.error.to_json()['error']}));sys.exit(2)
key=preflight.value
out=HERE/'anchor-027-042-testability-runs';out.mkdir(exist_ok=True)

def call(job):
    path=out/(job['correlation_id']+f"-r{job['repeat']}.json")
    if path.exists():return json.loads(path.read_text())
    payload=canonical(job['body']);assert hashlib.sha256(payload).hexdigest()==job['body_sha256']
    record={'correlation_id':job['correlation_id'],'repeat':job['repeat'],'request_sha256':job['body_sha256'],'request':job['body'],'attempts':[]}
    for attempt in (1,2):
        request=urllib.request.Request(jev.JEV_URL,data=payload,method='POST',headers={'Authorization':f'Bearer {key}','Content-Type':'application/json','User-Agent':'plan-anchoring/jev_judge'})
        try:
            with urllib.request.urlopen(request,timeout=45,context=ssl.create_default_context(cafile=certifi.where())) as response:raw=response.read(jev.MAX_RESPONSE_BYTES+1)
            if len(raw)>jev.MAX_RESPONSE_BYTES:raise ValueError('response exceeds limit')
            parsed=json.loads(raw)
            checked=jev.validate_response(parsed,job['body']['questions'])
            if isinstance(checked,Err):raise ValueError(checked.error.code+': '+checked.error.message)
            record['attempts'].append({'attempt':attempt,'raw_response_utf8':raw.decode(),'raw_response_sha256':hashlib.sha256(raw).hexdigest(),'response':parsed,'run_id':parsed.get('id') or parsed.get('run_id') or job['correlation_id']+f"-r{job['repeat']}-a{attempt}"})
            record['success']=True;break
        except urllib.error.HTTPError as exc:record['attempts'].append({'attempt':attempt,'error':{'code':'EXECUTION.JEV','message':f'Jev HTTP {exc.code}; body withheld'}})
        except (urllib.error.URLError,OSError,ValueError,UnicodeError) as exc:record['attempts'].append({'attempt':attempt,'error':{'code':'EXECUTION.JEV','message':type(exc).__name__+': '+str(exc)}})
        if attempt==2:record['success']=False
    path.write_text(json.dumps(record,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    return record

jobs=[{**j,'repeat':r} for j in manifest for r in (1,2)]
if '--third' in sys.argv:
    jobs=[]
    for j in manifest:
        a=json.loads((out/(j['correlation_id']+'-r1.json')).read_text())['attempts'][-1]['response']['answers']
        b=json.loads((out/(j['correlation_id']+'-r2.json')).read_text())['attempts'][-1]['response']['answers']
        if any(a[k]['choice']!=b[k]['choice'] for k in sealed['questions']):jobs.append({**j,'repeat':3})
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(call,jobs))
print(json.dumps({'requests':len(results),'successes':sum(r['success'] for r in results),'failures':[r['correlation_id'] for r in results if not r['success']]}))
