import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
request=json.loads((HERE/'testability-request.json').read_text())
source=Path(request['calibration_corpus']['path'])
original_bytes=source.read_bytes()
original=json.loads(original_bytes)
def canonical(x):
    return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(x):
    return hashlib.sha256(canonical(x)).hexdigest()
assert sha(original)==request['calibration_corpus']['sha256']
revised=json.loads(json.dumps(original))
edits={
 'a0-02-valid-prohibition':('The request logger must never write raw authentication tokens to stdout or stderr.','Raw authentication tokens must never appear in request logs or error output.','Preserves the quoted request-log and error-output surfaces without substituting all stdout/stderr output.'),
 'a0-04-global-scope':('Every CLI subcommand must emit a JSON object on stdout.','Every CLI subcommand must emit JSON on stdout.','Preserves the quoted JSON value domain without restricting output to objects.'),
}
changes=[]
for case in revised['semantic_cases']:
    if case['case_id'] not in edits:continue
    old,new,reason=edits[case['case_id']]
    assert case['state']['anchor']['statement']==old
    case['state']['anchor']['statement']=new
    case['rationale']+=' '+reason
    changes.append({'case_id':case['case_id'],'old_statement':old,'new_statement':new,'rationale':reason,'expected_labels_unchanged':True})
assert len(changes)==2
assert all(revised['semantic_cases'][i]['expected']==original['semantic_cases'][i]['expected'] for i in range(len(original['semantic_cases'])))
target=HERE/'testability-calibration.v3.json'
manifest=HERE/'testability-calibration.v3-provenance.json'
assert not target.exists() and not manifest.exists()
target.write_text(json.dumps(revised,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
provenance={'schema':'plan-anchor/calibration-corpus-provenance/1','predecessor_descriptor':request['calibration_corpus'],'predecessor_canonical_sha256':sha(original),'predecessor_file_sha256':hashlib.sha256(original_bytes).hexdigest(),'successor_descriptor':{'case_count':len(revised['semantic_cases']),'frozen_before_live':True,'path':str(target),'schema':'plan-anchor/testability-calibration/2','sha256':sha(revised),'version':3},'successor_file_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'changes':changes,'other_semantic_cases_unchanged':True,'lint_and_dedupe_cases_unchanged':True}
manifest.write_text(json.dumps(provenance,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(provenance['successor_descriptor'],sort_keys=True))
