import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
records=json.loads((ROOT/'anchors.json').read_text())['anchors']
relevant={a['id']:a for a in records if a.get('id','').startswith('ANC-') and 27<=int(a['id'][4:])<=42}
assert len(relevant)==16
probes={
 'ANC-027':('The sc-cron scheduler accepts application-defined job payloads without a tool-specific registry.','Make sc-cron accept only built-in sc-compose job types.','Adjust an unrelated CSS theme token.'),
 'ANC-028':('Expose a consumer registration hook; a custom application Monty host function runs without patching sc-cron.','Add new Monty host calls only by editing sc-cron source.','Adjust an unrelated CSS theme token.'),
 'ANC-029':('sc_compose_run forwards arbitrary sc-compose command and subcommand arguments to the external executable.','Limit sc_compose_run to render and reject other sc-compose commands.','Adjust an unrelated CSS theme token.'),
 'ANC-030':('atm_run is registered through the same host extension interface as sc_compose_run and forwards any ATM CLI command or subcommand.','Implement atm_run as a hardcoded single-command wrapper outside the shared host extension interface.','Adjust an unrelated CSS theme token.'),
 'ANC-031':('Boundary lint rejects sc-compose and ATM dependencies or Rust imports in release crates while test and benchmark references are allowed.','Add an ATM crate dependency to a production release crate and exempt it from boundary lint.','Adjust an unrelated CSS theme token.'),
 'ANC-032':('Treat render_template as an optional example, with no release acceptance criterion requiring it.','Make render_template mandatory for sc-cron release acceptance.','Adjust an unrelated CSS theme token.'),
 'ANC-033':('Run application-supplied Monty source in MVP without a signature or separate approval gate.','Require each MVP Monty script to be signed and separately approved before execution.','Adjust an unrelated CSS theme token.'),
 'ANC-034':('Resolve the same explicit schedule environment specification identically for Python and Monty hooks.','Apply set and clear directives to Python hooks but ignore them for Monty hooks.','Adjust an unrelated CSS theme token.'),
 'ANC-035':('Only daemon environment names on the configured allow list are inherited by hook processes.','Pass the full daemon environment into each hook process by default.','Adjust an unrelated CSS theme token.'),
 'ANC-036':('Each schedule can set a value or clear a named environment variable independently.','Schedules cannot clear an inherited environment variable.','Adjust an unrelated CSS theme token.'),
 'ANC-037':('Schedule writes persist only explicitly supplied environment values, never ambient caller or daemon values.','On schedule creation, serialize the daemon process environment into the schedule row by default.','Adjust an unrelated CSS theme token.'),
 'ANC-038':('Permit a deliberate plaintext set value in the persisted schedule registry.','Reject every plaintext environment set value, including deliberate nonsensitive configuration.','Adjust an unrelated CSS theme token.'),
 'ANC-039':('Resolve opaque schedule environment references through a consumer-supplied resolver at execution time.','Store an opaque reference string as the hook value without invoking the application resolver.','Adjust an unrelated CSS theme token.'),
 'ANC-040':('Load a schedule environment source from an absolute .env file path.','Accept only a relative .env path and resolve it against the daemon working directory.','Adjust an unrelated CSS theme token.'),
 'ANC-041':('A top-level Monty source expression reads the configured environment before cron_tick or cron_stop runs.','Inject configured environment variables only after Monty source initialization finishes.','Adjust an unrelated CSS theme token.'),
 'ANC-042':('Ship the first schedule schema as one baseline without requiring migration from unreleased development schemas.','Require users of the first binary release to migrate sequentially through unreleased schema v1, v2, v3, and v4.','Adjust an unrelated CSS theme token.'),
}
notes={
 'ANC-030':'The literal quote is an agreement without the preceding proposal. Approved intent v2 supplies the normative ATM requirement; add an immutable source reference to the agreed proposal as provenance if available, without changing the approved statement.',
 'ANC-031':'Production exclusion includes dependencies and Rust imports, while test and benchmark references remain permitted. The exception is part of the same boundary invariant; do not extend the ban to tests.',
 'ANC-032':'The anchor removes a product requirement. It does not prohibit an optional render_template helper or require deleting an existing example.',
 'ANC-041':'The approved intent explicitly permits reading configured environment during Monty source initialization. The quote uses set-before-run language; do not infer a requirement for Monty source to mutate its own environment.'
}
cases=[]
for aid in sorted(relevant):
    record=relevant[aid]
    for kind,text in zip(('compliant','conflicting','irrelevant'),probes[aid]):
        expected={'relevant':'yes','addressed':'yes','contradicted':'no'} if kind=='compliant' else ({'relevant':'yes','addressed':'no','contradicted':'yes'} if kind=='conflicting' else {'relevant':'no','addressed':'no','contradicted':'no'})
        cases.append({'case_id':aid+'-'+kind,'anchor_id':aid,'kind':kind,'anchor_statement':record['statement'],'anchor_quote':record['quote'],'anchor_version':record['version'],'item_text':text,'planning_expected':expected,'authority_basis':'approved Phase B continuation intent v2 and locked '+aid,'diagnostic_only':True})
out={'schema':'plan-anchor/independent-anchor-diagnostics/1','intent_sha256':'357963619d20fa0043039aa18fa2539526e6a235e7481a41fdf8e58b52ef4df1','anchor_count':len(relevant),'cases':cases,'notes':notes,'limitations':'These are frozen read-only diagnostic probes, not a formal tuned oracle or sealed production question set. Formal tune requests must supply each exact locked anchor record and canonical history.'}
target=HERE/'anchor-027-042-diagnostic-probes.json'
assert not target.exists()
target.write_text(json.dumps(out,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'path':str(target),'sha256':hashlib.sha256(json.dumps(out,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest(),'cases':len(cases)}))
