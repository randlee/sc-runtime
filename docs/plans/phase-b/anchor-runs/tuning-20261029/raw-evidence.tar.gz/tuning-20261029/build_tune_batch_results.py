import hashlib
import json
import math
from pathlib import Path
import statistics
import sys
import time

HERE=Path(__file__).resolve().parent
gate=sys.argv[1];assert gate in ('planning','development')
V2='--v2' in sys.argv
V3='--v3' in sys.argv
FIXTURES='--fixtures' in sys.argv
FIXTURES_V5='--fixtures-v5' in sys.argv
v2_ids={'planning':{27,29,32,33,37,38,40},'development':{28,29,30,31,32,33,34,35,36,37,38,40,41,42}}
v3_ids={'planning':{27,32,33,37,38},'development':{29,30,31,32,33,34,35,36,37,38,40,41,42}}
sys.path.insert(0,'/Volumes/Extreme Pro/github/sc-runtime-worktrees/codex/install-plan-anchoring/.codex/skills/plan-anchoring/scripts')
import jev_judge as jev
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(x):return hashlib.sha256(canonical(x)).hexdigest()
roles={'relevance':'relevant','compliance':'addressed' if gate=='planning' else 'implemented','conflict':'contradicted' if gate=='planning' else 'violated'}
if gate=='development':roles['evidence']='evidenced'
run_dir=HERE/(f'{gate}-tune-fixtures-v5-jev-runs' if FIXTURES_V5 else f'{gate}-tune-fixtures-v4-jev-runs' if FIXTURES else f'{gate}-tune-v3-jev-runs' if V3 else f'{gate}-tune-v2-jev-runs' if V2 else f'{gate}-tune-jev-runs')

for i in range(27,43):
    if FIXTURES_V5 and not (gate=='development' and i in (31,32)):continue
    if V2 and i not in v2_ids[gate]:continue
    if V3 and i not in v3_ids[gate]:continue
    aid=f'ANC-{i:03d}'
    req=json.loads((HERE/(f'{aid}-{gate}-fixtures-v5-20261029-request.json' if FIXTURES_V5 else f'{aid}-{gate}-fixtures-v4-20261029-request.json' if FIXTURES else f'{aid}-{gate}-v3-20261029-request.json' if V3 else f'{aid}-{gate}-v2-20261029-request.json' if V2 else f'{aid}-{gate}-20261029-request.json')).read_text())
    oracle_path=HERE/(f'{aid}-{gate}-fixtures-v5-oracle.json' if FIXTURES_V5 else f'{aid}-{gate}-fixtures-v4-oracle.json' if FIXTURES else f'{aid}-{gate}-oracle-v3-final.json' if V3 and aid=='ANC-038' and gate=='planning' else f'{aid}-{gate}-oracle-v3.json' if V3 else f'{aid}-{gate}-oracle-v2.json' if V2 else f'{aid}-{gate}-oracle.json')
    candidate_path=HERE/(f'{aid}-{gate}-fixtures-v4-candidates.json' if FIXTURES_V5 or FIXTURES else f'{aid}-{gate}-candidates-v3.json' if V3 and (HERE/f'{aid}-{gate}-candidates-v3.json').exists() else f'{aid}-{gate}-candidates-v2.json' if (V2 or V3) and (HERE/f'{aid}-{gate}-candidates-v2.json').exists() else f'{aid}-{gate}-candidates.json')
    manifest_path=HERE/(f'{aid}-{gate}-fixtures-v5-jev-requests.json' if FIXTURES_V5 else f'{aid}-{gate}-fixtures-v4-jev-requests.json' if FIXTURES else f'{aid}-{gate}-jev-requests-v3.json' if V3 else f'{aid}-{gate}-jev-requests-v2.json' if V2 else f'{aid}-{gate}-jev-requests.json')
    oracle=json.loads(oracle_path.read_text())
    candidates=json.loads(candidate_path.read_text())
    manifest=json.loads(manifest_path.read_text())
    kind=req['authority']['anchors']['records'][0]['kind']
    rows=[];by_bundle=[]
    all_files=[];all_run_ids=[];all_retries=0
    for b in range(len(next(iter(candidates.values())))):
        score={'exact_role_cells':0,'total_role_cells':len(oracle['cases'])*len(candidates),'exact_semantic_verdicts':0,'total_semantic_verdicts':len(oracle['cases']),'stable_cases':0,'total_cases':len(oracle['cases']),'regressions':0}
        confidences=[];bundle_req_hashes=[];bundle_resp_hashes=[];bundle_run_ids=[];bad=[]
        for case in oracle['cases']:
            cid=req['correlation_id']+f'-b{b}-'+case['case_id']
            paths=[run_dir/f'{cid}-r{rep}.json' for rep in (1,2,3)]
            records=[json.loads(p.read_text()) for p in paths if p.exists()]
            assert len(records)>=2 and all(r['success'] for r in records)
            answers=[r['attempts'][-1]['response']['answers'] for r in records]
            first_disagreement=any(answers[0][role]['choice']!=answers[1][role]['choice'] for role in candidates)
            assert (len(records)==3)==first_disagreement
            pair_stable=not first_disagreement
            score['stable_cases']+=int(pair_stable)
            verdicts=[jev.decide(a,roles,0.0,kind)[0] for a in answers]
            verdict_exact=verdicts[0]==verdicts[1]==case['expected_verdict']
            score['exact_semantic_verdicts']+=int(verdict_exact)
            for role,expected in case['expected'].items():
                values=[a[role] for a in answers]
                exact=values[0]['choice']==values[1]['choice']==expected
                score['exact_role_cells']+=int(exact)
                confidences.append(min(values[0]['confidence'],values[1]['confidence']))
                row={'case_id':case['case_id'],'kind':case['kind'],'bundle':b,'candidate_id':f'{role}-{b}','role':role,'expected':expected,'observed':[{'choice':x['choice'],'confidence':x['confidence']} for x in values],'exact':exact,'stable_first_pair':values[0]['choice']==values[1]['choice'],'expected_verdict':case['expected_verdict'],'observed_verdicts':verdicts,'verdict_exact':verdict_exact,'oracle_rationale':case['authority_rationale'],'raw_files':[str(p) for p in paths if p.exists()]}
                rows.append(row)
                if not exact:bad.append({'case_id':case['case_id'],'role':role,'expected':expected,'observed':[x['choice'] for x in values]})
            for rec in records:
                item=rec['attempts'][-1]
                bundle_req_hashes.append(rec['request_sha256']);bundle_resp_hashes.append(item['raw_response_sha256']);bundle_run_ids.append(item['run_id']);all_run_ids.append(item['run_id'])
                all_retries+=len(rec['attempts'])-1
            all_files.extend(p for p in paths if p.exists())
        conf_sorted=sorted(confidences)
        p10=conf_sorted[max(0,math.ceil(0.1*len(conf_sorted))-1)]
        conf={'threshold':req['confidence_reference_threshold'],'cells_at_or_above_threshold':sum(x>=req['confidence_reference_threshold'] for x in confidences),'total_cells':len(confidences),'minimum':round(min(confidences),6),'p10':round(p10,6),'median':round(statistics.median(confidences),6),'mean':round(statistics.mean(confidences),6)}
        by_bundle.append({'bundle':b,'score':score,'confidence':conf,'bad':bad,'request_hashes':bundle_req_hashes,'response_hashes':bundle_resp_hashes,'run_ids':bundle_run_ids,'question_set':{role:candidates[role][b]['question'] for role in candidates},'complexity':sum(len(json.dumps(candidates[role][b]['question'])) for role in candidates)})
    baseline=by_bundle[0]
    for bundle in by_bundle:
        b=bundle['bundle'];regress=0
        for case in oracle['cases']:
            for role in candidates:
                base=next(r for r in rows if r['bundle']==0 and r['case_id']==case['case_id'] and r['role']==role)
                cur=next(r for r in rows if r['bundle']==b and r['case_id']==case['case_id'] and r['role']==role)
                regress+=base['exact'] and not cur['exact']
        bundle['score']['regressions']=regress
        s=bundle['score']
        bundle['semantic_accepted']=s['exact_role_cells']==s['total_role_cells'] and s['exact_semantic_verdicts']==s['total_semantic_verdicts'] and s['stable_cases']==s['total_cases'] and regress==0
    ranked=sorted(by_bundle,key=lambda x:(-int(x['semantic_accepted']),-x['score']['exact_role_cells'],-x['score']['exact_semantic_verdicts'],-x['score']['stable_cases'],x['score']['regressions'],-x['confidence']['cells_at_or_above_threshold'],-x['confidence']['mean'],x['complexity'],x['bundle']))
    selected=ranked[0];accepted=selected['semantic_accepted']
    rankings=[{'candidate_id':f'bundle-{x["bundle"]}','rank':j+1,'semantic_accepted':x['semantic_accepted'],'semantic_score':x['score'],'confidence_diagnostics':x['confidence'],'complexity_chars':x['complexity'],'rejection_reasons':x['bad']} for j,x in enumerate(ranked)]
    questions=selected['question_set'];sealed={'questions':questions,'digest':sha({'questions':questions})} if accepted else None
    before=req['tuning_history'];assert len(before['events'])>=1 if (FIXTURES or FIXTURES_V5) else len(before['events'])==(2 if V3 else 1 if V2 else 0)
    score=selected['score'];confidence=selected['confidence']
    event={'event_index':len(before['events'])+1,'previous_event_sha256':sha(before['events'][-1]) if before['events'] else None,'event':'question_set_sealed' if accepted else 'question_set_rejected','protocol_version':req['tournament_protocol_version'],'authority':oracle['authority'],'oracle':{'sha256':sha(oracle),'case_ids':[c['case_id'] for c in oracle['cases']],'case_count':len(oracle['cases']),'repeat_count':req['repeat_count']},'candidate':{'candidate_id':f'bundle-{selected["bundle"]}','question_sha256':sha({'questions':questions})},'evidence':{'canonical_request_sha256':selected['request_hashes'],'raw_response_sha256':selected['response_hashes'],'run_ids':selected['run_ids']},'score':{**score,'confidence':confidence},'decision':{'status':'sealed' if accepted else 'rejected','question_set_sha256':sealed['digest'] if accepted else None,'reason_code':'TOURNAMENT.EXACT' if accepted else 'TOURNAMENT.SEMANTIC_REJECTED'},'supersedes':{'protocol_version':before['events'][-1]['protocol_version'],'decision_sha256':sha(before['events'][-1]['decision'])} if before['events'] else None}
    after={**before,'events':before['events']+[event]}
    explanation=('All required role cells and semantic verdicts are exact and repeat-stable on the frozen oracle.' if accepted else f"No candidate bundle was exact and repeat-stable on the frozen oracle. Best bundle {selected['bundle']} has {score['exact_role_cells']}/{score['total_role_cells']} exact role cells and {score['exact_semantic_verdicts']}/{score['total_semantic_verdicts']} exact verdicts. Inspect named mismatches before changing an instrument or versioning a probe.")
    evidence={'oracle_file':str(oracle_path),'oracle_sha256':sha(oracle),'candidate_file':str(candidate_path),'candidate_sha256':sha(candidates),'request_manifest_file':str(manifest_path),'request_manifest_sha256':sha(manifest),'raw_response_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(all_files))},'selected_bundle':selected['bundle'],'selected_bad_cells':selected['bad'],'reuse_bindings_file':str(HERE/f'{gate}-fixtures-v5-reuse-bindings.json') if FIXTURES_V5 else str(HERE/f'{gate}-fixtures-v4-reuse-bindings.json') if FIXTURES else None}
    data={'operation':'tune','gate':gate,'accepted':accepted,'tournament_protocol_version':req['tournament_protocol_version'],'production_confidence_threshold':req['production_confidence_threshold'],'confidence_reference_threshold':req['confidence_reference_threshold'],'semantic_score':score,'confidence_diagnostics':confidence,'tuning_history_before_sha256':sha(before),'tuning_history_after':after,'tuning_history_after_sha256':sha(after),'production_semantics_unchanged':True,'authority_citations':[f"{oracle['authority']['intent_id']} v{oracle['authority']['intent_version']}",f"{aid} v{oracle['authority']['anchor_version']}"],'oracle_sha256':sha(oracle),'sealed_question_set':sealed,'candidate_rankings':rankings,'acceptance_table':rows,'evidence':evidence,'explanation':explanation,'planner_action':'Apply the sealed question set only after validating this result.' if accepted else 'Keep existing questions; review the named oracle cells and candidate responses.','question_action':None,'sealed_question_set_digest_before':None,'sealed_question_set_digest_after':sealed['digest'] if accepted else None,'authority_recommendations':[]}
    metadata={'duration_ms':max(0,round((time.time()-min(p.stat().st_mtime for p in all_files))*1000)),'tool_calls':len(all_files)+all_retries,'retry_count':all_retries,'correlation_id':req['correlation_id'],'jev_run_ids':sorted(set(all_run_ids)),'planner_observation_trust':None,'authoritative_sources_unchanged':True}
    result={'schema_version':'1.0.0','success':True,'canceled':False,'aborted_by':None,'data':data,'error':None,'metadata':metadata}
    stem=f'{aid}-{gate}-'+('fixtures-v5-' if FIXTURES_V5 else 'fixtures-v4-' if FIXTURES else 'v3-' if V3 else 'v2-' if V2 else '')+'20261029-result'
    (HERE/(stem+'.json')).write_text(json.dumps(result,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    (HERE/(stem+'-vars.json')).write_text(json.dumps({k:result[k] for k in ('success','canceled','aborted_by','data','error','metadata')},sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    print(aid,gate,'accepted',accepted,'score',score['exact_role_cells'],score['total_role_cells'],'verdicts',score['exact_semantic_verdicts'],score['total_semantic_verdicts'],'selected',selected['bundle'])
