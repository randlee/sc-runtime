import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
def sha(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
targets={
 'planning':('addressed',{'type':'choice','instructions':'Does item.text expressly preserve the schedule registry permission to accept every deliberately supplied plaintext environment value, including secret and nonsecret values? Merely mentioning plaintext while banning a value class does not carry the permission forward.','criteria':{'yes':'The plan explicitly preserves the full permitted class of deliberate plaintext set values.','no':'The plan is silent or denies any permitted class, even if it mentions plaintext.','unclear':'The plan names plaintext values but leaves the allowed class unresolved.'}}),
 'development':('implemented',{'type':'choice','instructions':'Does item.text state that the delivered schedule registry accepts deliberately supplied plaintext environment values without excluding the secret class? A nonsecret-only implementation does not fulfill the complete permission.','criteria':{'yes':'The delivered registry accepts deliberate plaintext set values including secret and nonsecret values.','no':'The described work omits that capability or restricts it to a subset.','unclear':'The delivery claim does not settle which deliberate values are accepted.'}}),
}
for gate,(role,q) in targets.items():
    old=json.loads((HERE/f'ANC-038-{gate}-candidates-v2.json').read_text());new=json.loads(json.dumps(old))
    for key in new:
        question=q if key==role else new[key][3]['question']
        new[key].append({'id':f'{key}-4','question':question,'origin':'targeted-successor' if key==role else 'frozen-bundle-control'})
    target=HERE/f'ANC-038-{gate}-candidates-v3.json';prov=HERE/f'ANC-038-{gate}-candidates-v3-provenance.json'
    assert not target.exists() and not prov.exists()
    target.write_text(json.dumps(new,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    prov.write_text(json.dumps({'schema':'plan-anchor/tuning-candidate-provenance/1','predecessor_sha256':sha(old),'successor_sha256':sha(new),'new_target_role':role,'candidate_id':role+'-4','purpose':'Separate full authorized plaintext capability from a partial nonsecret-only implementation.'},sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    print(gate,sha(new))
